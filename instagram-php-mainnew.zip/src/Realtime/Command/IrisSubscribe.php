<?php

namespace InstagramAPI\Realtime\Command;

use InstagramAPI\Constants;
use InstagramAPI\Realtime\CommandInterface;
use InstagramAPI\Realtime\Mqtt;

class IrisSubscribe implements CommandInterface
{
    const INVALID_SEQUENCE_ID = -1;

    /**
     * @var array
     */
    protected $_data;

    /**
     * Constructor.
     *
     * @param int    $sequenceId
     * @param string $snapshotAtMs
     * @param string snapshotAppVersion
     *
     * @throws \InvalidArgumentException
     */
    public function __construct(
        $sequenceId,
        $snapshotAtMs,
        $snapshotAppVersion)
    {
        if ($sequenceId === self::INVALID_SEQUENCE_ID) {
            throw new \InvalidArgumentException('Invalid Iris sequence identifier.');
        }
        $this->_data = [];
        $this->_data['seq_id'] = $sequenceId;
        $this->_data['snapshot_at_ms'] =  $snapshotAtMs;
        $this->_data['snapshot_app_version'] = $snapshotAppVersion;
    }

    /** {@inheritdoc} */
    public function getTopic()
    {
        return Mqtt\Topics::IRIS_SUB;
    }

    /** {@inheritdoc} */
    public function getQosLevel()
    {
        return Mqtt\QosLevel::ACKNOWLEDGED_DELIVERY;
    }

    /** {@inheritdoc} */
    public function jsonSerialize()
    {
        return $this->_data;
    }
}
