<?php

namespace InstagramAPI\Realtime\Subscription\GraphQl;

use InstagramAPI\Realtime\Subscription\GraphQlSubscription;
use InstagramAPI\Signatures;

class IgLiveWaveSubscription extends GraphQlSubscription
{
    const QUERY = '17882305414154951';
    const ID = 'live_wave';

    /**
     * Constructor.
     *
     * @param string $deviceId
     */
    public function __construct(
        $subscriptionId,
        $broadcastId,
        $receiverId)
    {
        parent::__construct(self::QUERY, [
            'client_subscription_id' => $subscriptionId,
            'broadcast_id' => $broadcastId,
            'receiver_id' => $receiverId
        ]);
    }

    /** {@inheritdoc} */
    public function getId()
    {
        return self::ID;
    }
}
