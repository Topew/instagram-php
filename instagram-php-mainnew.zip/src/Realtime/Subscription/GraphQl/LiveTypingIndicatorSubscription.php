<?php

namespace InstagramAPI\Realtime\Subscription\GraphQl;

use InstagramAPI\Realtime\Subscription\GraphQlSubscription;
use InstagramAPI\Signatures;

class LiveTypingIndicatorSubscription extends GraphQlSubscription
{
    const QUERY = '17926314067024917';
    const ID = 'live_typing_indicator';

    /**
     * Constructor.
     *
     * @param string $deviceId
     */
    public function __construct(
        $subscriptionId,
        $broadcastId)
    {
        parent::__construct(self::QUERY, [
            'client_subscription_id' => $subscriptionId,
            'broadcast_id' => $broadcastId
        ]);
    }

    /** {@inheritdoc} */
    public function getId()
    {
        return self::ID;
    }
}
