<?php

namespace InstagramAPI;

use GuzzleHttp\Client as GuzzleClient;
use GuzzleHttp\Cookie\CookieJar;
use GuzzleHttp\Cookie\SetCookie;
use GuzzleHttp\HandlerStack;
use GuzzleHttp\Promise\PromiseInterface;
use function GuzzleHttp\Psr7\modify_request;
use InstagramAPI\Exception\InstagramException;
use InstagramAPI\Exception\LoginRequiredException;
use InstagramAPI\Exception\ServerMessageThrower;
use InstagramAPI\Middleware\FakeCookies;
use InstagramAPI\Middleware\ZeroRating;
use LazyJsonMapper\Exception\LazyJsonMapperException;
use Psr\Http\Message\RequestInterface as HttpRequestInterface;
use Psr\Http\Message\ResponseInterface as HttpResponseInterface;

/**
 * This class handles core API network communication.
 */
class Client
{
    /**
     * How frequently we're allowed to auto-save the cookie jar, in seconds.
     *
     * @var int
     */
    const COOKIE_AUTOSAVE_INTERVAL = 45;

    /**
     * The Instagram class instance we belong to.
     *
     * @var \InstagramAPI\Instagram
     */
    protected $_parent;

    /**
     * What user agent to identify our client as.
     *
     * @var string
     */
    protected $_userAgent;

    /**
     * The SSL certificate verification behavior of requests.
     *
     * @see http://docs.guzzlephp.org/en/latest/request-options.html#verify
     *
     * @var bool|string
     */
    protected $_verifySSL;

    /**
     * Proxy to use for all requests. Optional.
     *
     * @see http://docs.guzzlephp.org/en/latest/request-options.html#proxy
     *
     * @var string|array|null
     */
    protected $_proxy;

    /**
     * Network interface override to use.
     *
     * Only works if Guzzle is using the cURL backend. But that's
     * almost always the case, on most PHP installations.
     *
     * @see http://php.net/curl_setopt CURLOPT_INTERFACE
     *
     * @var string|null
     */
    protected $_outputInterface;

    /**
     * @var \GuzzleHttp\Client
     */
    private $_guzzleClient;

    /**
     * @var \InstagramAPI\Middleware\FakeCookies
     */
    private $_fakeCookies;

    /**
     * @var \InstagramAPI\Middleware\ZeroRating
     */
    private $_zeroRating;

    /**
     * @var \GuzzleHttp\Cookie\CookieJar
     */
    private $_cookieJar;

    /**
     * The timestamp of when we last saved our cookie jar to disk.
     *
     * Used for automatically saving the jar after any API call, after enough
     * time has elapsed since our last save.
     *
     * @var int
     */
    private $_cookieJarLastSaved;

    /**
     * The flag to force cURL to reopen a fresh connection.
     *
     * @var bool
     */
    private $_resetConnection;

    /**
     * The most recent request processed.
     *
     * Used for debugging failed requests in exceptions without needing to
     * enable debug mode.
     *
     * @var Request
     */
    private $_lastRequest;

    /**
     * The flag will use same pigeon Timestamp.
     *
     * @var bool
     */
    private $_pigeonBatch;

    /**
     * The Pigeon Timestamp.
     *
     * @var float
     */
    private $_pigeonTimestamp;

    /**
     * The Pigeon Session ID.
     *
     * @var string
     */
    private $_pigeonSession;

    /**
     * Current connection retries count
     * Usage: Mobile proxies connection break adaptation.
     *
     * @var int
     */
    private $_connectRetries;

    /**
     * Maximum connection retries count
     * Usage: Mobile proxies connection break adaptation.
     *
     * @var int
     */
    private $_maxConnectRetries;

    /**
     * Current connection retries count
     * Usage: Mobile proxies connection break adaptation.
     *
     * @var int
     */
    private $_reqStartTime;

    /**
     * Send asynchronous requests
     * 
     * @var bool
     */
    private $_isAsyncRequest;

    /**
     * Additional cookies for request header
     *
     * @var string
     */
    public $_authorization = '';
    public $_wwwClaim = '';
    public $_DIRECT_REGION_HINT = '';
    public $_SHBID = '';
    public $_SHBTS = '';
    public $_RUR = '';
    public $_DS_USER_ID = '';
    public $_MID = '';
    public $_navChain = '';
    public $_resetNavChain = false;
    public $_clientEndpoint = '';
    public $_resetClientEndpoint = false;

    /**
     * Constructor.
     *
     * @param \InstagramAPI\Instagram $parent
     */
    public function __construct(
        $parent)
    {
        $this->_parent = $parent;

        // Defaults.
        $this->_verifySSL = true;
        $this->_proxy = null;
        $this->_isAsyncRequest = false;

        // Set Pigeon Session ID.
        if ($this->_parent->getPlatform() === 'ios') {
            $this->_pigeonSession = strtoupper(Signatures::generateUUID());
        } else {
            $this->_pigeonSession = 'UFS-' . Signatures::generateUUID() . '-0';
        }

        // Create a default handler stack with Guzzle's auto-selected "best
        // possible transfer handler for the user's system", and with all of
        // Guzzle's default middleware (cookie jar support, etc).
        $stack = HandlerStack::create();

        // Create our cookies middleware and add it to the stack.
        $this->_fakeCookies = new FakeCookies();
        $stack->push($this->_fakeCookies, 'fake_cookies');

        $this->_zeroRating = new ZeroRating($parent);
        $stack->push($this->_zeroRating, 'zero_rewrite');

        // Default request options (immutable after client creation).
        $this->_guzzleClient = new GuzzleClient([
            'handler'         => $stack, // Our middleware is now injected.
            'allow_redirects' => [
                'max' => 8, // Allow up to eight redirects (that's plenty).
            ],
            'connect_timeout' => 10.0, // Give up trying to connect after 10s.
            'decode_content'  => true, // Decode gzip/deflate/etc HTTP responses.
            'timeout'         => 240.0, // Maximum per-request time (seconds).
            // Tells Guzzle to stop throwing exceptions on non-"2xx" HTTP codes,
            // thus ensuring that it only triggers exceptions on socket errors!
            // We'll instead MANUALLY be throwing on certain other HTTP codes.
            'http_errors'     => false,
        ]);

        $this->_resetConnection = false;
        $this->_connectRetries = 0;
        $this->_maxConnectRetries = 5;
        $this->_connectRetryDelay = 7;
    }

    /**
     * Set custom maximum connection retries.
     * 
     * @param int $value
     * 
     * @return self
     */
    public function setConnectRetries(
        $value)
    {
        if (!empty($value) && is_integer($value) && $value >= 0) {
            $this->_connectRetries = $value;
        }

        return $this;
    }

    /**
     * Get current connection retries 
     * 
     * @return int
     */
    public function getConnectRetries()
    {
        return $this->_connectRetries;
    }

    /**
     * Set custom maximum connection retries.
     * 
     * @param int $value
     * 
     * @return self
     */
    public function setMaxConnectRetries(
        $value)
    {
        if (!empty($value) && is_integer($value) && $value > 0) {
            $this->_maxConnectRetries = $value;
        }

        return $this;
    }

    /**
     * Get custom maximum connection retries.
     * 
     * @return int
     */
    public function getMaxConnectRetries()
    {
        return $this->_maxConnectRetries;
    }

    /**
     * Set sleep before next connect retry.
     * 
     * @param int $value
     * 
     * @return self
     */
    public function setConnectRetryDelay(
        $value)
    {
        if (!empty($value) && is_integer($value) && $value > 0) {
            $this->_connectRetryDelay = $value;
        }

        return $this;
    }

    /**
     * Get sleep before next connect retry.
     * 
     * @return int
     */
    public function getConnectRetryDelay()
    {
        return $this->_connectRetryDelay;
    }

    /**
     * Set this request as async request
     * 
     * @param bool $value
     * 
     * @return self
     */
    public function setIsAsyncRequest(
        $value = false)
    {
        $this->_isAsyncRequest = (bool) $value;

        return $this;
    }

    /**
     * Is this request is async request
     * 
     * @return bool 
     */
    public function getIsAsyncRequest() 
    {
        return $this->_isAsyncRequest;
    }

    /**
     * Resets certain Client settings via the current Settings storage.
     *
     * Used whenever we switch active user, to configure our internal state.
     *
     * @param bool $resetCookieJar (optional) Whether to clear current cookies.
     *
     * @throws \InstagramAPI\Exception\SettingsException
     */
    public function updateFromCurrentSettings(
        $resetCookieJar = false)
    {
        // Update our internal client state from the new user's settings.
        $this->_userAgent = $this->_parent->device->getUserAgent();
        $this->loadCookieJar($resetCookieJar);

        // Verify that the jar contains a non-expired csrftoken for the API
        // domain. Instagram gives us a 1-year csrftoken whenever we log in.
        // If it's missing, we're definitely NOT logged in! But even if all of
        // these checks succeed, the cookie may still not be valid. It's just a
        // preliminary check to detect definitely-invalid session cookies!
        if ($this->getToken() === null) {
            // Deprecated, because we are not using cookies anymore in mobile API
            // $this->_parent->isMaybeLoggedIn = false;
        }

        // Load rewrite rules (if any).
        $this->zeroRating()->update($this->_parent->settings->getRewriteRules());
    }

    /**
     * Loads all cookies via the current Settings storage.
     *
     * @param bool $resetCookieJar (optional) Whether to clear current cookies.
     *
     * @throws \InstagramAPI\Exception\SettingsException
     */
    public function loadCookieJar(
        $resetCookieJar = false)
    {
        // Mark any previous cookie jar for garbage collection.
        $this->_cookieJar = null;

        // Delete all current cookies from the storage if this is a reset.
        if ($resetCookieJar) {
            $this->_parent->settings->setCookies('');
        }

        // Get all cookies for the currently active user.
        $cookieData = $this->_parent->settings->getCookies();

        // Attempt to restore the cookies, otherwise create a new, empty jar.
        $restoredCookies = is_string($cookieData) ? @json_decode($cookieData, true) : null;
        if (!is_array($restoredCookies)) {
            $restoredCookies = [];
        }

        // Memory-based cookie jar which must be manually saved later.
        $this->_cookieJar = new CookieJar(false, $restoredCookies);

        // Reset the "last saved" timestamp to the current time to prevent
        // auto-saving the cookies again immediately after this jar is loaded.
        $this->_cookieJarLastSaved = time();
    }

    /**
     * Retrieve Pigeon Session ID.
     *
     * @return string
     */
    public function getPigeonSession()
    {
        return $this->_pigeonSession;
    }

    /**
     * Retrieve the CSRF token from the current cookie jar.
     *
     * Note that Instagram gives you a 1-year token expiration timestamp when
     * you log in. But if you log out, they set its timestamp to "0" which means
     * that the cookie is "expired" and invalid. We ignore token cookies if they
     * have been logged out, or if they have expired naturally.
     *
     * @return string|null The token if found and non-expired, otherwise NULL.
     */
    public function getToken()
    {
        $cookie = $this->getCookie('csrftoken', 'i.instagram.com');
        if ($cookie === null || $cookie->getValue() === '') {
            return null;
        }

        return $cookie->getValue();
    }

    /**
     * Retrieve the CSRF token from the current cookie jar (web API)
     *
     * Note that Instagram gives you a 1-year token expiration timestamp when
     * you log in. But if you log out, they set its timestamp to "0" which means
     * that the cookie is "expired" and invalid. We ignore token cookies if they
     * have been logged out, or if they have expired naturally.
     *
     * @return string|null The token if found and non-expired, otherwise NULL.
     */
    public function getTokenGraph()
    {
        $cookie = $this->getCookie('csrftoken', '.instagram.com');
        if ($cookie === null || $cookie->getValue() === '') {
            return null;
        }

        return $cookie->getValue();
    }

    /**
     * Retrieve the MID token from the current cookie jar.
     *
     * @return string|null The MID if found and non-expired, otherwise NULL.
     */
    public function getMid()
    {
        $cookie = $this->getCookie('mid', 'i.instagram.com');
        if ($cookie === null || $cookie->getValue() === '') {
            return null;
        }

        return $cookie->getValue();
    }

    /**
     * Retrieve the ds_user_id token from the current cookie jar.
     *
     * @return string|null The ds_user_id if found and non-expired, otherwise NULL.
     */
    public function getDSUserId()
    {
        $cookie = $this->getCookie('ds_user_id', 'i.instagram.com');
        if ($cookie === null || $cookie->getValue() === '') {
            return null;
        }

        return $cookie->getValue();
    }

    /**
     * Retrieve the SessionID token from the current cookie jar.
     *
     * @return string|null The SessionID if found and non-expired, otherwise NULL.
     */
    public function getSessionID()
    {
        $cookie = $this->getCookie('sessionid', 'i.instagram.com');
        if ($cookie === null || $cookie->getValue() === '') {
            return null;
        }

        return $cookie->getValue();
    }

    /**
     * Retrieve the urlgen token from the current cookie jar.
     *
     * @return string|null The urlgen if found and non-expired, otherwise NULL.
     */
    public function getURLGen()
    {
        $cookie = $this->getCookie('urlgen', 'i.instagram.com');
        if ($cookie === null || $cookie->getValue() === '') {
            return null;
        }

        return $cookie->getValue();
    }

    /**
     * Retrieve the shbid token from the current cookie jar.
     *
     * @return string|null The shbid if found and non-expired, otherwise NULL.
     */
    public function getShbid()
    {
        $cookie = $this->getCookie('shbid', 'i.instagram.com');
        if ($cookie === null || $cookie->getValue() === '') {
            return null;
        }

        return $cookie->getValue();
    }

    /**
     * Retrieve the shbts token from the current cookie jar.
     *
     * @return string|null The shbts if found and non-expired, otherwise NULL.
     */
    public function getShbts()
    {
        $cookie = $this->getCookie('shbts', 'i.instagram.com');
        if ($cookie === null || $cookie->getValue() === '') {
            return null;
        }

        return $cookie->getValue();
    }

    /**
     * Retrieve the rur token from the current cookie jar.
     *
     * @return string|null The rur if found and non-expired, otherwise NULL.
     */
    public function getRUR()
    {
        $cookie = $this->getCookie('rur', 'i.instagram.com');
        if ($cookie === null || $cookie->getValue() === '') {
            return null;
        }

        return $cookie->getValue();
    }

    /**
     * Searches for a specific cookie in the current jar.
     *
     * @param string      $name   The name of the cookie.
     * @param string|null $domain (optional) Require a specific domain match.
     * @param string|null $path   (optional) Require a specific path match.
     *
     * @return \GuzzleHttp\Cookie\SetCookie|null A cookie if found and non-expired, otherwise NULL.
     */
    public function getCookie(
        $name,
        $domain = null,
        $path = null)
    {
        $foundCookie = null;
        if ($this->_cookieJar instanceof CookieJar) {
            /** @var SetCookie $cookie */
            foreach ($this->_cookieJar->getIterator() as $cookie) {
                if ($cookie->getName() === $name
                    && !$cookie->isExpired()
                    && ($domain === null || $cookie->matchesDomain($domain))
                    && ($path === null || $cookie->matchesPath($path))) {
                    // Loop-"break" is omitted intentionally, because we might
                    // have more than one cookie with the same name, so we will
                    // return the LAST one. This is necessary because Instagram
                    // has changed their cookie domain from `i.instagram.com` to
                    // `.instagram.com` and we want the *most recent* cookie.
                    // Guzzle's `CookieJar::setCookie()` always places the most
                    // recently added/modified cookies at the *end* of array.
                    $foundCookie = $cookie;
                }
            }
        }

        return $foundCookie;
    }

    /**
     * Set a cookie in the current jar.
     *
     * @param string      $name   The name of the cookie.
     * @param string|null $domain (optional) Require a specific domain match.
     * @param string|null $path   (optional) Require a specific path match.
     *
     * @return self
     */
    public function setCookie(
        $name,
        $domain = null,
        $value = null)
    {
        $cookie = new SetCookie();
        $cookie->setName($name);
        $cookie->setValue($value);
        $cookie->setDomain($domain);

        $this->_cookieJar->setCookie($cookie);

        return $this;
    }

    /**
     * Remove a cookie from the current jar.
     *
     * @param string      $name   The name of the cookie.
     *
     * @return self
     */
    public function removeCookie(
        $name)
    {
        foreach ($this->_cookieJar->getIterator() as $cookie) {
            if ($cookie->getName() == $name) {
                $this->_cookieJar->clear(
                    $cookie->getDomain(),
                    $cookie->getPath(),
                    $cookie->getName()
                );

                break;
            }
        }

        return $this;
    }

    /**
     * Return a cookie from the current jar.
     *
     * @param string      $name   The name of the cookie.
     *
     * @return self
     */
    public function returnCookie(
        $name)
    {
        foreach ($this->_cookieJar->getIterator() as $cookie) {
            if ($cookie->getName() == $name) {
                return $cookie->getValue();
            }
        }

        return false;
    }

    /**
     * Remove empty cookies from current jar.
     *
     * @return self
     */
    public function removeEmptyCookies() {
        if ($this->_cookieJar) {
            foreach ($this->_cookieJar->getIterator() as $cookie) {
                $name = $cookie->getName();
                $value = $cookie->getValue();
                if ($cookie->getValue() == '""') {
                    $this->_cookieJar->clear(
                        $cookie->getDomain(),
                        $cookie->getPath(),
                        $cookie->getName()
                    );

                    break;
                }
            }
        }

        return $this;
    }
    
    /**
     * Gives you all cookies in the Jar encoded as a JSON string.
     *
     * This allows custom Settings storages to retrieve all cookies for saving.
     *
     * @throws \InvalidArgumentException If the JSON cannot be encoded.
     *
     * @return string
     */
    public function getCookieJarAsJSON()
    {
        if (!$this->_cookieJar instanceof CookieJar) {
            return '[]';
        }

        // Gets ALL cookies from the jar, even temporary session-based cookies.
        $cookies = $this->_cookieJar->toArray();

        // Throws if data can't be encoded as JSON (will never happen).
        $jsonStr = \GuzzleHttp\json_encode($cookies);

        return $jsonStr;
    }

    /**
     * Tells current settings storage to store cookies if necessary.
     *
     * NOTE: This Client class is NOT responsible for calling this function!
     * Instead, our parent "Instagram" instance takes care of it and saves the
     * cookies "onCloseUser", so that cookies are written to storage in a
     * single, efficient write when the user's session is finished. We also call
     * it during some important function calls such as login/logout. Client also
     * automatically calls it when enough time has elapsed since last save.
     *
     * @throws \InvalidArgumentException                 If the JSON cannot be encoded.
     * @throws \InstagramAPI\Exception\SettingsException
     */
    public function saveCookieJar()
    {
        // Tell the settings storage to persist the latest cookies.
        $newCookies = $this->getCookieJarAsJSON();
        $this->_parent->settings->setCookies($newCookies);

        // Reset the "last saved" timestamp to the current time.
        $this->_cookieJarLastSaved = time();
    }

    /**
     * Controls the SSL verification behavior of the Client.
     *
     * @see http://docs.guzzlephp.org/en/latest/request-options.html#verify
     *
     * @param bool|string $state TRUE to verify using PHP's default CA bundle,
     *                           FALSE to disable SSL verification (this is
     *                           insecure!), String to verify using this path to
     *                           a custom CA bundle file.
     */
    public function setVerifySSL(
        $state)
    {
        $this->_verifySSL = $state;
    }

    /**
     * Gets the current SSL verification behavior of the Client.
     *
     * @return bool|string
     */
    public function getVerifySSL()
    {
        return $this->_verifySSL;
    }

    /**
     * Set the proxy to use for requests.
     *
     * @see http://docs.guzzlephp.org/en/latest/request-options.html#proxy
     *
     * @param string|array|null $value String or Array specifying a proxy in
     *                                 Guzzle format, or NULL to disable proxying.
     */
    public function setProxy(
        $value)
    {
        if (!empty($value)) {
            $proxy_parts = explode('://', $value);
            if ($proxy_parts[0] == "https" || $proxy_parts[0] == "http") {
                $value = $proxy_parts[1];
            }
            $this->_resetConnection = true;
        } else {
            $value = null;
        }
        $this->_proxy = $value;
    }

    /**
     * Gets the current proxy used for requests.
     *
     * @return string|array|null
     */
    public function getProxy()
    {
        return $this->_proxy;
    }

    /**
     * Sets the network interface override to use.
     *
     * Only works if Guzzle is using the cURL backend. But that's
     * almost always the case, on most PHP installations.
     *
     * @see http://php.net/curl_setopt CURLOPT_INTERFACE
     *
     * @param string|null $value Interface name, IP address or hostname, or NULL to
     *                           disable override and let Guzzle use any interface.
     */
    public function setOutputInterface(
        $value)
    {
        $this->_outputInterface = $value;
        $this->_resetConnection = true;
    }

    /**
     * Gets the current network interface override used for requests.
     *
     * @return string|null
     */
    public function getOutputInterface()
    {
        return $this->_outputInterface;
    }

    /**
     * Output debugging information.
     *
     * @param string                $method        "GET" or "POST".
     * @param string                $url           The URL or endpoint used for the request.
     * @param string|null           $uploadedBody  What was sent to the server. Use NULL to
     *                                             avoid displaying it.
     * @param int|null              $uploadedBytes How many bytes were uploaded. Use NULL to
     *                                             avoid displaying it.
     * @param HttpResponseInterface $response      The Guzzle response object from the request.
     * @param string                $responseBody  The actual text-body reply from the server.
     * @param bool                  $debug         CLI Debug.
     */
    protected function _printDebug(
        $method,
        $url,
        $headers,
        $uploadedBody,
        $uploadedBytes,
        HttpResponseInterface $response,
        $responseBody,
        $debug)
    {
        $path = Debug::$debugLogPath;
        if ($this->_parent->settings->getStorage() instanceof \InstagramAPI\Settings\Storage\File) {
            $path = $this->_parent->settings->getUserPath($this->_parent->username);
        }
        Debug::printRequest($method, $url, $path, $debug);

        Debug::printConnectRetries($this->getConnectRetries(), $this->getMaxConnectRetries(), $path, $debug);

        if (!empty($this->getProxy())) {
            Debug::printProxy($this->getProxy(), $path, $debug);
        }

        if (!empty($headers)) {
            Debug::printHeaders($headers, $path, $debug);
        }

        // Display the data body that was uploaded, if provided for debugging.
        // NOTE: Only provide this from functions that submit meaningful BODY data!
        if (is_string($uploadedBody)) {
            Debug::printPostData($uploadedBody, $path, $debug);
        }

        // Display the number of bytes uploaded in the data body, if provided for debugging.
        // NOTE: Only provide this from functions that actually upload files!
        if ($uploadedBytes !== null) {
            Debug::printUpload(Utils::formatBytes($uploadedBytes), $path, $debug);
        }

        // Display the number of bytes received from the response, and status code.
        if ($response->hasHeader('x-encoded-content-length')) {
            $bytes = Utils::formatBytes((int) $response->getHeaderLine('x-encoded-content-length'));
        } elseif ($response->hasHeader('Content-Length')) {
            $bytes = Utils::formatBytes((int) $response->getHeaderLine('Content-Length'));
        } else {
            $bytes = 0;
        }
        Debug::printHttpCode($response->getStatusCode(), $bytes, $path, $debug);

        // Display the actual API response body.
        Debug::printResponse($responseBody, $this->_parent->truncatedDebug, $path, $debug);
    }

    /**
     * Output debugging information (for async requests)
     *
     * @param string                $method        "GET" or "POST".
     * @param string                $url           The URL or endpoint used for the request.
     * @param string|null           $uploadedBody  What was sent to the server. Use NULL to
     *                                             avoid displaying it.
     * @param int|null              $uploadedBytes How many bytes were uploaded. Use NULL to
     *                                             avoid displaying it.
     * @param bool                  $debug         CLI Debug.
     */
    protected function _printAsyncDebug(
        $method,
        $url,
        $headers,
        $uploadedBody,
        $uploadedBytes,
        $debug)
    {
        $path = Debug::$debugLogPath;
        if ($this->_parent->settings->getStorage() instanceof \InstagramAPI\Settings\Storage\File) {
            $path = $this->_parent->settings->getUserPath($this->_parent->username);
        }
        Debug::printRequest($method, $url, $path, $debug);

        Debug::printConnectRetries($this->getConnectRetries(), $this->getMaxConnectRetries(), $path, $debug);

        if (!empty($this->getProxy())) {
            Debug::printProxy($this->getProxy(), $path, $debug);
        }

        if (!empty($headers)) {
            Debug::printHeaders($headers, $path, $debug);
        }

        // Display the data body that was uploaded, if provided for debugging.
        // NOTE: Only provide this from functions that submit meaningful BODY data!
        if (is_string($uploadedBody)) {
            Debug::printPostData($uploadedBody, $path, $debug);
        }

        // Display the number of bytes uploaded in the data body, if provided for debugging.
        // NOTE: Only provide this from functions that actually upload files!
        if ($uploadedBytes !== null) {
            Debug::printUpload(Utils::formatBytes($uploadedBytes), $path, $debug);
        }

        Debug::printMessage("RESPONSE: This is async request. Response can be checked via promises.", $path, $debug);
        Debug::printNewLine($path, $debug);
    }

    /**
     * Maps a server response onto a specific kind of result object.
     *
     * The result is placed directly inside `$responseObject`.
     *
     * @param Response              $responseObject An instance of a class object whose
     *                                              properties to fill with the response.
     * @param string                $rawResponse    A raw JSON response string
     *                                              from Instagram's server.
     * @param HttpResponseInterface $httpResponse   HTTP response object.
     * @param bool                  $silentFail     Silent fail flag.
     *
     * @throws InstagramException In case of invalid or failed API response.
     */
    public function mapServerResponse(
        Response $responseObject,
        $rawResponse,
        HttpResponseInterface $httpResponse,
        $silentFail)
    {
        // Attempt to decode the raw JSON to an array.
        // Important: Special JSON decoder which handles 64-bit numbers!
        $jsonArray = $this->api_body_decode($rawResponse, true);

        // If the server response is not an array, it means that JSON decoding
        // failed or some other bad thing happened. So analyze the HTTP status
        // code (if available) to see what really happened.
        if (!is_array($jsonArray)) {
            $httpStatusCode = $httpResponse !== null ? $httpResponse->getStatusCode() : null;
            switch ($httpStatusCode) {
                case 400:
                    throw new \InstagramAPI\Exception\BadRequestException("Invalid request options. Something going wrong with your request.");  
                case 403:
                    if (!empty($this->getProxy())) {
                        throw new \InstagramAPI\Exception\InstagramException("Instagram blocked your request. Please check your proxy for possible issues.");  
                    } else {
                        throw new \InstagramAPI\Exception\InstagramException("Instagram blocked your request. Please check your account for possible issues.");  
                    }
                case 404:
                    throw new \InstagramAPI\Exception\NotFoundException("Requested resource does not exist. The link you followed may be broken, or the page may have been removed.");
                case 502:
                    throw new \InstagramAPI\Exception\EmptyResponseException(sprintf("Connection with Instagram server couldn't be esablished. Received HTTP code: %s. Please try again later.", $httpStatusCode));
                default:
                    if (!empty($httpStatusCode)) {
                        throw new \InstagramAPI\Exception\EmptyResponseException(sprintf("No response from Instagram server. Either a connection or configuration error. Received HTTP code: %s.", $httpStatusCode));
                    } else {
                        throw new \InstagramAPI\Exception\EmptyResponseException('No response from Instagram server. Either a connection or configuration error.');
                    }
            }
        }

        // Perform mapping of all response properties.
        try {
            // Assign the new object data. Only throws if custom _init() fails.
            // NOTE: False = assign data without automatic analysis.
            $responseObject->assignObjectData($jsonArray, false); // Throws.

            // Use API developer debugging? We'll throw if class lacks property
            // definitions, or if they can't be mapped as defined in the class
            // property map. But we'll ignore missing properties in our custom
            // UnpredictableKeys containers, since those ALWAYS lack keys. ;-)
            if ($this->_parent->apiDeveloperDebug) {
                // Perform manual analysis (so that we can intercept its analysis result).
                $analysis = $responseObject->exportClassAnalysis(); // Never throws.

                // Remove all "missing_definitions" errors for UnpredictableKeys containers.
                // NOTE: We will keep any "bad_definitions" errors for them.
                foreach ($analysis->missing_definitions as $className => $x) {
                    if (strpos($className, '\\Response\\Model\\UnpredictableKeys\\') !== false) {
                        unset($analysis->missing_definitions[$className]);
                    }
                }

                // If any problems remain after that, throw with all combined summaries.
                if ($analysis->hasProblems()) {
                    throw new LazyJsonMapperException(
                        $analysis->generateNiceSummariesAsString()
                    );
                }
            }
        } catch (LazyJsonMapperException $e) {
            // Since there was a problem, let's help our developers by
            // displaying the server's JSON data in a human-readable format,
            // which makes it easy to see the structure and necessary changes
            // and speeds up the job of updating responses and models.
            try {
                // Decode to stdClass to properly preserve empty objects `{}`,
                // otherwise they would appear as empty `[]` arrays in output.
                // NOTE: Large >32-bit numbers will be transformed into strings,
                // which helps us see which numeric values need "string" type.
                $jsonObject = $this->api_body_decode($rawResponse, false);
                if (is_object($jsonObject)) {
                    $prettyJson = @json_encode(
                        $jsonObject,
                        JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE
                    );
                    if ($prettyJson !== false) {
                        Debug::printResponse(
                            'Human-Readable Response:'.PHP_EOL.$prettyJson,
                            false // Not truncated.
                        );
                    }
                }
            } catch (\Exception $e) {
                // Ignore errors.
            }

            // Exceptions will only be thrown if API developer debugging is
            // enabled and finds a problem. Either way, we should re-wrap the
            // exception to our native type instead. The message gives enough
            // details and we don't need to know the exact Lazy sub-exception.
            throw new InstagramException($e->getMessage());
        }

        // Save the HTTP response object as the "getHttpResponse()" value.
        $responseObject->setHttpResponse($httpResponse);

        // Throw an exception if the API response was unsuccessful.
        // NOTE: It will contain the full server response object too, which
        // means that the user can look at the full response details via the
        // exception itself.
        if (!$responseObject->isOk() || ($responseObject->hasStepName() && $responseObject->getStepName())) {
            if ($responseObject instanceof \InstagramAPI\Response\DirectSendItemResponse && $responseObject->getPayload() !== null) {
                // Check is response is array
                // Can be both DirectSendItemPayload and DirectSendItemPayload[].
                if (is_array($responseObject->getPayload())) {
                    // Temporary solution
                    if (isset($responseObject->getPayload()[0])) {
                        $message = $responseObject->getPayload()[0]->getMessage();
                    } else {
                        $msg = explode(":",  implode(",", $responseObject->getPayload()), 2);
                        $message = isset($msg[1]) ? $msg[1] : $msg[0];
                    }
                } else {
                    $message = $responseObject->getPayload()->getMessage();
                }
            } else {
                $message = $responseObject->getMessage();
            }

            if ($silentFail !== true) {
                try {
                    ServerMessageThrower::autoThrow(
                        get_class($responseObject),
                        $message,
                        $responseObject,
                        $httpResponse
                    );
                } catch (LoginRequiredException $e) {
                    // Instagram told us that our session is invalid (that we are
                    // not logged in). Update our cached "logged in?" state. This
                    // ensures that users with various retry-algorithms won't hammer
                    // their server. When this flag is false, ALL further attempts
                    // at AUTHENTICATED requests will be aborted by our library.
                    $this->_parent->isMaybeLoggedIn = false;

                    throw $e; // Re-throw.
                }
            }
        }
    }

    /**
     * Helper which builds in the most important Guzzle options.
     *
     * Takes care of adding all critical options that we need on every request.
     * Such as cookies and the user's proxy. But don't call this function
     * manually. It's automatically called by _guzzleRequest()!
     *
     * @param array $guzzleOptions The options specific to the current request.
     *
     * @return array A guzzle options array.
     */
    protected function _buildGuzzleOptions(
        array $guzzleOptions = [])
    {
        if ($this->_parent->isWebLogin) {
            // Web API
            $criticalOptions = [
                'cookies' => ($this->_cookieJar instanceof CookieJar ? $this->_cookieJar : false),
                'verify'  => file_exists('/etc/ssl/certs/cacert.pem') ? '/etc/ssl/certs/cacert.pem' : $this->_verifySSL,
                'proxy'   => ($this->_proxy !== null ? $this->_proxy : null),
                'curl'    => [
                    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_2, // Make http client work with HTTP 2/0
                    CURLOPT_SSLVERSION => 1,
                    CURLOPT_SSL_VERIFYPEER => false
                ]
            ];
        } else {
            // Mobile API
            $criticalOptions = [
                'verify'  => file_exists('/etc/ssl/certs/cacert.pem') ? '/etc/ssl/certs/cacert.pem' : $this->_verifySSL,
                'proxy'   => ($this->_proxy !== null ? $this->_proxy : null),
                'curl'    => [
                    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_2, // Make http client work with HTTP 2/0
                    CURLOPT_SSLVERSION => 1,
                    CURLOPT_SSL_VERIFYPEER => false
                ]
            ];
        }

        // Critical options always overwrite identical keys in regular opts.
        // This ensures that we can't screw up the proxy/verify/cookies.
        $finalOptions = array_merge($guzzleOptions, $criticalOptions);

        // Now merge any specific Guzzle cURL-backend overrides. We must do this
        // separately since it's in an associative array and we can't just
        // overwrite that whole array in case the caller had curl options.
        if (!array_key_exists('curl', $finalOptions)) {
            $finalOptions['curl'] = [];
        }

        // Add their network interface override if they want it.
        // This option MUST be non-empty if set, otherwise it breaks cURL.
        if (is_string($this->_outputInterface) && $this->_outputInterface !== '') {
            $finalOptions['curl'][CURLOPT_INTERFACE] = $this->_outputInterface;
        }
        if ($this->_resetConnection) {
            $finalOptions['curl'][CURLOPT_FRESH_CONNECT] = true;
            $this->_resetConnection = false;
        }

        return $finalOptions;
    }

    /**
     * Wraps Guzzle's request and adds special error handling and options.
     *
     * Automatically throws exceptions on certain very serious HTTP errors. And
     * re-wraps all Guzzle errors to our own internal exceptions instead. You
     * must ALWAYS use this (or _apiRequest()) instead of the raw Guzzle Client!
     * However, you can never assume the server response contains what you
     * wanted. Be sure to validate the API reply too, since Instagram's API
     * calls themselves may fail with a JSON message explaining what went wrong.
     *
     * WARNING: This is a semi-lowlevel handler which only applies critical
     * options and HTTP connection handling! Most functions will want to call
     * _apiRequest() instead. An even higher-level handler which takes care of
     * debugging, server response checking and response decoding!
     *
     * @param HttpRequestInterface $request       HTTP request to send.
     * @param array                $guzzleOptions Extra Guzzle options for this request.
     *
     * @throws \InstagramAPI\Exception\NetworkException                For any network/socket related errors.
     * @throws \InstagramAPI\Exception\ThrottledException              When we're throttled by server.
     * @throws \InstagramAPI\Exception\RequestHeadersTooLargeException When request is too large.
     *
     * @return HttpResponseInterface|PromiseInterface
     */
    protected function _guzzleRequest(
        HttpRequestInterface $request,
        array $guzzleOptions = [])
    {
        // Add critically important options for authenticating the request.
        $guzzleOptions = $this->_buildGuzzleOptions($guzzleOptions);

        // Check is proxied connection disabled
        if ($this->_parent->_skipProxy) {
            $guzzleOptions['proxy'] = null;
            // Set priority to IPv4 over IPv6
            $guzzleOptions['force_ip_resolve'] = 'v4';
        }

        // Check is this is async request
        if ($this->getIsAsyncRequest()) {
            $promise = $this->_guzzleClient->sendAsync($request, $guzzleOptions);
            return $promise;
        }

        // Connection break adaptation (for mobile proxies)
        $this->_connectRetries = 0;
        $this->_maxConnectRetries = $this->getMaxConnectRetries();
        $isConnected = false;
        do {
            // Update connection retry counter
            $this->_connectRetries++;
            $this->_reqStartTime = time();

            // Attempt the request. Will throw in case of socket errors!
            try {
                $response = $this->_guzzleClient->send($request, $guzzleOptions);
                $isConnected = true;
            } catch (\Exception $e) {
                // This will 
                if ($this->_connectRetries >= $this->_maxConnectRetries) {
                    // Re-wrap Guzzle's exception using our own NetworkException.
                    throw new \InstagramAPI\Exception\NetworkException($e);
                } elseif ($this->_connectRetryDelay > 0) {
                    $sleep_time = $this->_connectRetryDelay - (time() - $this->_reqStartTime);
                    if ($sleep_time > 0) {
                        sleep($this->_connectRetryDelay);
                    }
                }
            }
        } while (!$isConnected);

        // Detect very serious HTTP status codes in the response.
        $httpCode = $response->getStatusCode();
        switch ($httpCode) {
            case 429: // "429 Too Many Requests"
                throw new \InstagramAPI\Exception\ThrottledException('Throttled by Instagram because of too many API requests.');
                break;
            case 431: // "431 Request Header Fields Too Large"
                throw new \InstagramAPI\Exception\RequestHeadersTooLargeException('The request start-line and/or headers are too large to process.');
                break;
            // WARNING: Do NOT detect 404 and other higher-level HTTP errors here,
            // since we catch those later during steps like mapServerResponse()
            // and autoThrow. This is a warning to future contributors!
        }

        // We'll periodically auto-save our cookies at certain intervals. This
        // complements the "onCloseUser" and "login()/logout()" force-saving.
        if ((time() - $this->_cookieJarLastSaved) > self::COOKIE_AUTOSAVE_INTERVAL) {
            $this->saveCookieJar();
        }

        // The response may still have serious but "valid response" errors, such
        // as "400 Bad Request". But it's up to the CALLER to handle those!
        return $response;
    }

    /**
     * Internal wrapper around _guzzleRequest().
     *
     * This takes care of many common additional tasks needed by our library,
     * so you should try to always use this instead of the raw _guzzleRequest()!
     *
     * Available library options are:
     * - 'noDebug': Can be set to TRUE to forcibly hide debugging output for
     *   this request. The user controls debugging globally, but this is an
     *   override that prevents them from seeing certain requests that you may
     *   not want to trigger debugging (such as perhaps individual steps of a
     *   file upload process). However, debugging SHOULD be allowed in MOST cases!
     *   So only use this feature if you have a very good reason.
     * - 'debugUploadedBody': Set to TRUE to make debugging display the data that
     *   was uploaded in the body of the request. DO NOT use this if your function
     *   uploaded binary data, since printing those bytes would kill the terminal!
     * - 'debugUploadedBytes': Set to TRUE to make debugging display the size of
     *   the uploaded body data. Should ALWAYS be TRUE when uploading binary data.
     *
     * @param HttpRequestInterface $request        HTTP request to send.
     * @param array                $guzzleOptions  Extra Guzzle options for this request.
     * @param array                $libraryOptions Additional options for controlling Library features
     *                                             such as the debugging output.
     *
     * @throws \InstagramAPI\Exception\NetworkException   For any network/socket related errors.
     * @throws \InstagramAPI\Exception\ThrottledException When we're throttled by server.
     *
     * @return HttpResponseInterface|PromiseInterface
     */
    protected function _apiRequest(
        HttpRequestInterface $request,
        array $guzzleOptions = [],
        array $libraryOptions = [])
    {
        // Perform the API request and retrieve the raw HTTP response body.
        $guzzleResponse = $this->_guzzleRequest($request, $guzzleOptions);

        // Debugging (must be shown before possible decoding error).
        if ($this->_parent->debug && (!isset($libraryOptions['noDebug']) || !$libraryOptions['noDebug']) || \InstagramAPI\Debug::$debugLog) {
            // Determine whether we should display the contents of the UPLOADED body.
            if (isset($libraryOptions['debugUploadedBody']) && $libraryOptions['debugUploadedBody']) {
                $uploadedBody = (string) $request->getBody();
                if (!strlen($uploadedBody)) {
                    $uploadedBody = null;
                }
            } else {
                $uploadedBody = null; // Don't display.
            }

            // Determine whether we should display the size of the UPLOADED body.
            if (isset($libraryOptions['debugUploadedBytes']) && $libraryOptions['debugUploadedBytes']) {
                // Calculate the uploaded bytes by looking at request's body size, if it exists.
                $uploadedBytes = $request->getBody()->getSize();
            } else {
                $uploadedBytes = null; // Don't display.
            }

            if ($this->getIsAsyncRequest()) {
                $this->_printAsyncDebug(
                    $request->getMethod(),
                    $this->_zeroRating->rewrite((string) $request->getUri()),
                    $request->getHeaders(),
                    $uploadedBody,
                    $uploadedBytes,
                    $this->_parent->debug
                );
            } else {
                $this->_printDebug(
                    $request->getMethod(),
                    $this->_zeroRating->rewrite((string) $request->getUri()),
                    $request->getHeaders(),
                    $uploadedBody,
                    $uploadedBytes,
                    $guzzleResponse,
                    (string) $guzzleResponse->getBody(),
                    $this->_parent->debug
                );
            }
        }

        return $guzzleResponse;
    }

    /**
     * Perform an Instagram API call.
     *
     * @param HttpRequestInterface $request       HTTP request to send.
     * @param array                $guzzleOptions Extra Guzzle options for this request.
     *
     * @throws InstagramException
     *
     * @return HttpResponseInterface|PromiseInterface
     */
    public function api(
        HttpRequestInterface $request,
        array $guzzleOptions = [])
    {
        if ($this->_parent->isWebLogin) {
            $headers = [
                'set_headers' => [
                    // Keep the API's HTTPS connection alive in Guzzle for future
                    // re-use, to greatly speed up all further queries after this.
                    // 'Connection'                 => 'Keep-Alive',
                    'Accept-Encoding'            => Constants::ACCEPT_ENCODING_GRAPH,
                    'Accept-Language'            => $this->_parent->getAcceptLanguage()
                ],
            ];
            $headers['set_headers']['Accept'] = '*/*';

            if ($this->_parent->_needsAuth) {
                $headers['set_headers']['Origin'] = 'https://www.instagram.com';
                $headers['set_headers']['Referer'] = 'https://www.instagram.com/';
                $headers['set_headers']['X-Asbd-Id'] = $this->_parent->settings->get('asbd_id');
                $headers['set_headers']['X-CSRFToken'] = $this->_parent->client->getTokenGraph();
                $headers['set_headers']['X-Requested-With'] = 'XMLHttpRequest';
                $headers['set_headers']['X-Ig-App-Id'] = Constants::IG_WEB_APPLICATION_ID;
            }

            $userAgent = $request->getHeader('User-Agent');
            if (!empty($userAgent)) {
                $headers['set_headers']['User-Agent'] = $userAgent;
            } else {
                if ($this->_parent->getIsAndroid()) {
                    $headers['set_headers']['User-Agent'] = sprintf('Mozilla/5.0 (Linux; Android %s; Google) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Mobile Safari/537.36', $this->_parent->device->getAndroidRelease());
                } else {
                    $headers['set_headers']['User-Agent'] = 'Mozilla/5.0 (iPhone; CPU iPhone OS ' . Constants::IOS_VERSION . ' like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.4 Mobile/15E148 Safari/604.1';
                }
            }
        } else {
            $headers = [
                'set_headers' => [
                    'X-Pigeon-Session-Id'    => $this->_pigeonSession,
                    'X-Pigeon-Rawclienttime' => $this->_getPigeonRawClientTime(),
                    // Keep the API's HTTPS connection alive in Guzzle for future
                    // re-use, to greatly speed up all further queries after this.
                    // 'Connection'                 => 'Keep-Alive',
                    'Accept-Language'        => $this->_parent->getAcceptLanguage()
                ],
            ];

            if ($this->_parent->getIsAndroid()) {
                $headers['set_headers']['Accept-Encoding'] = Constants::ACCEPT_ENCODING;
            } else {
                $headers['set_headers']['Accept-Encoding'] = Constants::ACCEPT_ENCODING_SKIP_ZSTD;
            }

            if ((PHP_VERSION_ID < 80000) && !@extension_loaded('zstd')) {
                $headers['set_headers']['Accept-Encoding'] = Constants::ACCEPT_ENCODING_SKIP_ZSTD;
            } else {
                $headers['set_headers']['Accept-Encoding'] = Constants::ACCEPT_ENCODING;
            }

            $userAgent = $request->getHeader('User-Agent');
            if (!empty($userAgent)) {
                $headers['set_headers']['User-Agent'] = $userAgent;
            } else {
                $headers['set_headers']['User-Agent'] = $this->_userAgent;
            }
        }

        $acceptEncoding = $request->getHeader('Accept-Encoding');
        if (!empty($acceptEncoding)) {
            $headers['set_headers']['Accept-Encoding'] = $acceptEncoding;
        }

        $this->removeEmptyCookies();

        if (!$this->_parent->isWebLogin) {
            if ($this->_parent->getIsAndroid()) {
                $headers['set_headers']['X-Ig-Bandwidth-Speed-Kbps'] = '0.000';
                $headers['set_headers']['X-Ig-Bandwidth-Totalbytes-B'] = 0;
                $headers['set_headers']['X-Ig-Bandwidth-Totaltime-Ms'] = 0;
            } else {
                $headers['set_headers']['X-Ig-Bandwidth-Speed-Kbps'] = '0.000';
                $headers['set_headers']['X-Ig-Abr-Connection-Speed-Kbps'] = 0;
            }

            if ($this->_parent->_needsAuth) {
                if ($this->_authorization) {
                    $headers['set_headers']['Authorization'] = $this->_authorization;
                }
                if ($this->_DIRECT_REGION_HINT) { 
                    $headers['set_headers']['Ig-U-Ig-Direct-Region-Hint'] = $this->_DIRECT_REGION_HINT;
                }
                if ($this->_SHBID) { 
                    $headers['set_headers']['Ig-U-Shbid'] = $this->_SHBID; 
                }
                if ($this->_SHBTS) { 
                    $headers['set_headers']['Ig-U-Shbts'] = $this->_SHBTS; 
                }
                if ($this->_DS_USER_ID) {
                    $headers['set_headers']['Ig-U-Ds-User-Id'] = $this->_DS_USER_ID;
                }
                if ($this->_RUR) {
                    $headers['set_headers']['Ig-U-Rur'] = $this->_RUR;
                }
                if (!empty($this->_navChain)) {
                    $headers['set_headers']['X-Ig-Nav-Chain'] = $this->_navChain;
                    if ($this->_resetNavChain) {
                        $this->_navChain = '';
                    }
                } elseif ($this->_parent->getPlatform() === 'android') {
                    $headers['set_headers']['X-Ig-Nav-Chain'] = '1ne:feed_timeline:1:cold_start';
                } else {
                    $headers['set_headers']['X-Ig-Nav-Chain'] = 'IGMainFeedViewController:feed_timeline:1:cold_start:' . sprintf('%.6F',  microtime(true)) . '::';
                }
                if (!empty($this->_clientEndpoint)) {
                    $headers['set_headers']['X-Ig-Client-Endpoint'] = $this->_clientEndpoint;
                    if ($this->_resetClientEndpoint) {
                        $this->_clientEndpoint = 'IGMainFeedViewController:feed_timeline';
                    }
                } elseif ($this->_parent->getPlatform() === 'android') {
                    $headers['set_headers']['X-Ig-Client-Endpoint'] = '1ne:feed_timeline';
                } else {
                    $headers['set_headers']['X-Ig-Client-Endpoint'] = 'IGMainFeedViewController:feed_timeline';
                }
            }
            if ($this->_DS_USER_ID) {
                $headers['set_headers']['Ig-Intended-User-Id'] = $this->_DS_USER_ID;
            } else {
                $headers['set_headers']['Ig-Intended-User-Id'] = 0;
            }
            if ($this->_MID) {
                $headers['set_headers']['X-Mid'] = $this->_MID;
            } else {
                $headers['set_headers']['X-Mid'] = 0;
            }
            $headers['set_headers']['X-Fb-Rmd'] = 'cached=0;state=NO_MATCH';
            $headers['set_headers']['Priority'] = 'u=2, i';
        }

        if ($this->_parent->_needsAuth) {
            if ($this->_wwwClaim) {
                $headers['set_headers']['X-Ig-Www-Claim'] = $this->_wwwClaim;
            } else {
                $headers['set_headers']['X-Ig-Www-Claim'] = 0;
            }
        }

        // Content-Length header
        $body = (string) $request->getBody();
        if (strlen($body)) {
            $headers['set_headers']['Content-Length'] = strlen($body);
        }

        // Set up headers that are required for every request.
        // Compatibility with Guzzle v.7.4 and higher
        if (class_exists('\GuzzleHttp\Psr7\Utils') && method_exists('\GuzzleHttp\Psr7\Utils', 'modifyRequest')) {
            $request = \GuzzleHttp\Psr7\Utils::modifyRequest($request, $headers);
        } else {
            $request = modify_request($request, $headers);
        }
        
        // Check the Content-Type header for debugging.
        $contentType = $request->getHeader('content-type');
        $isFormData = count($contentType) && reset($contentType) === Constants::CONTENT_TYPE;

        $start = microtime(true);

        // Perform the API request.
        $response = $this->_apiRequest($request, $guzzleOptions, [
            'debugUploadedBody'  => $isFormData,
            'debugUploadedBytes' => !$isFormData,
        ]);

        if ($this->getIsAsyncRequest()) {
            $this->_parent->client->setIsAsyncRequest(false);
            return $response;
        }

        if ($response->hasHeader('X-Ig-Set-Www-Claim')) {
            $this->_wwwClaim = $response->getHeaderLine('X-Ig-Set-Www-Claim');
            if ($this->_wwwClaim !== $this->_parent->settings->get('x_ig_www_claim')) {
                $this->_parent->settings->set('x_ig_www_claim', $this->_wwwClaim); // This header should be stored
            }
        }

        if ($response->hasHeader('X-Ig-Set-X-Mid')) {
            $this->_MID = $response->getHeaderLine('X-Ig-Set-X-Mid');
            if ($this->_MID !== $this->_parent->settings->get('x_mid')) {
                $this->_parent->settings->set('x_mid', $this->_MID); // This header should be stored
            }
        }

        if (!$this->_parent->isWebLogin) {
            if ($response->hasHeader('Ig-Set-Authorization')) {
                $this->_authorization = $response->getHeaderLine('Ig-Set-Authorization');
                if ($this->_authorization !== $this->_parent->settings->get('authorization')) {
                    $this->_parent->settings->set('authorization', $this->_authorization); // This authorization token should be stored
                }
            }
            if ($response->hasHeader('Ig-Set-Ig-U-Ig-Direct-Region-Hint')) {
                $this->_DIRECT_REGION_HINT = $response->getHeaderLine('Ig-Set-Ig-U-Ig-Direct-Region-Hint');
                if ($this->_DIRECT_REGION_HINT !== $this->_parent->settings->get('direct_region_hint')) {
                    $this->_parent->settings->set('direct_region_hint', $this->_DIRECT_REGION_HINT); // This header should be stored
                }
            }
            if ($response->hasHeader('Ig-Set-Ig-U-Shbid')) {
                $this->_SHBID = $response->getHeaderLine('Ig-Set-Ig-U-Shbid');
                if ($this->_SHBID !== $this->_parent->settings->get('shbid')) {
                    $this->_parent->settings->set('shbid', $this->_SHBID); // This header should be stored
                }
            }
            if ($response->hasHeader('Ig-Set-Ig-U-Shbts')) {
                $this->_SHBTS = $response->getHeaderLine('Ig-Set-Ig-U-Shbts');
                if ($this->_SHBTS !== $this->_parent->settings->get('shbts')) {
                    $this->_parent->settings->set('shbts', $this->_SHBTS); // This header should be stored
                }
            }
            if ($response->hasHeader('Ig-Set-Ig-U-Ds-User-Id')) {
                $this->_DS_USER_ID = $response->getHeaderLine('Ig-Set-Ig-U-Ds-User-Id');
                if ($this->_DS_USER_ID !== $this->_parent->settings->get('ds_user_id')) {
                    $this->_parent->settings->set('ds_user_id', $this->_DS_USER_ID); // This header should be stored
                }
            }
            if ($response->hasHeader('Ig-Set-Ig-U-Rur')) {
                $this->_RUR = $response->getHeaderLine('Ig-Set-Ig-U-Rur');
                if ($this->_RUR !== $this->_parent->settings->get('rur')) {
                    $this->_parent->settings->set('rur', $this->_RUR); // This header should be stored
                }
            }
        }

        return $response;
    }

    /**
     * Decode a JSON reply from Instagram's API.
     *
     * WARNING: EXTREMELY IMPORTANT! NEVER, *EVER* USE THE BASIC "json_decode"
     * ON API REPLIES! ALWAYS USE THIS METHOD INSTEAD, TO ENSURE PROPER DECODING
     * OF BIG NUMBERS! OTHERWISE YOU'LL TRUNCATE VARIOUS INSTAGRAM API FIELDS!
     *
     * @param string $json  The body (JSON string) of the API response.
     * @param bool   $assoc When FALSE, decode to object instead of associative array.
     *
     * @return object|array|null Object if assoc false, Array if assoc true,
     *                           or NULL if unable to decode JSON.
     */
    public static function api_body_decode(
        $json,
        $assoc = true)
    {
        return @json_decode($json, $assoc, 512, JSON_BIGINT_AS_STRING);
    }

    /**
     * Get the cookies middleware instance.
     *
     * @return FakeCookies
     */
    public function fakeCookies()
    {
        return $this->_fakeCookies;
    }

    /**
     * Get the zero rating rewrite middleware instance.
     *
     * @return ZeroRating
     */
    public function zeroRating()
    {
        return $this->_zeroRating;
    }

    /**
     * Start Pigeon batch requests.
     */
    public function startEmulatingBatch()
    {
        $this->_pigeonBatch = true;
        $this->_pigeonTimestamp = microtime(true);
    }

    /**
     * Stop Pigeon batch requests.
     */
    public function stopEmulatingBatch()
    {
        $this->_pigeonBatch = false;
        $this->_pigeonTimestamp = null;
    }

    /**
     * Get Pigeon Client time.
     *
     * @return string
     */
    private function _getPigeonRawClientTime()
    {
        if ($this->_pigeonBatch === true) {
            $result = $this->_pigeonTimestamp;
            $this->_pigeonTimestamp += mt_rand(0, 100) / 1000;
        } else {
            $result = microtime(true);
        }

        return sprintf('%.6F', $result);
    }

    /**
     * Sets the last processed request.
     *
     * @param Request $endpoint The last processed request
     */
    public function setLastRequest(
        $endpoint)
    {
        $this->_lastRequest = $endpoint;
    }
    
    /**
     * Gets the last processed point.
     *
     * @return Request
     */
    public function getLastRequest()
    {
        return $this->_lastRequest;
    }
}
