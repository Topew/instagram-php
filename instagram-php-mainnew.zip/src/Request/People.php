<?php

namespace InstagramAPI\Request;

use InstagramAPI\Constants;
use InstagramAPI\Exception\RequestHeadersTooLargeException;
use InstagramAPI\Exception\ThrottledException;
use InstagramAPI\Exception\EmptyResponseException;
use InstagramAPI\Exception\InstagramException;
use InstagramAPI\Response;
use InstagramAPI\Utils;

/**
 * Functions related to finding, exploring and managing relations with people.
 */
class People extends RequestCollection
{
    /**
     * Get details about a specific user via their numerical UserPK ID.
     *
     * NOTE: The real app uses this particular endpoint for _all_ user lookups
     * except "@mentions" (where it uses `getInfoByName()` instead).
     *
     * @param string      $userId Numerical UserPK ID.
     * @param string|null $module From which app module (page) you have opened the profile. One of (incomplete):
     *                            "comments_v2_feed_contextual_chain",
     *                            "followers",
     *                            "following",
     *                            "likers",
     *                            "newsfeed_you",
     *                            "self_profile",
     *                            "self_followers",
     *                            "self_following",
     *                            "self_likers",
     *                            "search_typeahead",
     *                            "feed_contextual_chain"
     *
     * @throws \InstagramAPI\Exception\InstagramException
     *
     * @return \InstagramAPI\Response\UserInfoResponse
     */
    public function getInfoById(
        $userId,
        $module = 'search_typeahead',
        $no_auth = true)
    {
        if ($userId == $this->ig->account_id) {
            $current_user = $this->ig->account->getCurrentUser();
            $array = !empty($current_user->getUser()) ? json_decode(json_encode($current_user->getUser()), true) : [];
            $user = new Response\Model\User($array);
            
            // Switch to fake Instagram client
            $username = $this->ig->username;
            $this->ig->setUserWithoutPassword($username . "_fake_session");

            // New safe way to get self user info for main account
            try {
                $resp = $this->getInfoByNameWeb($username, false);
            } catch (EmptyResponseException $e) {
                // Compatibility with IP rotation feature in Proxy Manager Pro module
                if (function_exists("\Plugins\ProxyManagerPro\changeIp")) {
                    \Plugins\ProxyManagerPro\changeIp($this->ig->getProxy());
                    sleep(10);
                    try {
                        $resp = $this->getInfoByNameWeb($username, false);
                    } catch (InstagramException $e) {
                    } catch (\Exception $e) {
                    }
                } elseif (!empty($this->ig->getRotationLink())) {
                    $this->ig->changeIp($this->ig->getRotationLink());
                    sleep(10);
                    try {
                        $resp = $this->getInfoByNameWeb($username, false);
                    } catch (InstagramException $e) {
                    } catch (\Exception $e) {
                    }
                }
            } catch (InstagramException $e) {
            } catch (\Exception $e) {
            }

            // Switch back to normal Instagram client
            $this->ig->changeUser($username, $this->ig->password);
            $this->ig->settings->deleteUser($username . "_fake_session");

            if (!empty($resp) && !empty($resp->getData())) {
                if ($resp->getData()->hasUser()) {
                    $user_data = $resp->getData()->getUser();
                    if (!empty($user_data) && $user_data->hasUsername() && $user_data->hasProfilePicUrl()) {
                        // $user = new Response\Model\User();
                        // $user->setPk($user_data->hasId() && $user_data->getId() ? $user_data->getId() : "")
                        //      ->setUsername($user_data->hasUsername() && $user_data->getUsername() ? $user_data->getUsername() : "")
                        //      ->setFullName($user_data->hasFullName() && $user_data->getFullName() ? $user_data->getFullName() : "")
                        //      ->setIsPrivate($user_data->hasIsPrivate() && $user_data->getIsPrivate() ? $user_data->getIsPrivate() : false)
                        //      ->setPkId($user_data->hasId() && $user_data->getId() ? $user_data->getId() : "")
                        //      ->setProfilePicUrl($user_data->hasProfilePicUrl() && $user_data->getProfilePicUrl() ? $user_data->getProfilePicUrl() : "")
                        //      ->setIsVerified($user_data->hasIsVerified() && $user_data->getIsVerified() ? $user_data->getIsVerified() : false)
                        //      ->setMediaCount(($user_data->hasEdgeOwnerToTimelineMedia() && isset($user_data->getEdgeOwnerToTimelineMedia()['count'])) ? $user_data->getEdgeOwnerToTimelineMedia()['count'] : 0)
                        //      ->setFollowerCount(($user_data->hasEdgeFollowedBy() && isset($user_data->getEdgeFollowedBy()['count'])) ? $user_data->getEdgeFollowedBy()['count'] : 0)
                        //      ->setFollowingCount(($user_data->hasEdgeFollow() && isset($user_data->getEdgeFollow()['count'])) ? $user_data->getEdgeFollow()['count'] : 0)
                        //      ->setBiography($user_data->hasBiography() ? $user_data->getBiography() : "")
                        //      ->setExternalUrl($user_data->hasExternalUrl() ? $user_data->getExternalUrl() : "")
                        //      ->setExternalLynxUrl($user_data->hasExternalUrlLinkshimmed() ? $user_data->getExternalUrlLinkshimmed() : "");
                        // $response = new Response\UserInfoResponse();
                        // $response->setUser($user);
                        $user->setMediaCount(($user_data->hasEdgeOwnerToTimelineMedia() && isset($user_data->getEdgeOwnerToTimelineMedia()['count'])) ? $user_data->getEdgeOwnerToTimelineMedia()['count'] : 0)
                             ->setFollowerCount(($user_data->hasEdgeFollowedBy() && isset($user_data->getEdgeFollowedBy()['count'])) ? $user_data->getEdgeFollowedBy()['count'] : 0)
                             ->setFollowingCount(($user_data->hasEdgeFollow() && isset($user_data->getEdgeFollow()['count'])) ? $user_data->getEdgeFollow()['count'] : 0);
                    }
                }
            }

            $response = new Response\UserInfoResponse();
            $response->setUser($user);
            return $response;
        } else {

            /**
             * getInfoById() endpoint are disabled by default for another accounts info.
             * 
             * 1. You can only use this feature for your account info.
             * 2. It is currently not possible to securely obtain any information about another users. 
             * 3. We are working on alternatives and will try to add more ways to do this in future versions of the API, but at the moment this feature is very risky for accounts.
             */

            if (!$this->ig->allowDangerousGetInfoByIdUsage) {
                throw new \InstagramAPI\Exception\InstagramException("Requests to the getInfoById() endpoint are disabled by default. You can only use this feature for your account info. It is currently not possible to securely obtain any information about another users. We are working on alternatives and will try to add more ways to do this in future versions of the API, but at the moment this feature is very risky for accounts.");
            } else {
                if ($this->ig->getPlatform() === 'ios') {
                    $nav_chain = 'IGMainFeedViewController:feed_timeline:1:cold_start:' . sprintf('%.6F',  microtime(true)) . '::';
                } else {
                    $nav_chain = 'MainFeedFragment:feed_timeline:1:cold_start:0.0::';
                }
                if (empty($this->ig->client->_navChain)) {
                    $this->ig->setNavChainHeader($nav_chain, true);
                }

                $request = $this->ig->request("users/{$userId}/info/")
                    ->addParam('device_id', $this->ig->device_id);

                if ($userId == $this->ig->account_id) {
                    $request->addParam('entry_point', 'self_profile');
                } else {
                    $request->addParam('entry_point', 'profile');
                    if ($module !== null) {
                        $request->addParam('from_module', $module);
                    }
                }

                return $request->getResponse(new Response\UserInfoResponse());
            }
        }
    }

    /**
     * Get details about a specific user via their numerical UserPK ID with web API
     *
     */
    public function getInfoByIdWeb(
        $userId) 
    {
        $request = $this->ig->request("users/{$userId}/info/")
            ->setAddDefaultHeaders(false)
            ->setSignedPost(false)
            ->addHeader('Origin', 'https://www.instagram.com')
            ->addHeader('Referer', 'https://www.instagram.com/')
            ->addHeader('X-Ig-App-Id', Constants::IG_WEB_APPLICATION_ID);
        
        if ($this->ig->getIsAndroid()) {
            $request->addHeader('User-Agent', sprintf('Mozilla/5.0 (Linux; Android %s; Google) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Mobile Safari/537.36', $this->ig->device->getAndroidRelease()));
        } else {
            $request->addHeader('User-Agent', 'Mozilla/5.0 (iPhone; CPU iPhone OS ' . Constants::IOS_VERSION . ' like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.4 Mobile/15E148 Safari/604.1');
        }

        return $request->getResponse(new Response\UserInfoResponse());
    }

    /**
     * Get details about a specific user via their username.
     *
     * NOTE: The real app only uses this endpoint for profiles opened via "@mentions".
     *
     * @param string $username Username as string (NOT as a numerical ID).
     * @param string $module   From which app module (page) you have opened the profile.
     *
     * @throws \InstagramAPI\Exception\InstagramException
     *
     * @return \InstagramAPI\Response\UserInfoResponse
     *
     * @see People::getInfoById() For the list of supported modules.
     */
    public function getInfoByName(
        $username,
        $module = 'feed_timeline')
    {
        return $this->ig->request("users/{$username}/usernameinfo/")
            ->addParam('from_module', $module)
            ->getResponse(new Response\UserInfoResponse());
    }

    /**
     * Get details about a specific user via their username with Web API
     *
     * @param string $name           Username as string (NOT as a numerical ID).
     * @param string $username       Username of slave account as string (NOT as a numerical ID). With which you get info about $username_about.
     * @param bool   $is_auth_needed Whenever account is authorized or not
     *
     * @throws \InvalidArgumentException
     * @throws \InstagramAPI\Exception\InstagramException
     *
     * @return \InstagramAPI\Response\GraphqlResponse
     */
    public function getInfoByNameWeb(
        $name,
        $auth = true)
    {
        $req = $this->ig->request("users/web_profile_info/")
            ->addParam('username', $name);

        if (!$auth) {
            $req->setNeedsAuth(false);
        }

        return $req->getResponse(new Response\GraphqlResponse());
    } 

    /**
     * Get the numerical UserPK ID for a specific user via their username.
     *
     * This is just a convenient helper function. You may prefer to use
     * People::getInfoByName() instead, which lets you see more details.
     *
     * @param string $username Username as string (NOT as a numerical ID).
     *
     * @throws \InstagramAPI\Exception\InstagramException
     *
     * @return string Their numerical UserPK ID.
     *
     * @see People::getInfoByName()
     */
    public function getUserIdForName(
        $username)
    {
        return $this->getInfoByName($username)->getUser()->getPk();
    }

    /**
     * Get user details about your own account.
     *
     * Also try Account::getCurrentUser() instead, for account details.
     *
     * @throws \InstagramAPI\Exception\InstagramException
     *
     * @return \InstagramAPI\Response\UserInfoResponse
     *
     * @see Account::getCurrentUser()
     */
    public function getSelfInfo()
    {
        return $this->getInfoById($this->ig->account_id, "self_profile");
    }

     /**
     * Get about this account info.
     *
     * This is only valid for verified accounts.
     *
     * @param string $userId Numerical UserPK ID.
     *
     * @throws \InstagramAPI\Exception\InstagramException
     *
     * @return \InstagramAPI\Response\AboutThisAccountResponse
     */
    public function getAboutThisAccountInfo(
        $userId)
    {
        $req = $this->ig->request('bloks/apps/com.instagram.interactions.about_this_account/')
            ->addPost('_uuid', $this->ig->uuid)
            ->addPost('target_user_id', $userId);

        if ($this->ig->getPlatform() === 'ios') {
            $req->addPost('bloks_versioning_id', Constants::IOS_BLOCKS_VERSIONING_ID);
        } else {
            $req->addPost('bloks_versioning_id', Constants::BLOCK_VERSIONING_ID);
        }

        return $req->getResponse(new Response\AboutThisAccountResponse());
    }

    /**
     * Get other people's recent activities related to you and your posts.
     *
     * This feed has information about when people interact with you, such as
     * liking your posts, commenting on your posts, tagging you in photos or in
     * comments, people who started following you, etc.
     *
     * @param bool $prefetch Indicates if request is called due to prefetch.
     *
     * @throws \InstagramAPI\Exception\InstagramException
     *
     * @return \InstagramAPI\Response\ActivityNewsResponse
     */
    public function getRecentActivityInbox(
        $prefetch = false,
        $next_max_id = null,
        $selected_filters = '')
    {
        $request = $this->ig->request('news/inbox/')
            ->addParam('mark_as_seen', false)
            ->addParam('timezone_offset', (!empty($this->ig->getTimezoneOffset())) ? $this->ig->getTimezoneOffset() : date('Z'));
        if ($prefetch) {
            $request->addHeader('X-IG-Prefetch-Request', 'foreground');
        }
        if ($next_max_id) {
            $request->addParam('next_max_id', $next_max_id);
        }
        if (!empty($selected_filters)) {
            $request->addParam('selected_filters', $selected_filters);
        }

        return $request->getResponse(new Response\ActivityNewsResponse());
    }

    /**
     * Send action news log.
     *
     * @param $newsPk   The news PK. Example: "t+g+XAtK5RaGUdeQeL/V5roIgEM="
     * @param $tuuid    The news UUID.
     *
     * @throws \InstagramAPI\Exception\InstagramException
     *
     * @return \InstagramAPI\Response\GenericResponse
     */
    public function sendNewsLog(
        $newsPk,
        $tuuid)
    {
        return $this->ig->request('news/log/')
            ->setSignedPost(false)
            ->addPost('action', 'click')
            ->addPost('pk', $newsPk)
            ->addPost('tuuid', $tuuid)
            ->addPost('_uuid', $this->ig->uuid)
            ->getResponse(new Response\GenericResponse());
    }

    /**
     * Get news feed with recent activities by accounts you follow.
     *
     * This feed has information about the people you follow, such as what posts
     * they've liked or that they've started following other people.
     *
     * @param string|null $maxId Next "maximum ID", used for pagination.
     *
     * @throws \InstagramAPI\Exception\InstagramException
     *
     * @return \InstagramAPI\Response\FollowingRecentActivityResponse
     */
    public function getFollowingRecentActivity(
        $maxId = null)
    {
        $activity = $this->ig->request('news/');
        if ($maxId !== null) {
            $activity->addParam('max_id', $maxId);
        }

        return $activity->checkDeprecatedVersion('114.0.0.13.120')
            ->getResponse(new Response\FollowingRecentActivityResponse());
    }

    /**
     * Retrieve bootstrap user data (autocompletion user list).
     *
     * WARNING: This is a special, very heavily throttled API endpoint.
     * Instagram REQUIRES that you wait several minutes between calls to it.
     *
     * @throws \InstagramAPI\Exception\InstagramException
     *
     * @return \InstagramAPI\Response\BootstrapUsersResponse|null Will be NULL if throttled by Instagram.
     */
    public function getBootstrapUsers()
    {
        $surfaces = [
            'coefficient_ios_section_test_bootstrap_ranking',
            'coefficient_besties_list_ranking',
            'coefficient_rank_recipient_user_suggestion',
            'autocomplete_user_list'
        ];

        try {
            $request = $this->ig->request('scores/bootstrap/users/')
                ->addParam('surfaces', json_encode($surfaces));

            return $request->getResponse(new Response\BootstrapUsersResponse());
        } catch (ThrottledException $e) {
            // Throttling is so common that we'll simply return NULL in that case.
            return null;
        }
    }

    /**
     * Show a user's friendship status with you.
     *
     * @param string $userId Numerical UserPK ID.
     *
     * @throws \InstagramAPI\Exception\InstagramException
     *
     * @return \InstagramAPI\Response\FriendshipsShowResponse
     */
    public function getFriendship(
        $userId)
    {
        return $this->ig->request("friendships/show/{$userId}/")->getResponse(new Response\FriendshipsShowResponse());
    }

    /**
     * Show multiple users' friendship status with you.
     *
     * @param string|string[] $userList List of numerical UserPK IDs.
     *
     * @throws \InstagramAPI\Exception\InstagramException
     *
     * @return \InstagramAPI\Response\FriendshipsShowManyResponse
     */
    public function getFriendships(
        $userList)
    {
        if (is_array($userList)) {
            $userList = implode(',', $userList);
        }

        return $this->ig->request('friendships/show_many/')
            ->setSignedPost(false)
            ->addPost('_uuid', $this->ig->uuid)
            ->addPost('user_ids', $userList)
            ->getResponse(new Response\FriendshipsShowManyResponse());
    }

    /**
     * Get list of pending friendship requests.
     *
     * @throws \InstagramAPI\Exception\InstagramException
     *
     * @return \InstagramAPI\Response\FollowerAndFollowingResponse
     */
    public function getPendingFriendships()
    {
        $request = $this->ig->request('friendships/pending/');

        return $request->getResponse(new Response\FollowerAndFollowingResponse());
    }

    /**
     * Approve a friendship request.
     *
     * @param string $userId Numerical UserPK ID.
     *
     * @throws \InstagramAPI\Exception\InstagramException
     *
     * @return \InstagramAPI\Response\FriendshipResponse
     */
    public function approveFriendship(
        $userId)
    {
        return $this->ig->request("friendships/approve/{$userId}/")
            ->addPost('_uuid', $this->ig->uuid)
            ->addPost('_uid', $this->ig->account_id)
            ->addPost('user_id', $userId)
            ->addPost('radio_type', $this->ig->radio_type)
            ->getResponse(new Response\FriendshipResponse());
    }

    /**
     * Reject a friendship request.
     *
     * Note that the user can simply send you a new request again, after your
     * rejection. If they're harassing you, use People::block() instead.
     *
     * @param string $userId Numerical UserPK ID.
     *
     * @throws \InstagramAPI\Exception\InstagramException
     *
     * @return \InstagramAPI\Response\FriendshipResponse
     */
    public function rejectFriendship(
        $userId)
    {
        return $this->ig->request("friendships/ignore/{$userId}/")
            ->addPost('_uuid', $this->ig->uuid)
            ->addPost('_uid', $this->ig->account_id)
            ->addPost('user_id', $userId)
            ->addPost('radio_type', $this->ig->radio_type)
            ->getResponse(new Response\FriendshipResponse());
    }

    /**
     * Remove one of your followers.
     *
     * @param string $userId Numerical UserPK ID.
     *
     * @throws \InstagramAPI\Exception\InstagramException
     *
     * @return \InstagramAPI\Response\FriendshipResponse
     */
    public function removeFollower(
        $userId)
    {
        return $this->ig->request("friendships/remove_follower/{$userId}/")
            ->addPost('_uuid', $this->ig->uuid)
            ->addPost('_uid', $this->ig->account_id)
            ->addPost('user_id', $userId)
            ->addPost('radio_type', $this->ig->radio_type)
            ->getResponse(new Response\FriendshipResponse());
    }

    /**
     * Mark user over age in order to see sensitive content.
     *
     * @param string $userId Numerical UserPK ID.
     *
     * @throws \InstagramAPI\Exception\InstagramException
     *
     * @return \InstagramAPI\Response\FriendshipResponse
     */
    public function markUserOverage(
        $userId)
    {
        return $this->ig->request("friendships/mark_user_overage/{$userId}/feed/")
            ->addPost('_uuid', $this->ig->uuid)
            ->addPost('_uid', $this->ig->account_id)
            ->addPost('user_id', $userId)
            ->getResponse(new Response\FriendshipResponse());
    }

    /**
     * Get list of who a user is following.
     *
     * @param string      $userId         Numerical UserPK ID.
     * @param string      $rankToken      The list UUID. You must use the same value for all pages of the list.
     * @param string|null $searchQuery    Limit the userlist to ones matching the query.
     * @param string|null $maxId          Next "maximum ID", used for pagination.
     * @param string|null $order          Search order. Latest followings: 'date_followed_earliest',
     *                                    earliest followings: 'date_followed_earliest'.
     * @param string      $search_surface 
     * @param bool        $enable_groups 
     *
     * @throws \InvalidArgumentException
     * @throws \InstagramAPI\Exception\InstagramException
     *
     * @return \InstagramAPI\Response\FollowerAndFollowingResponse
     *
     * @see Signatures::generateUUID() To create a UUID.
     * @see examples/rankTokenUsage.php For an example.
     */
    public function getFollowing(
        $userId,
        $rankToken,
        $searchQuery = null,
        $maxId = null,
        $order = null,
        $search_surface = 'follow_list_page',
        $enable_groups = true)
    {
        Utils::throwIfInvalidRankToken($rankToken);
        $request = $this->ig->request("friendships/{$userId}/following/")
            ->addParam('includes_hashtags', true)
            ->addParam('rank_token', $rankToken)
            ->addParam('target_id', $userId)
            ->addParam('search_surface', $search_surface)
            ->addParam('enable_groups', $enable_groups);
        if ($order !== null) {
            if ($order !== 'date_followed_earliest' && $order !== 'date_followed_latest') {
                throw new \InvalidArgumentException('Invalid order type.');
            }
            $request->addParam('order', $order);
        }
        if ($searchQuery !== null) {
            $request->addParam('query', $searchQuery);
        }
        if ($maxId !== null) {
            $request->addParam('max_id', $maxId);
        }

        return $request->getResponse(new Response\FollowerAndFollowingResponse());
    }

    /**
     * Get list of who a user is followed by.
     *
     * @param string      $userId         Numerical UserPK ID.
     * @param string      $rankToken      The list UUID. You must use the same value for all pages of the list.
     * @param string|null $searchQuery    Limit the userlist to ones matching the query.
     * @param string|null $maxId          Next "maximum ID", used for pagination.
     * @param string      $order          Search order.
     * @param string      $search_surface 
     * @param bool        $enable_groups 
     *
     * @throws \InvalidArgumentException
     * @throws \InstagramAPI\Exception\InstagramException
     *
     * @return \InstagramAPI\Response\FollowerAndFollowingResponse
     *
     * @see Signatures::generateUUID() To create a UUID.
     * @see examples/rankTokenUsage.php For an example.
     */
    public function getFollowers(
        $userId,
        $rankToken,
        $searchQuery = null,
        $maxId = null,
        $order = 'default',
        $search_surface = 'follow_list_page',
        $enable_groups = true)
    {
        Utils::throwIfInvalidRankToken($rankToken); 
        $request = $this->ig->request("friendships/{$userId}/followers/")
            ->addParam('rank_token', $rankToken)
            ->addParam('target_id', $userId)
            ->addParam('rank_mutual', 0)
            ->addParam('order', $order)
            ->addParam('search_surface', $search_surface)
            ->addParam('enable_groups', $enable_groups);
        if ($searchQuery !== null) {
            $request->addParam('query', $searchQuery);
        }
        if ($maxId !== null) {
            $request->addParam('max_id', $maxId);
        }

        return $request->getResponse(new Response\FollowerAndFollowingResponse());
    }

    /**
     * Get list of who a user is followed with web API
     *
     * @param string      $userId        Numerical UserPK ID.
     * @param int         $next_page     Limit the userlist.
     * @param string|null $end_cursor    Next "maximum ID", used for pagination.
     * @param bool        $include_reel  Include stories reels in response
     *
     * @throws \InvalidArgumentException
     * @throws \InstagramAPI\Exception\InstagramException
     *
     * @return \InstagramAPI\Response\GraphqlResponse
     */
    public function getFollowersGraph(
        $userId,
        $next_page = 48,
        $end_cursor = null,
        $include_reel = false,
        $username = "",
        $query_hash = "5aefa9893005572d237da5068082d8d5")
    {
        if ($userId == null) {
            throw new \InvalidArgumentException('Empty $userId sent to getFollowersGraph() function.');
        }

        $request = $this->ig->request("graphql/query/")
            ->setVersion(5)
            ->setAddDefaultHeaders(false)
            ->setSignedPost(false);

            if (!empty($username)) {
                $request->addHeader('Referer', 'https://www.instagram.com/' . $username . '/followers/');
            } else {
                $request->addHeader('Referer', 'https://www.instagram.com/');
            }

            $request->addParam('query_hash', $query_hash)
                    ->addParam('variables', json_encode([
                        "id" => $userId,
                        "include_reel" => $include_reel ? true : false,
                        "fetch_mutual" => false,
                        "first" => $next_page,
                        "after" => $end_cursor,
                    ]));
        return $request->getResponse(new Response\GraphqlResponse());
    }

    /**
     * Get list of who a user is following with web API
     *
     * @param string      $userId        Numerical UserPK ID.
     * @param int         $next_page     Limit the userlist.
     * @param string|null $end_cursor    Next "maximum ID", used for pagination.
     * @param bool        $include_reel  Include stories reels in response
     *
     * @throws \InvalidArgumentException
     * @throws \InstagramAPI\Exception\InstagramException
     *
     * @return \InstagramAPI\Response\GraphqlResponse
     */
    public function getFollowingGraph(
        $userId,
        $next_page = 48,
        $end_cursor = null,
        $include_reel = false,
        $username = "",
        $query_hash = "3dec7e2c57367ef3da3d987d89f9dbc8")
    {
        if ($userId == null) {
            throw new \InvalidArgumentException('Empty $userId sent to getFollowingGraph() function.');
        }

        $request = $this->ig->request("graphql/query/")
            ->setVersion(5)
            ->setAddDefaultHeaders(false)
            ->setSignedPost(false);

            if (!empty($username)) {
                $request->addHeader('Referer', 'https://www.instagram.com/' . $username . '/following/');
            } else {
                $request->addHeader('Referer', 'https://www.instagram.com/');
            }

            $request->addParam('query_hash', $query_hash)
                    ->addParam('variables', json_encode([
                        "id" => $userId,
                        "include_reel" => $include_reel ? true : false,
                        "fetch_mutual" => false,
                        "first" => $next_page,
                        "after" => $end_cursor,
                    ]));
        return $request->getResponse(new Response\GraphqlResponse());
    }

    /**
     * Get list of who a user is followed with web API (v2, just name changed for compatibility)
     *
     * @param string      $userId        Numerical UserPK ID.
     * @param int         $next_page     Limit the userlist.
     * @param string|null $end_cursor    Next "maximum ID", used for pagination.
     * @param bool        $include_reel  Include stories reels in response
     *
     * @throws \InvalidArgumentException
     * @throws \InstagramAPI\Exception\InstagramException
     *
     * @return \InstagramAPI\Response\GraphqlResponse
     */
    public function getFollowerWeb(
        $userId,
        $next_page = null,
        $end_cursor = null,
        $include_reel = true)
    {
        if ($userId == null) {
            throw new \InvalidArgumentException('Empty $userId sent to getFollowersGraph() function.');
        }

        return $request = $this->ig->request("graphql/query/")
            ->setVersion(5)
            ->setAddDefaultHeaders(false)
            ->setSignedPost(false)
            ->addParam('query_hash', 'c76146de99bb02f6415203be841dd25a')
            ->addParam('variables', json_encode([
                "id" => $userId,
                "include_reel" => $include_reel ? true : false,
                "fetch_mutual" => false,
                "first" => ($next_page !== null) ? $next_page : 50,
                "after" => $end_cursor,
            ]))
            ->getResponse(new Response\GraphqlResponse());
    }

    /**
     * Get list of who you are following.
     *
     * @param string      $rankToken   The list UUID. You must use the same value for all pages of the list.
     * @param string|null $searchQuery Limit the userlist to ones matching the query.
     * @param string|null $maxId       Next "maximum ID", used for pagination.
     * @param string|null $order       Search order. Latest followings: 'date_followed_earliest',
     *                                 earliest followings: 'date_followed_earliest'.
     *
     * @throws \InstagramAPI\Exception\InstagramException
     *
     * @return \InstagramAPI\Response\FollowerAndFollowingResponse
     *
     * @see Signatures::generateUUID() To create a UUID.
     * @see examples/rankTokenUsage.php For an example.
     */
    public function getSelfFollowing(
        $rankToken,
        $searchQuery = null,
        $maxId = null,
        $order = null)
    {
        return $this->getFollowing($this->ig->account_id, $rankToken, $searchQuery, $maxId, $order);
    }

    /**
     * Get list of your own followers.
     *
     * @param string      $rankToken   The list UUID. You must use the same value for all pages of the list.
     * @param string|null $searchQuery Limit the userlist to ones matching the query.
     * @param string|null $maxId       Next "maximum ID", used for pagination.
     *
     * @throws \InstagramAPI\Exception\InstagramException
     *
     * @return \InstagramAPI\Response\FollowerAndFollowingResponse
     *
     * @see Signatures::generateUUID() To create a UUID.
     * @see examples/rankTokenUsage.php For an example.
     */
    public function getSelfFollowers(
        $rankToken,
        $searchQuery = null,
        $maxId = null)
    {
        return $this->getFollowers($this->ig->account_id, $rankToken, $searchQuery, $maxId);
    }

    /**
     * Search for Instagram users.
     *
     * @param string         $query       The username or full name to search for.
     * @param string[]|int[] $excludeList Array of numerical user IDs (ie "4021088339")
     *                                    to exclude from the response, allowing you to skip users
     *                                    from a previous call to get more results.
     * @param string|null    $rankToken   A rank token from a first call response.
     *
     * @throws \InvalidArgumentException                  If invalid query or
     *                                                    trying to exclude too
     *                                                    many user IDs.
     * @throws \InstagramAPI\Exception\InstagramException
     *
     * @return \InstagramAPI\Response\SearchUserResponse
     *
     * @see SearchUserResponse::getRankToken() To get a rank token from the response.
     * @see examples/paginateWithExclusion.php For an example.
     */
    public function search(
        $query,
        array $excludeList = [],
        $rankToken = null)
    {
        // Do basic query validation.
        if (!is_string($query) || $query === '') {
            throw new \InvalidArgumentException('Query must be a non-empty string.');
        }

        $request = $this->_paginateWithExclusion(
            $this->ig->request('users/search/')
                ->addParam('q', $query)
                ->addParam('timezone_offset', (!empty($this->ig->getTimezoneOffset())) ? $this->ig->getTimezoneOffset() : date('Z'))
                ->addParam('search_surface', 'user_search_page')
                ->addParam('count', 30),
            $excludeList,
            $rankToken
        );

        try {
            /** @var Response\SearchUserResponse $result */
            $result = $request->getResponse(new Response\SearchUserResponse());
        } catch (RequestHeadersTooLargeException $e) {
            $result = new Response\SearchUserResponse([
                'has_more'    => false,
                'num_results' => 0,
                'users'       => [],
                'rank_token'  => $rankToken,
            ]);
        }

        return $result;
    }

    /**
     * Get business account details.
     *
     * @param string $userId Numerical UserPK ID.
     *
     * @throws \InstagramAPI\Exception\InstagramException
     *
     * @return \InstagramAPI\Response\AccountDetailsResponse
     */
    public function getAccountDetails(
        $userId)
    {
        return $this->ig->request("users/{$userId}/account_details/")
            ->getResponse(new Response\AccountDetailsResponse());
    }

    /**
     * Get a business account's former username(s).
     *
     * @param string $userId Numerical UserPK ID.
     *
     * @throws \InstagramAPI\Exception\InstagramException
     *
     * @return \InstagramAPI\Response\FormerUsernamesResponse
     */
    public function getFormerUsernames(
        $userId)
    {
        return $this->ig->request("users/{$userId}/former_usernames/")
            ->getResponse(new Response\FormerUsernamesResponse());
    }

    /**
     * Get a business account's shared follower base with similar accounts.
     *
     * @param string $userId Numerical UserPk ID.
     *
     * @throws \InstagramAPI\Exception\InstagramException
     *
     * @return \InstagramAPI\Response\SharedFollowersResponse
     */
    public function getSharedFollowers(
        $userId)
    {
        return $this->ig->request("users/{$userId}/shared_follower_accounts/")
            ->getResponse(new Response\SharedFollowersResponse());
    }

    /**
     * Get a business account's active ads on feed.
     *
     * @param string      $targetUserId Numerical UserPk ID.
     * @param string|null $maxId        Next "maximum ID", used for pagination.
     *
     * @throws \InstagramAPI\Exception\InstagramException
     *
     * @return \InstagramAPI\Response\ActiveFeedAdsResponse
     */
    public function getActiveFeedAds(
        $targetUserId,
        $maxId = null)
    {
        return $this->_getActiveAds($targetUserId, '35', $maxId);
    }

    /**
     * Get a business account's active ads on stories.
     *
     * @param string      $targetUserId Numerical UserPk ID.
     * @param string|null $maxId        Next "maximum ID", used for pagination.
     *
     * @throws \InstagramAPI\Exception\InstagramException
     *
     * @return \InstagramAPI\Response\ActiveReelAdsResponse
     */
    public function getActiveStoryAds(
        $targetUserId,
        $maxId = null)
    {
        return $this->_getActiveAds($targetUserId, '49', $maxId);
    }

    /**
     * Helper function for getting active ads for business accounts.
     *
     * @param string      $targetUserId Numerical UserPk ID.
     * @param string      $pageType     Content-type id(?) of the ad. 35 is feed ads and 49 is story ads.
     * @param string|null $maxId        Next "maximum ID", used for pagination.
     *
     * @throws \InvalidArgumentException
     * @throws \InstagramAPI\Exception\InstagramException
     *
     * @return Response
     */
    protected function _getActiveAds(
        $targetUserId,
        $pageType,
        $maxId = null)
    {
        $request = $this->ig->request('ads/view_ads/')
            ->setSignedPost(false)
            ->addPost('_uuid', $this->ig->uuid)
            ->addPost('target_user_id', $targetUserId)
            ->addPost('page_type', $pageType);
        if ($maxId !== null) {
            $request->addPost('next_max_id', $maxId);
        }
        $request->addPost('ig_user_id', $this->ig->account_id);

        switch ($pageType) {
            case '35':
                return $request->getResponse(new Response\ActiveFeedAdsResponse());
                break;
            case '49':
                return $request->getResponse(new Response\ActiveReelAdsResponse());
                break;
            default:
                throw new \InvalidArgumentException('Invalid page type.');
        }
    }

    /**
     * Search for users by linking your address book to Instagram.
     *
     * WARNING: You must unlink your current address book before you can link
     * another one to search again, otherwise you will just keep getting the
     * same response about your currently linked address book every time!
     *
     * @param array  $contacts
     * @param string $module
     *
     * @throws \InstagramAPI\Exception\InstagramException
     *
     * @return \InstagramAPI\Response\LinkAddressBookResponse
     *
     * @see People::unlinkAddressBook()
     */
    public function linkAddressBook(
        array $contacts,
        $module = 'find_friends_contacts')
    {
        return $this->ig->request('address_book/link/')
            ->setSignedPost(false)
            ->setIsBodyCompressed(true)
            ->addPost('phone_id', $this->ig->phone_id)
            ->addPost('module', $module)
            ->addPost('contacts', json_encode($contacts))
            ->addPost('device_id', $this->ig->device_id)
            ->addPost('_uuid', $this->ig->uuid)
            ->getResponse(new Response\LinkAddressBookResponse());
    }

    /**
     * Unlink your address book from Instagram.
     *
     * @throws \InstagramAPI\Exception\InstagramException
     *
     * @return \InstagramAPI\Response\UnlinkAddressBookResponse
     */
    public function unlinkAddressBook()
    {
        return $this->ig->request('address_book/unlink/')
            ->addPost('user_initiated', 'true')
            ->addPost('phone_id', $this->ig->phone_id)
            ->addPost('device_id', $this->ig->device_id)
            ->addPost('_uuid', $this->ig->uuid)
            ->addPost('_uid', $this->ig->account_id)
            ->getResponse(new Response\UnlinkAddressBookResponse());
    }

    /**
     * Discover new people via Facebook's algorithm.
     *
     * This matches you with other people using multiple algorithms such as
     * "friends of friends", "location", "people using similar hashtags", etc.
     *
     * @param string|null $maxId Next "maximum ID", used for pagination.
     *
     * @throws \InstagramAPI\Exception\InstagramException
     *
     * @return \InstagramAPI\Response\DiscoverPeopleResponse
     */
    public function discoverPeople(
        $maxId = null)
    {
        $request = $this->ig->request('discover/ayml/')
            ->setSignedPost(false)
            ->addPost('phone_id', $this->ig->phone_id)
            ->addPost('module', 'discover_people')
            ->addPost('_uuid', $this->ig->uuid)
            ->addPost('paginate', true);

        if ($maxId !== null) {
            $request->addPost('max_id', $maxId);
        }

        return $request->getResponse(new Response\DiscoverPeopleResponse());
    }

    /**
     * Get suggested users related to a user.
     *
     * @param string $userId Numerical UserPK ID.
     *
     * @throws \InstagramAPI\Exception\InstagramException
     *
     * @return \InstagramAPI\Response\SuggestedUsersResponse
     */
    public function getSuggestedUsers(
        $userId)
    {
        return $this->ig->request('discover/chaining/')
            ->addParam('target_id', $userId)
            ->getResponse(new Response\SuggestedUsersResponse());
    }

    /**
     * Get suggested users via account badge.
     *
     * @param string|null $module (optional) From which app module (page) accesed.
     *
     * This is the endpoint for when you press the "user icon with the plus
     * sign" on your own profile in the Instagram app. Its amount of suggestions
     * matches the number on the badge, and it usually only has a handful (1-4).
     *
     * @throws \InstagramAPI\Exception\InstagramException
     *
     * @return \InstagramAPI\Response\SuggestedUsersBadgeResponse
     */
    public function getSuggestedUsersBadge(
        $module = 'discover_people')
    {
        $request = $this->ig->request('discover/profile_su_badge/')
            ->addPost('_uuid', $this->ig->uuid);

        if ($module !== null) {
            $request->addPost('module', $module);
        }

        return $request->getResponse(new Response\SuggestedUsersBadgeResponse());
    }

    /**
     * Hide suggested user, so that they won't be suggested again.
     *
     * You must provide the correct algorithm for the user you want to hide,
     * which can be seen in their "algorithm" value in People::discoverPeople().
     *
     * Here is a probably-outdated list of algorithms and their meanings:
     *
     * - realtime_chaining_algorithm = ?
     * - realtime_chaining_ig_coeff_algorithm = ?
     * - tfidf_city_algorithm = Popular people near you.
     * - hashtag_interest_algorithm = Popular people on similar hashtags as you.
     * - second_order_followers_algorithm = Popular.
     * - super_users_algorithm = Popular.
     * - followers_algorithm = Follows you.
     * - ig_friends_of_friends_from_tao_laser_algorithm = ?
     * - page_rank_algorithm = ?
     *
     * TODO: Do more research about this function and document it properly.
     *
     * @param string $userId    Numerical UserPK ID.
     * @param string $algorithm Which algorithm to hide the suggestion from;
     *                          must match that user's "algorithm" value in
     *                          functions like People::discoverPeople().
     *
     * @throws \InstagramAPI\Exception\InstagramException
     *
     * @return \InstagramAPI\Response\SuggestedUsersResponse
     */
    public function hideSuggestedUser(
        $userId,
        $algorithm)
    {
        return $this->ig->request('discover/aysf_dismiss/')
            ->addPost('_uuid', $this->ig->uuid)
            ->addParam('target_id', $userId)
            ->addParam('algorithm', $algorithm)
            ->getResponse(new Response\SuggestedUsersResponse());
    }

    /**
     * Follow a user.
     *
     * @param string      $userId  Numerical UserPK ID.
     * @param string|null $mediaId The media ID in Instagram's internal format (ie "3482384834_43294").
     *
     * @throws \InstagramAPI\Exception\InstagramException
     *
     * @return \InstagramAPI\Response\FriendshipResponse
     */
    public function follow(
        $userId,
        $mediaId = null,
        $container_module = 'profile',
        $nav_chain = 'MainFeedFragment:feed_timeline:1:cold_start:0.0::')
    {
        if ($this->ig->getPlatform() === 'ios') {
            if ($container_module == 'self_following') {
                $nav_chain = 'IGProfileViewController:self_profile:14:main_profile,IGFollowListTabPageViewController:self_unified_follow_lists:18:';
            } elseif ($container_module == 'profile') {
                $nav_chain = 'IGMainFeedViewController:feed_timeline:1:cold_start::,IGProfileViewController:profile:15:media_owner';
            } else {
                $nav_chain = 'IGMainFeedViewController:feed_timeline:1:cold_start::,IGProfileViewController:profile:15:media_owner';
            }
        }

        if (empty($this->ig->client->_navChain)) {
            $this->ig->setNavChainHeader($nav_chain, true);
        }

        $request = $this->ig->request("friendships/create/{$userId}/")
            ->addPost('nav_chain', $nav_chain)
            ->addPost('_uuid', $this->ig->uuid)
            ->addPost('user_id', $userId)
            ->addPost('device_id', $this->ig->device_id)
            ->addPost('_uid', $this->ig->account_id)
            ->addPost('container_module', $container_module);
        
        if ($this->ig->getPlatform() === 'android') {
            $request->addPost('radio_type', $this->ig->radio_type);
        }

        if ($mediaId !== null) {
            $request->addPost('media_id_attribution', $mediaId);
        }

        return $request->getResponse(new Response\FriendshipResponse());
    }

    /**
     * Unfollow a user.
     *
     * @param string      $userId  Numerical UserPK ID.
     * @param string|null $mediaId The media ID in Instagram's internal format (ie "3482384834_43294").
     *
     * @throws \InstagramAPI\Exception\InstagramException
     *
     * @return \InstagramAPI\Response\FriendshipResponse
     */
    public function unfollow(
        $userId,
        $mediaId = null,
        $container_module = 'self_following',
        $nav_chain = 'MainFeedFragment:feed_timeline:1:cold_start:0.0::')
    {
        if ($this->ig->getPlatform() === 'ios') {
            if ($container_module == 'self_following') {
                $nav_chain = 'IGProfileViewController:self_profile:14:main_profile,IGFollowListTabPageViewController:self_unified_follow_lists:18:';
            } elseif ($container_module == 'profile') {
                $nav_chain = 'IGMainFeedViewController:feed_timeline:1:cold_start::,IGProfileViewController:profile:15:media_owner';
            } else {
                $nav_chain = 'IGMainFeedViewController:feed_timeline:1:cold_start::,IGProfileViewController:profile:15:media_owner';
            }
        }

        if (empty($this->ig->client->_navChain)) {
            $this->ig->setNavChainHeader($nav_chain, true);
        }

        $request = $this->ig->request("friendships/destroy/{$userId}/")
            ->addPost('nav_chain', $nav_chain)
            ->addPost('_uuid', $this->ig->uuid)
            ->addPost('user_id', $userId)
            ->addPost('device_id', $this->ig->device_id)
            ->addPost('_uid', $this->ig->account_id)
            ->addPost('container_module', $container_module);

        if ($this->ig->getPlatform() === 'android') {
            $request->addPost('radio_type', $this->ig->radio_type);
        }

        if ($mediaId !== null) {
            $request->addPost('media_id_attribution', $mediaId);
        }

        return $request->getResponse(new Response\FriendshipResponse());
    }

    /**
     * Like the media with web API
     *
     * @param string      $mediaId        Numerical Media ID.
     * @param string      $rollout_hash   Use function getDataFromWeb() from /src/Instagram.php to get this constant
     *
     * @throws \InvalidArgumentException
     * @throws \InstagramAPI\Exception\InstagramException
     *
     * @return \InstagramAPI\Response\GenericResponse
     */
    public function likeWeb(
        $mediaId,
        $rollout_hash)
    {
        if ($mediaId == null) {
            throw new \InvalidArgumentException('Empty $mediaId sent to likeWeb() function.');
        }

        if ($rollout_hash == null || !is_string($rollout_hash)) {
            throw new \InvalidArgumentException('Empty or incorrect $rollout_hash sent to likeWeb() function.');
        }

        $request = $this->ig->request("https://instagram.com/web/likes/{$mediaId}/like/")
            ->setAddDefaultHeaders(false)
            ->setSignedPost(false)
            ->addHeader('Referer', 'https://www.instagram.com/')
            ->addHeader('X-CSRFToken', $this->ig->client->getTokenGraph())
            ->addHeader('X-Requested-With', 'XMLHttpRequest')
            ->addHeader('X-Instagram-AJAX', $rollout_hash)
            ->addHeader('X-Ig-App-Id', Constants::IG_WEB_APPLICATION_ID);
        if ($this->ig->getIsAndroid()) {
            $request->addHeader('User-Agent', sprintf('Mozilla/5.0 (Linux; Android %s; Google) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Mobile Safari/537.36', $this->ig->device->getAndroidRelease()));
        } else {
            $request->addHeader('User-Agent', 'Mozilla/5.0 (iPhone; CPU iPhone OS ' . Constants::IOS_VERSION . ' like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.4 Mobile/15E148 Safari/604.1');
        }
        $request->addPost('', '');

        return $request->getResponse(new Response\GenericResponse());
    }

    /**
     * Like the media comment with web API
     *
     * @param string      $commentId        Numerical Comment ID.
     * @param string      $rollout_hash   Use function getDataFromWeb() from /src/Instagram.php to get this constant
     *
     * @throws \InvalidArgumentException
     * @throws \InstagramAPI\Exception\InstagramException
     *
     * @return \InstagramAPI\Response\GenericResponse
     */
    public function likeCommentWeb(
        $commentId,
        $rollout_hash)
    {
        if ($commentId == null) {
            throw new \InvalidArgumentException('Empty $commentId sent to likeCommentWeb() function.');
        }

        if ($rollout_hash == null || !is_string($rollout_hash)) {
            throw new \InvalidArgumentException('Empty or incorrect $rollout_hash sent to likeCommentWeb() function.');
        }

        $request = $this->ig->request("https://instagram.com/web/comments/like/{$commentId}/")
            ->setAddDefaultHeaders(false)
            ->setSignedPost(false)
            ->addHeader('X-CSRFToken', $this->ig->client->getTokenGraph())
            ->addHeader('Referer', 'https://www.instagram.com/')
            ->addHeader('X-Requested-With', 'XMLHttpRequest')
            ->addHeader('X-Instagram-AJAX', $rollout_hash)
            ->addHeader('X-Ig-App-Id', Constants::IG_WEB_APPLICATION_ID);
            if ($this->ig->getIsAndroid()) {
                $request->addHeader('User-Agent', sprintf('Mozilla/5.0 (Linux; Android %s; Google) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Mobile Safari/537.36', $this->ig->device->getAndroidRelease()));
            } else {
                $request->addHeader('User-Agent', 'Mozilla/5.0 (iPhone; CPU iPhone OS ' . Constants::IOS_VERSION . ' like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.4 Mobile/15E148 Safari/604.1');
            }
            $request->addPost('', '');

        return $request->getResponse(new Response\GenericResponse());
    }

    /**
     * Follow user with web API
     *
     * @param string       $userId       Numerical User PK ID.
     * @param string       $rollout_hash   Use function getDataFromWeb() from /src/Instagram.php to get this constant
     *
     * @throws \InvalidArgumentException
     * @throws \InstagramAPI\Exception\InstagramException
     *
     * @return \InstagramAPI\Response\FriendshipResponse
     */
    public function followWeb(
        $userId, 
        $username,
        $rollout_hash) {
        if ($userId == null) {
            throw new \InvalidArgumentException('Empty $userId sent to followWeb() function.');
        }

        if ($username == null) {
            throw new \InvalidArgumentException('Empty $username sent to followWeb() function.');
        }

        if ($rollout_hash == null || !is_string($rollout_hash)) {
            throw new \InvalidArgumentException('Empty or incorrect $rollout_hash sent to followWeb() function.');
        }
        
        $request = $this->ig->request("https://www.instagram.com/web/friendships/{$userId}/follow/")
            ->setAddDefaultHeaders(false)
            ->setSignedPost(false)
            ->addHeader('X-CSRFToken', $this->ig->client->getTokenGraph())
            ->addHeader('Origin', 'https://www.instagram.com/')
            ->addHeader('Referer', 'https://www.instagram.com/' . $username . '/')
            ->addHeader('X-Requested-With', 'XMLHttpRequest')
            ->addHeader('X-Instagram-AJAX', $rollout_hash)
            ->addHeader('X-Ig-App-Id', Constants::IG_WEB_APPLICATION_ID);
            if ($this->ig->getIsAndroid()) {
                $request->addHeader('User-Agent', sprintf('Mozilla/5.0 (Linux; Android %s; Google) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Mobile Safari/537.36', $this->ig->device->getAndroidRelease()));
            } else {
                $request->addHeader('User-Agent', 'Mozilla/5.0 (iPhone; CPU iPhone OS ' . Constants::IOS_VERSION . ' like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.4 Mobile/15E148 Safari/604.1');
            }
            $request->addPost('', '');

        return $request->getResponse(new Response\FriendshipResponse());
    }

    /**
     * Unfollow user with web API
     *
     * @param string      $userId       Numerical User PK ID.
     * @param string      $rollout_hash   Use function getDataFromWeb() from /src/Instagram.php to get this constant
     *
     * @throws \InvalidArgumentException
     * @throws \InstagramAPI\Exception\InstagramException
     *
     * @return \InstagramAPI\Response\FriendshipResponse
     */
    public function unfollowWeb(
        $userId,
        $username,
        $rollout_hash) 
    {
        if ($userId == null) {
            throw new \InvalidArgumentException('Empty $userId sent to unfollowWeb() function.');
        }

        if ($username == null) {
            throw new \InvalidArgumentException('Empty $username sent to unfollowWeb() function.');
        }

        if ($rollout_hash == null || !is_string($rollout_hash)) {
            throw new \InvalidArgumentException('Empty or incorrect $rollout_hash sent to followWeb() function.');
        }
        
        $request = $this->ig->request("https://www.instagram.com/web/friendships/{$userId}/unfollow/")
            ->setAddDefaultHeaders(false)
            ->setSignedPost(false)
            ->addHeader('X-CSRFToken', $this->ig->client->getTokenGraph())
            ->addHeader('Origin', 'https://www.instagram.com/')
            ->addHeader('Referer', 'https://www.instagram.com/' . $username . '/')
            ->addHeader('X-Requested-With', 'XMLHttpRequest')
            ->addHeader('X-Instagram-AJAX', $rollout_hash)
            ->addHeader('X-Ig-App-Id', Constants::IG_WEB_APPLICATION_ID);
            if ($this->ig->getIsAndroid()) {
                $request->addHeader('User-Agent', sprintf('Mozilla/5.0 (Linux; Android %s; Google) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Mobile Safari/537.36', $this->ig->device->getAndroidRelease()));
            } else {
                $request->addHeader('User-Agent', 'Mozilla/5.0 (iPhone; CPU iPhone OS ' . Constants::IOS_VERSION . ' like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.4 Mobile/15E148 Safari/604.1');
            }
            $request->addPost('', '');

        return $request->getResponse(new Response\FriendshipResponse());
    }

    /**
     * Enable high priority for a user you are following.
     *
     * When you mark someone as favorite, you will receive app push
     * notifications when that user uploads media, and their shared
     * media will get higher visibility. For instance, their stories
     * will be placed at the front of your reels-tray, and their
     * timeline posts will stay visible for longer on your homescreen.
     *
     * @param string $userId Numerical UserPK ID.
     *
     * @throws \InstagramAPI\Exception\InstagramException
     *
     * @return \InstagramAPI\Response\GenericResponse
     */
    public function favorite(
        $userId)
    {
        return $this->ig->request("friendships/favorite/{$userId}/")
            ->addPost('_uuid', $this->ig->uuid)
            ->addPost('_uid', $this->ig->account_id)
            ->addPost('user_id', $userId)
            ->getResponse(new Response\GenericResponse());
    }

    /**
     * Disable high priority for a user you are following.
     *
     * @param string $userId Numerical UserPK ID.
     *
     * @throws \InstagramAPI\Exception\InstagramException
     *
     * @return \InstagramAPI\Response\GenericResponse
     */
    public function unfavorite(
        $userId)
    {
        return $this->ig->request("friendships/unfavorite/{$userId}/")
            ->addPost('_uuid', $this->ig->uuid)
            ->addPost('_uid', $this->ig->account_id)
            ->addPost('user_id', $userId)
            ->getResponse(new Response\GenericResponse());
    }

    /**
     * Turn on story notifications.
     *
     * @param string $userId Numerical UserPK ID.
     *
     * @throws \InstagramAPI\Exception\InstagramException
     *
     * @return \InstagramAPI\Response\GenericResponse
     */
    public function favoriteForStories(
        $userId)
    {
        return $this->ig->request("friendships/favorite_for_stories/{$userId}/")
            ->addPost('_uuid', $this->ig->uuid)
            ->addPost('_uid', $this->ig->account_id)
            ->addPost('user_id', $userId)
            ->getResponse(new Response\GenericResponse());
    }

    /**
     * Turn off story notifications.
     *
     * @param string $userId Numerical UserPK ID.
     *
     * @throws \InstagramAPI\Exception\InstagramException
     *
     * @return \InstagramAPI\Response\GenericResponse
     */
    public function unfavoriteForStories(
        $userId)
    {
        return $this->ig->request("friendships/unfavorite_for_stories/{$userId}/")
            ->addPost('_uuid', $this->ig->uuid)
            ->addPost('_uid', $this->ig->account_id)
            ->addPost('user_id', $userId)
            ->getResponse(new Response\GenericResponse());
    }

    /**
     * Report a user as spam.
     *
     * @param string $userId     Numerical UserPK ID.
     * @param string $sourceName (optional) Source app-module of the report.
     *
     * @throws \InstagramAPI\Exception\InstagramException
     *
     * @return \InstagramAPI\Response\GenericResponse
     */
    public function report(
        $userId,
        $sourceName = 'profile')
    {
        return $this->ig->request("users/{$userId}/flag_user/")
            ->addPost('reason_id', 1)
            ->addPost('_uuid', $this->ig->uuid)
            ->addPost('_uid', $this->ig->account_id)
            ->addPost('user_id', $userId)
            ->addPost('source_name', $sourceName)
            ->addPost('is_spam', true)
            ->getResponse(new Response\GenericResponse());
    }

    /**
     * Block a user.
     *
     * @param string $userId Numerical UserPK ID.
     *
     * @throws \InstagramAPI\Exception\InstagramException
     *
     * @return \InstagramAPI\Response\FriendshipResponse
     */
    public function block(
        $userId)
    {
        return $this->ig->request("friendships/block/{$userId}/")
            ->addPost('_uuid', $this->ig->uuid)
            ->addPost('_uid', $this->ig->account_id)
            ->addPost('user_id', $userId)
            ->getResponse(new Response\FriendshipResponse());
    }

    /**
     * Restrict a user account.
     *
     * @param string $userId Numerical UserPK ID.
     *
     * @throws \InstagramAPI\Exception\InstagramException
     *
     * @return \InstagramAPI\Response\FriendshipResponse
     */
    public function restrict(
        $userId)
    {
        return $this->ig->request('restrict_action/restrict/')
            ->setSignedPost(false)
            ->addPost('_uuid', $this->ig->uuid)
            ->addPost('target_user_id', $userId)
            ->getResponse(new Response\FriendshipResponse());
    }

    /**
     * Unrestrict a user account.
     *
     * @param string $userId Numerical UserPK ID.
     *
     * @throws \InstagramAPI\Exception\InstagramException
     *
     * @return \InstagramAPI\Response\FriendshipResponse
     */
    public function unrestrict(
        $userId)
    {
        return $this->ig->request('restrict_action/unrestrict/')
            ->setSignedPost(false)
            ->addPost('_uuid', $this->ig->uuid)
            ->addPost('target_user_id', $userId)
            ->getResponse(new Response\FriendshipResponse());
    }

    /**
     * Mute stories, posts or both from a user.
     *
     * It prevents user media from showing up in the timeline and/or story feed.
     *
     * @param string $userId Numerical UserPK ID.
     * @param string $option Selection of what type of media are going to be muted.
     *                       Available options: 'story', 'post' or 'all'.
     *
     * @throws \InvalidArgumentException
     * @throws \InstagramAPI\Exception\InstagramException
     *
     * @return \InstagramAPI\Response\FriendshipResponse
     */
    public function muteUserMedia(
        $userId,
        $option)
    {
        return $this->_muteOrUnmuteUserMedia($userId, $option, 'friendships/mute_posts_or_story_from_follow/');
    }

    /**
     * Unmute stories, posts or both from a user.
     *
     * @param string $userId Numerical UserPK ID.
     * @param string $option Selection of what type of media are going to be muted.
     *                       Available options: 'story', 'post' or 'all'.
     *
     * @throws \InvalidArgumentException
     * @throws \InstagramAPI\Exception\InstagramException
     *
     * @return \InstagramAPI\Response\FriendshipResponse
     */
    public function unmuteUserMedia(
        $userId,
        $option)
    {
        return $this->_muteOrUnmuteUserMedia($userId, $option, 'friendships/unmute_posts_or_story_from_follow/');
    }

    /**
     * Helper function to mute user media.
     *
     * @param string $userId   Numerical UserPK ID.
     * @param string $option   Selection of what type of media are going to be muted.
     *                         Available options: 'story', 'post' or 'all'.
     * @param string $endpoint API endpoint for muting/unmuting user media.
     *
     * @throws \InvalidArgumentException
     * @throws \InstagramAPI\Exception\InstagramException
     *
     * @return \InstagramAPI\Response\FriendshipResponse
     *
     * @see People::muteUserMedia()
     * @see People::unmuteUserMedia()
     */
    protected function _muteOrUnmuteUserMedia(
        $userId,
        $option,
        $endpoint)
    {
        $request = $this->ig->request($endpoint)
            ->addPost('_uuid', $this->ig->uuid)
            ->addPost('_uid', $this->ig->account_id);

        switch ($option) {
            case 'story':
                $request->addPost('target_reel_author_id', $userId);
                break;
            case 'post':
                $request->addPost('target_posts_author_id', $userId);
                break;
            case 'all':
                $request->addPost('target_reel_author_id', $userId);
                $request->addPost('target_posts_author_id', $userId);
                break;
            default:
                throw new \InvalidArgumentException(sprintf('"%s" is not a valid muting option.', $option));
        }

        return $request->getResponse(new Response\FriendshipResponse());
    }

    /**
     * Unblock a user.
     *
     * @param string $userId Numerical UserPK ID.
     *
     * @throws \InstagramAPI\Exception\InstagramException
     *
     * @return \InstagramAPI\Response\FriendshipResponse
     */
    public function unblock(
        $userId)
    {
        return $this->ig->request("friendships/unblock/{$userId}/")
            ->addPost('_uuid', $this->ig->uuid)
            ->addPost('_uid', $this->ig->account_id)
            ->addPost('user_id', $userId)
            ->getResponse(new Response\FriendshipResponse());
    }

    /**
     * Get a list of all blocked users.
     *
     * @param string|null $maxId Next "maximum ID", used for pagination.
     *
     * @throws \InstagramAPI\Exception\InstagramException
     *
     * @return \InstagramAPI\Response\BlockedListResponse
     */
    public function getBlockedList(
        $maxId = null)
    {
        $request = $this->ig->request('users/blocked_list/');
        if ($maxId !== null) {
            $request->addParam('max_id', $maxId);
        }

        return $request->getResponse(new Response\BlockedListResponse());
    }

    /**
     * Block a user's ability to see your stories.
     *
     * @param string $userId Numerical UserPK ID.
     * @param string $source (optional) The source where this request was triggered.
     *
     * @throws \InstagramAPI\Exception\InstagramException
     *
     * @return \InstagramAPI\Response\FriendshipResponse
     *
     * @see People::muteFriendStory()
     */
    public function blockMyStory(
        $userId,
        $source = 'profile')
    {
        return $this->ig->request("friendships/block_friend_reel/{$userId}/")
            ->addPost('_uuid', $this->ig->uuid)
            ->addPost('_uid', $this->ig->account_id)
            ->addPost('source', $source)
            ->getResponse(new Response\FriendshipResponse());
    }

    /**
     * Unblock a user so that they can see your stories again.
     *
     * @param string $userId Numerical UserPK ID.
     *
     * @throws \InstagramAPI\Exception\InstagramException
     *
     * @return \InstagramAPI\Response\FriendshipResponse
     *
     * @see People::unmuteFriendStory()
     */
    public function unblockMyStory(
        $userId)
    {
        return $this->ig->request("friendships/unblock_friend_reel/{$userId}/")
            ->addPost('_uuid', $this->ig->uuid)
            ->addPost('_uid', $this->ig->account_id)
            ->addPost('source', 'profile')
            ->getResponse(new Response\FriendshipResponse());
    }

    /**
     * Get the list of users who are blocked from seeing your stories.
     *
     * @throws \InstagramAPI\Exception\InstagramException
     *
     * @return \InstagramAPI\Response\BlockedReelsResponse
     */
    public function getBlockedStoryList()
    {
        return $this->ig->request('friendships/blocked_reels/')
            ->addPost('_uuid', $this->ig->uuid)
            ->addPost('_uid', $this->ig->account_id)
            ->getResponse(new Response\BlockedReelsResponse());
    }

    /**
     * Mute a friend's stories, so that you no longer see their stories.
     *
     * This hides them from your reels tray (the "latest stories" bar on the
     * homescreen of the app), but it does not block them from seeing *your*
     * stories.
     *
     * @param string $userId Numerical UserPK ID.
     *
     * @throws \InstagramAPI\Exception\InstagramException
     *
     * @return \InstagramAPI\Response\FriendshipResponse
     *
     * @see People::blockMyStory()
     */
    public function muteFriendStory(
        $userId)
    {
        return $this->ig->request("friendships/mute_friend_reel/{$userId}/")
            ->addPost('_uuid', $this->ig->uuid)
            ->addPost('_uid', $this->ig->account_id)
            ->getResponse(new Response\FriendshipResponse());
    }

    /**
     * Unmute a friend's stories, so that you see their stories again.
     *
     * This does not unblock their ability to see *your* stories.
     *
     * @param string $userId Numerical UserPK ID.
     *
     * @throws \InstagramAPI\Exception\InstagramException
     *
     * @return \InstagramAPI\Response\FriendshipResponse
     *
     * @see People::unblockMyStory()
     */
    public function unmuteFriendStory(
        $userId)
    {
        return $this->ig->request("friendships/unmute_friend_reel/{$userId}/")
            ->addPost('_uuid', $this->ig->uuid)
            ->addPost('_uid', $this->ig->account_id)
            ->getResponse(new Response\FriendshipResponse());
    }

    /**
     * Get the list of users on your close friends list.
     *
     * @throws \InstagramAPI\Exception\InstagramException
     *
     * @return \InstagramAPI\Response\CloseFriendsResponse
     */
    public function getCloseFriends()
    {
        return $this->ig->request('friendships/besties/')
            ->getResponse(new Response\CloseFriendsResponse());
    }

    /**
     * Get the list of suggested users for your close friends list.
     *
     * @throws \InstagramAPI\Exception\InstagramException
     *
     * @return \InstagramAPI\Response\CloseFriendsResponse
     */
    public function getSuggestedCloseFriends()
    {
        return $this->ig->request('friendships/bestie_suggestions/')
            ->getResponse(new Response\CloseFriendsResponse());
    }

    /**
     * Add or Remove users from your close friends list.
     *
     * Note: You probably shouldn't touch $module and $source as there is only one way to modify your close friends.
     *
     * @param array  $add    Users to add to your close friends list.
     * @param array  $remove Users to remove from your close friends list.
     * @param string $module (optional) From which app module (page) you have change your close friends list.
     * @param string $source (optional) Source page of app-module of where you changed your close friends list.
     *
     * @throws \InstagramAPI\Exception\InstagramException
     *
     * @return \InstagramAPI\Response\GenericResponse
     */
    public function setCloseFriends(
        array $add,
        array $remove,
        $module = 'favorites_home_list',
        $source = 'audience_manager')
    {
        return $this->ig->request('friendships/set_besties/')
            ->setSignedPost(true)
            ->addPost('module', $module)
            ->addPost('source', $source)
            ->addPost('_uid', $this->ig->account_id)
            ->addPost('_uuid', $this->ig->uuid)
            ->addPost('remove', $remove)
            ->addPost('add', $add)
            ->getResponse(new Response\GenericResponse());
    }

    /**
     * Gets a list of ranked users to display in Android's share UI.
     *
     * @throws \InstagramAPI\Exception\InstagramException
     *
     * @return \InstagramAPI\Response\SharePrefillResponse
     */
    public function getSharePrefill()
    {
        return $this->ig->request('banyan/banyan/')
            ->addParam('views', '["story_share_sheet","direct_user_search_nullstate","reshare_share_sheet","forwarding_recipient_sheet","share_extension","call_recipients","direct_user_search_keypressed"]')
            ->getResponse(new Response\SharePrefillResponse());
    }

    /**
     * Gets a list of users who's stories or posts you mute.
     *
     * @throws \InstagramAPI\Exception\InstagramException
     *
     * @return \InstagramAPI\Response\MutedUsersResponse
     */
    public function getMutedUsers()
    {
        $req = $this->ig->request('bloks/apps/com.instagram.growth.screens.muted_users/')
            ->addPost('_uuid', $this->ig->uuid);

        if ($this->ig->getPlatform() === 'ios') {
            $req->addPost('bloks_versioning_id', Constants::IOS_BLOCKS_VERSIONING_ID);
        } else {
            $req->addPost('bloks_versioning_id', Constants::BLOCK_VERSIONING_ID);
        }

        return $req->getResponse(new Response\MutedUsersResponse());
    }

    /**
     * Get list of explore people with web api.
     *
     * @param string $fs_count        Numerical fetch suggested user count.
     * @param int    $end_cursor      Next "maximum ID", used for pagination.
     * @param array  $seen_ids        Already collected user ids.
     * @param bool   $include_reel    Include stories reels in response.
     * @param bool   $ignore_cache    Ignore cache for suggestion & explore response..
     * @param bool   $filter_followed This variable provide suggestion like your already followed peoples..
     * 
     * @throws \InvalidArgumentException
     * @throws \InstagramAPI\Exception\InstagramException
     *
     * @return \InstagramAPI\Response\GraphqlResponse
     */
    public function getDiscoverGraph(
        $fs_count = 50,
        $ignore_cache = false,
        $end_cursor = null,
        $seen_ids = [],
        $include_reel = true,
        $filter_followed = false)
    {
        if ($userId == null) {
            throw new \InvalidArgumentException('Empty $userId sent to getFollowersGraph() function.');
        }

        return $request = $this->ig->request("graphql/query/")
            ->setVersion(5)
            ->setAddDefaultHeaders(false)
            ->setSignedPost(false)
            ->addParam('query_hash', 'bd90987150a65578bc0dd5d4e60f113d')
            ->addParam('variables', json_encode([
                "filter_followed_friends" => $filter_followed ? true : false,
                "fetch_media_count" => false,
                "seen_ids" => $seen_ids, 
                "include_reel" => $include_reel ? true : false,
                "ignore_cache" => $ignore_cache ? true : false,
                "fetch_suggested_count" => $fs_count,
                "after" => $end_cursor,
            ]))
            ->getResponse(new Response\GraphqlResponse());
    }

    /**
     * Unfollow Chaining Count request for a user.
     *
     * @param string $userId  Numerical UserPK ID.
     * 
     *
     * @throws \InstagramAPI\Exception\InstagramException
     *
     * @return \InstagramAPI\Response\FriendshipResponse
     */
    public function unfollowChainingCount(
        $userId)
    {
        $request = $this->ig->request("friendships/unfollow_chaining_count/{$userId}/")
            ->addPost('_uuid', $this->ig->uuid)
            ->addPost('_uid', $this->ig->account_id)
            ->addPost('user_id', $userId)
            ->addPost('device_id', $this->ig->device_id)
            ->addPost('radio_type', $this->ig->radio_type);

        return $request->getResponse(new Response\FriendshipResponse());
    }
}
