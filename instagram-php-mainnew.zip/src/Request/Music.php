<?php

namespace InstagramAPI\Request;

use InstagramAPI\Request;
use InstagramAPI\Constants;
use InstagramAPI\Response;
use InstagramAPI\Signatures;
use InstagramAPI\Utils;

/**
 * Functions for interacting with Music items from yourself and others.
 */
class Music extends RequestCollection
{
    /**
     * Bookmark (save) music to your Collections
     * 
     * @param string $original_audio_id     Audio ID in Instagram internal format
     * @param string surface_requested_from Surface, from which action was made.
     * 
     * @throws \InstagramAPI\Exception\InstagramException
     *
     * @return \InstagramAPI\Response\GenericResponse
     */
    public function bookmarkMusic(
        $original_audio_id,
        $surface_requested_from = 'audio_aggregation_page')
    {
        return $this->ig->request("music/bookmark_music/")
            ->addPost('original_audio_id', $original_audio_id)
            ->addPost('_uuid', $this->ig->uuid)
            ->addPost('surface_requested_from', $surface_requested_from)
            ->getResponse(new Response\GenericResponse);
    }

    /**
     * Unbookmark (unsave) music from your Collections
     * 
     * @param string $original_audio_id     Audio ID in Instagram internal format
     * @param string surface_requested_from Surface, from which action was made.
     * 
     * @throws \InstagramAPI\Exception\InstagramException
     *
     * @return \InstagramAPI\Response\GenericResponse
     */
    public function unbookmarkMusic(
        $original_audio_id,
        $surface_requested_from = 'audio_aggregation_page')
    {
        return $this->ig->request("music/unbookmark_music/")
            ->addPost('original_audio_id', $original_audio_id)
            ->addPost('_uuid', $this->ig->uuid)
            ->addPost('surface_requested_from', $surface_requested_from)
            ->getResponse(new Response\GenericResponse);
    }

    /**
     * Get a Reels feed for music
     * 
     * @param string      $asset_id                      Audio Cluster ID in Instagram internal format
     * @param string      $pageSize                      Number of reels.
     * @param string|null $maxId                         Next "maximum ID", used for pagination.
     * 
     * @throws \InstagramAPI\Exception\InstagramException
     *
     * @return \InstagramAPI\Response\MusicClipsResponse
     */
    public function getMusicFeed(
        $asset_id,
        $maxId = null,
        $pageSize = 12)
    {
        $request = $this->ig->request("clips/music/")
            ->addPost('_uuid', $this->ig->uuid)
            ->addPost('original_sound_audio_asset_id', $asset_id);

        if (!empty($maxId)) {
            $request->addPost('max_id', $maxId);
        }

        if (!empty($pageSize)) {
            $request->addPost('page_size', $pageSize);
        }

        return $request->getResponse(new Response\MusicClipsResponse);
    }

    /**
     * Search for Music
     * 
     * Gives you search results ordered by best matches first.
     * 
     * Note that you can get more than one "page" of music search results by
     * excluding the numerical IDs of all tags from a previous search query.
     * 
     * @throws \InstagramAPI\Exception\InstagramException
     *
     * @return \InstagramAPI\Response\MusicSearchResponse
     */
    public function search(
        $query,
        $browse_session_id = null)
    {
        // Do basic query validation. Do NOT use throwIfInvalidHashtag here.
        if (!is_string($query) || $query === '') {
            throw new \InvalidArgumentException('Query must be a non-empty string.');
        }

        if (!empty($browse_session_id)) {
            $browse_session_id = \InstagramAPI\Signatures::generateUUID();
        }

        $request = $this->ig->request("music/audio_global_search/")
            ->addParam('query', $query)
            ->addParam('browse_session_id', $browse_session_id);

        return $request->getResponse(new Response\MusicSearchResponse);
    }
}