<?php

namespace InstagramAPI;

use \Psr\Http\Message\ResponseInterface as HttpResponseInterface;

/**
 * Private Instagram API for PHP (iOS & Android)
 * 
 * @link https://nextpost.tech/downloads/nextpost-api-bundle/
 * 
 * @version 7.0.3
 * @author Nextpost.tech (https://nextpost.tech)
 */
class Instagram implements ExperimentsInterface
{
    /**
     * License Key 
     * 
     * Once you got a license key at https://nextpost.tech/downloads/nextpost-api-bundle/ you have 2 ways to add a license key to API.
     * @see 
     * 
     * @var string
     */
    public $license_key = null;
     
    /**
     * Experiments refresh interval in sec.
     *
     * @var int
     */
    const EXPERIMENTS_REFRESH = 7200;

    /**
     * Currently active Instagram username.
     *
     * @var string
     */
    public $username;

    /**
     * Currently active Instagram password.
     *
     * @var string
     */
    public $password;

    /**
     * Currently active Facebook access token.
     *
     * @var string
     */
    public $fb_access_token;

    /**
     * The Android device for the currently active user.
     *
     * @var \InstagramAPI\Devices\DeviceInterface
     */
    public $device;

    /**
     * Toggles API query/response debug output.
     *
     * @var bool
     */
    public $debug;

    /**
     * Toggles truncating long responses when debugging.
     *
     * @var bool
     */
    public $truncatedDebug;

    /**
     * For internal use by Instagram-API developers!
     *
     * Toggles the throwing of exceptions whenever Instagram-API's "Response"
     * classes lack fields that were provided by the server. Useful for
     * discovering that our library classes need updating.
     *
     * This is only settable via this public property and is NOT meant for
     * end-users of this library. It is for contributing developers!
     *
     * @var bool
     */
    public $apiDeveloperDebug = false;

    /**
     * Global flag for users who want to run the library incorrectly online.
     *
     * YOU ENABLE THIS AT YOUR OWN RISK! WE GIVE _ZERO_ SUPPORT FOR THIS MODE!
     * EMBEDDING THE LIBRARY DIRECTLY IN A WEBPAGE (WITHOUT ANY INTERMEDIARY
     * PROTECTIVE LAYER) CAN CAUSE ALL KINDS OF DAMAGE AND DATA CORRUPTION!
     *
     * YOU HAVE BEEN WARNED. ANY DATA CORRUPTION YOU CAUSE IS YOUR OWN PROBLEM!
     *
     * The right way to run the library online is described in `webwarning.htm`.
     *
     * @var bool
     *
     * @see Instagram::__construct()
     */
    public static $allowDangerousWebUsageAtMyOwnRisk = false;

    /**
     * Global flag for users who want to still use dangerous getInfoById() function
     * 
     * Requests to the getInfoById() endpoint are disabled by default. 
     * You can only use this feature for your account info. 
     * It is currently not possible to securely obtain any information about another users. 
     * We are working on alternatives and will try to add more ways to do this in future versions 
     * of the API, but at the moment this feature is very risky for accounts.
     * 
     * @var bool
     * 
     * @see Instagram::__construct()
     */
    public static $allowDangerousGetInfoByIdUsage = false;

    /**
     * Global flag for users who want to run the library incorrectly.
     *
     * YOU ENABLE THIS AT YOUR OWN RISK! WE GIVE _ZERO_ SUPPORT FOR THIS MODE!
     * THIS WILL SKIP ANY PRE AND POST LOGIN FLOW!
     *
     * THIS SHOULD BE ONLY USED FOR RESEARCHING AND EXPERIMENTAL PURPOSES.
     *
     * YOU HAVE BEEN WARNED. ANY DATA CORRUPTION YOU CAUSE IS YOUR OWN PROBLEM!
     *
     * @var bool
     */
    public static $skipLoginFlowAtMyOwnRisk = false;

    /**
     * Global flag for users who want to manage login exceptions on their own.
     *
     * YOU ENABLE THIS AT YOUR OWN RISK! WE GIVE _ZERO_ SUPPORT FOR THIS MODE!
     *
     * @var bool
     *
     * @see Instagram::__construct()
     */
    public static $manuallyManageLoginException = false;

    /**
     * Global flag for users who want to run deprecated functions.
     *
     * YOU ENABLE THIS AT YOUR OWN RISK! WE GIVE _ZERO_ SUPPORT FOR THIS MODE!
     *
     * @var bool
     *
     * @see Instagram::__construct()
     */
    public static $overrideDeprecatedThrower = false;

    /**
     * Set this value to false for the recent 
     * logins. This is required to use this API
     * in a webpage for consecutive
     * @var boolean
     */
    public static $sendLoginFlow = true;

    /**
     * UUID.
     *
     * @var string
     */
    public $uuid;

    /**
     * IP Rotation link for proxy
     *
     * @var string
     */
    public $rotationLink = null;

    /**
     * Google Play Advertising ID.
     *
     * The advertising ID is a unique ID for advertising, provided by Google
     * Play services for use in Google Play apps. Used by Instagram.
     *
     * @var string
     *
     * @see https://support.google.com/googleplay/android-developer/answer/6048248?hl=en
     */
    public $advertising_id;

    /**
     * Facebook Tracking ID.
     *
     * @var string
     */
    public $fb_tracking_id;

    /**
     * Device ID.
     *
     * @var string
     */
    public $device_id;

    /**
     * Phone ID.
     *
     * @var string
     */
    public $phone_id;

    /**
     * Numerical UserPK ID of the active user account.
     *
     * @var string
     */
    public $account_id;

    /**
     * Our current guess about the session status.
     *
     * This contains our current GUESS about whether the current user is still
     * logged in. There is NO GUARANTEE that we're still logged in. For example,
     * the server may have invalidated our current session due to the account
     * password being changed AFTER our last login happened (which kills all
     * existing sessions for that account), or the session may have expired
     * naturally due to not being used for a long time, and so on...
     *
     * NOTE TO USERS: The only way to know for sure if you're logged in is to
     * try a request. If it throws a `LoginRequiredException`, then you're not
     * logged in anymore. The `login()` function will always ensure that your
     * current session is valid. But AFTER that, anything can happen... It's up
     * to Instagram, and we have NO control over what they do with your session!
     *
     * @var bool
     */
    public $isMaybeLoggedIn = false;

    /**
     * Raw API communication/networking class.
     *
     * @var Client
     */
    public $client;

    /**
     * The account settings storage.
     *
     * @var \InstagramAPI\Settings\StorageHandler|null
     */
    public $settings;

    /**
     * The current application session ID.
     *
     * This is a temporary ID which changes in the official app every time the
     * user closes and re-opens the Instagram application or switches account.
     *
     * @var string
     */
    public $session_id;

    /**
     * A list of experiments enabled on per-account basis.
     *
     * @var array
     */
    public $experiments;

    /**
     * Custom Device string.
     *
     * @var string|null
     */
    public $customDeviceString = null;

    /**
     * Custom Device string.
     *
     * @var string|null
     */
    public $customDeviceId = null;

    /**
     * Login attempt counter.
     *
     * @var int
     */
    public $loginAttemptCount = 0;

    /**
     * The radio type used for requests.
     *
     * @var array
     */
    public $radio_type = 'wifi-none';

    /**
     * Timezone offset.
     *
     * @var int
     */
    public $timezoneOffset = null;

    /**
     * The platform used for requests.
     *
     * @var string
     */
    public $platform;

    /**
     * Connection speed.
     *
     * @var string
     */
    public $connectionSpeed = '-1kbps';

    /**
     * VP9 Capable.
     *
     * @var string
     */
    public $vp9Capable = 'true';

    /**
     * EU user.
     *
     * @var bool
     */
    public $isEUUser = true;

    /**
     * Battery level.
     *
     * @var int
     */
    public $batteryLevel = 100;

    /**
     * Device charging.
     *
     * @var bool
     */
    public $isDeviceCharging = true;

    /**
     * Locale.
     *
     * @var string
     */
    public $locale = '';

    /**
     * App locale.
     *
     * @var string
     */
    public $app_locale = '';

    /**
     * App locale.
     *
     * @var string
     */
    public $app_startup_country = '';

    /**
     * Accept language.
     *
     * @var string
     */
    public $acceptLanguage = '';

    /**
     * Event batch collection.
     *
     * @var array
     */
    public $eventBatch = [];

    /**
     * Batch index.
     *
     * @var int
     */
    public $batchIndex = 0;

    /**
     * Navigation sequence.
     *
     * @var int
     */
    public $navigationSequence = 0;

    /**
     * Checkpoints
     *
     * @var bool
     */
    public $isWebLogin = false;
    public $_needsAuth = true;
    public $_skipProxy = false;
    public $csrfToken = null;

    /** @var Request\Account Collection of Account related functions. */
    public $account;
    /** @var Request\Business Collection of Business related functions. */
    public $business;
    /** @var Request\Collection Collection of Collections related functions. */
    public $collection;
    /** @var Request\Creative Collection of Creative related functions. */
    public $creative;
    /** @var Request\Direct Collection of Direct related functions. */
    public $direct;
    /** @var Request\Discover Collection of Discover related functions. */
    public $discover;
    /** @var Request\Event Collection of Event related functions. */
    public $event;
    /** @var Request\Hashtag Collection of Hashtag related functions. */
    public $hashtag;
    /** @var Request\Highlight Collection of Highlight related functions. */
    public $highlight;
    /** @var Request\TV Collection of Instagram TV functions. */
    public $tv;
    /** @var Request\Internal Collection of Internal (non-public) functions. */
    public $internal;
    /** @var Request\Live Collection of Live related functions. */
    public $live;
    /** @var Request\Location Collection of Location related functions. */
    public $location;
    /** @var Request\Media Collection of Media related functions. */
    public $media;
    /** @var Request\Reels Collection of Reels related functions. */
    public $reels;
    /** @var Request\Music Collection of Music related functions. */
    public $music;
    /** @var Request\People Collection of People related functions. */
    public $people;
    /** @var Request\Push Collection of Push related functions. */
    public $push;
    /** @var Request\Shopping Collection of Shopping related functions. */
    public $shopping;
    /** @var Request\Story Collection of Story related functions. */
    public $story;
    /** @var Request\Timeline Collection of Timeline related functions. */
    public $timeline;
    /** @var Request\Usertag Collection of Usertag related functions. */
    public $usertag;

    /**
     * Constructor.
     *
     * @param bool  $debug          Show API queries and responses.
     * @param bool  $truncatedDebug Truncate long responses in debug.
     * @param array $storageConfig  Configuration for the desired
     *                              user settings storage backend.
     * @param bool   $platform      The platform to be emulated. 'android' or 'ios'.
     *
     * @throws \InstagramAPI\Exception\InstagramException
     */
    public function __construct(
        $debug = false,
        $truncatedDebug = false,
        array $storageConfig = [],
        $platform = 'ios')
    {
        if ($platform !== 'android' && $platform !== 'ios') {
            throw new \InvalidArgumentException(sprintf('"%s" is not a valid platform.', $platform));
        } else {
            $this->platform = $platform;
        }
        
        // Disable incorrect web usage by default. People should never embed
        // this application emulator library directly in a webpage, or they
        // might cause all kinds of damage and data corruption. They should
        // use an intermediary layer such as a database or a permanent process!
        // NOTE: People can disable this safety via the flag at their own risk.
        if (!self::$allowDangerousWebUsageAtMyOwnRisk && (!defined('PHP_SAPI') || PHP_SAPI !== 'cli')) {
            // IMPORTANT: We do NOT throw any exception here for users who are
            // running the library via a webpage. Many webservers are configured
            // to hide all PHP errors, and would just give the user a totally
            // blank webpage with "Error 500" if we throw here, which would just
            // confuse the newbies even more. Instead, we output a HTML warning
            // message for people who try to run the library on a webpage.
            echo file_get_contents(__DIR__.'/../webwarning.htm');
            echo '<p>If you truly want to enable <em>incorrect</em> website usage by directly embedding this application emulator library in your page, then you can do that <strong>AT YOUR OWN RISK</strong> by setting the following flag <em>before</em> you create the <code>Instagram()</code> object:</p>'.PHP_EOL;
            echo '<p><code>\InstagramAPI\Instagram::$allowDangerousWebUsageAtMyOwnRisk = true;</code></p>'.PHP_EOL;
            exit(0); // Exit without error to avoid triggering Error 500.
        }

        // Prevent people from running this library on ancient PHP versions, and
        // verify that people have the most critically important PHP extensions.
        // NOTE: All of these are marked as requirements in composer.json, but
        // some people install the library at home and then move it somewhere
        // else without the requirements, and then blame us for their errors.
        if (!defined('PHP_VERSION_ID') || PHP_VERSION_ID < 50600) {
            throw new \InstagramAPI\Exception\InstagramException(
                'You must have PHP 5.6 or higher to use the Instagram API library.'
            );
        }

        static $extensions = ['curl', 'mbstring', 'gd', 'exif', 'zlib'];
        foreach ($extensions as $ext) {
            if (!@extension_loaded($ext)) {
                throw new \InstagramAPI\Exception\InstagramException(sprintf(
                    'You must have the "%s" PHP extension to use the Instagram API library.',
                    $ext
                ));
            }
        }

        // Check cURL version and required features
        if (function_exists('curl_version')) {
            $curl_version = isset(curl_version()["version"]) ? curl_version()["version"] : '';
            if (!empty($curl_version) && version_compare($curl_version, '7.61', '<')) {
                throw new \InstagramAPI\Exception\InstagramException(
                    'You must have cURL 7.61 or higher to use the Instagram API library.'
                );
            }
            $http2_supported = (curl_version()['features'] & CURL_HTTP_VERSION_2);
            if (!$http2_supported) {
                throw new \InstagramAPI\Exception\InstagramException(
                    'Your cURL should be compiled with HTTP2 feature to use the Instagram API library.'
                );
            }
        }

        // Check Ramsey\Uuid library exist
        if (!class_exists('Ramsey\Uuid\Uuid')) {
            throw new \InstagramAPI\Exception\InstagramException(sprintf(
                'You must have the %s to use the Instagram API library.',
                '<a target="_blank" href="https://github.com/ramsey/uuid">Ramsey\Uuid library</a>'
            ));
        }

        // Debugging options.
        $this->debug = $debug;
        $this->truncatedDebug = $truncatedDebug;

        // Load all function collections.
        $this->account = new Request\Account($this);
        $this->business = new Request\Business($this);
        $this->collection = new Request\Collection($this);
        $this->creative = new Request\Creative($this);
        $this->direct = new Request\Direct($this);
        $this->discover = new Request\Discover($this);
        $this->event = new Request\Event($this);
        $this->hashtag = new Request\Hashtag($this);
        $this->highlight = new Request\Highlight($this);
        $this->tv = new Request\TV($this);
        $this->internal = new Request\Internal($this);
        $this->live = new Request\Live($this);
        $this->location = new Request\Location($this);
        $this->media = new Request\Media($this);
        $this->reels = new Request\Reels($this);
        $this->music = new Request\Music($this);
        $this->people = new Request\People($this);
        $this->push = new Request\Push($this);
        $this->shopping = new Request\Shopping($this);
        $this->story = new Request\Story($this);
        $this->timeline = new Request\Timeline($this);
        $this->usertag = new Request\Usertag($this);

        // Configure the settings storage and network client.
        $self = $this;
        $this->settings = Settings\Factory::createHandler(
            $storageConfig,
            [
                // This saves all user session cookies "in bulk" at script exit
                // or when switching to a different user, so that it only needs
                // to write cookies to storage a few times per user session:
                'onCloseUser' => function ($storage) use ($self) {
                    if ($self->client instanceof Client) {
                        $self->client->saveCookieJar();
                    }
                },
            ]
        );
        $this->client = new Client($this);
        $this->experiments = [];
    }

    /**
     * Controls the SSL verification behavior of the Client.
     *
     * @see http://docs.guzzlephp.org/en/latest/request-options.html#verify
     *
     * @param bool|string $state TRUE to verify using PHP's default CA bundle,
     *                           FALSE to disable SSL verification (this is
     *                           insecure!), String to verify using this path to
     *                           a custom CA bundle file.
     */
    public function setVerifySSL(
        $state)
    {
        $this->client->setVerifySSL($state);
    }

    /**
     * Gets the current SSL verification behavior of the Client.
     *
     * @return bool|string
     */
    public function getVerifySSL()
    {
        return $this->client->getVerifySSL();
    }

    /**
     * Set the proxy to use for requests.
     *
     * @see http://docs.guzzlephp.org/en/latest/request-options.html#proxy
     *
     * @param string|array|null $value String or Array specifying a proxy in
     *                                 Guzzle format, or NULL to disable
     *                                 proxying.
     */
    public function setProxy(
        $value)
    {
        $this->client->setProxy($value);
    }

    /**
     * Gets the current proxy used for requests.
     *
     * @return string|array|null
     */
    public function getProxy()
    {
        return $this->client->getProxy();
    }

    /**
     * Set the IP rotation link for the proxy
     *
     * @param string $value URL to change proxy IP (feature of mobile proxies)
     */
    public function setRotationLink(
        $value)
    {
        $this->rotationLink = $value;
    }

    /**
     * Get the IP rotation link for the proxy
     * 
     * @return string|null
     */
    public function getRotationLink()
    {
        return $this->rotationLink;
    }

    /**
     * Set a custom device string.
     *
     * If the provided device string is not valid, a device from
     * the good devices list will be chosen randomly.
     *
     * @param string|null $value Device string.
     */
    public function setDeviceString(
        $value)
    {
        $this->customDeviceString = $value;
    }

    /**
     * Set a custom device ID.
     *
     * @param string|null $value Device string.
     */
    public function setCustomDeviceId(
        $value)
    {
        $this->customDeviceId = $value;
    }

    /**
     * Sets the network interface override to use.
     *
     * Only works if Guzzle is using the cURL backend. But that's
     * almost always the case, on most PHP installations.
     *
     * @see http://php.net/curl_setopt CURLOPT_INTERFACE
     *
     * @param string|null $value Interface name, IP address or hostname, or NULL
     *                           to disable override and let Guzzle use any
     *                           interface.
     */
    public function setOutputInterface(
        $value)
    {
        $this->client->setOutputInterface($value);
    }

    /**
     * Gets the current network interface override used for requests.
     *
     * @return string|null
     */
    public function getOutputInterface()
    {
        return $this->client->getOutputInterface();
    }

    /**
     * Set the radio type used for requests.
     *
     * @param string $value String specifying the radio type.
     */
    public function setRadioType(
        $value)
    {
        if ($value !== 'wifi-none' && $value !== 'mobile-lte') {
            throw new \InvalidArgumentException(sprintf('"%s" is not a valid radio type.', $value));
        }

        $this->radio_type = $value;
    }

    /**
     * Get the radio type used for requests.
     *
     * @return string
     */
    public function getRadioType()
    {
        return $this->radio_type;
    }

    /**
     * Set the timezone offset.
     *
     * @param int $value Timezone offset.
     */
    public function setTimezoneOffset(
        $value)
    {
        $this->timezoneOffset = $value;
    }

    /**
     * Get timezone offset.
     *
     * @return string
     */
    public function getTimezoneOffset()
    {
        return $this->timezoneOffset;
    }

    /**
     * Set locale.
     *
     * @param string $value
     */
    public function setLocale(
        $value)
    {
        preg_match('/^[a-z]{2}_[A-Z]{2}$/', $value, $matches, PREG_OFFSET_CAPTURE, 0);

        if (!empty($matches)) {
            $this->locale = $value;
        } else {
            throw new \InvalidArgumentException(sprintf('"%s" is not a valid locale.', $value));
        }
    }

    /**
     * Get locale.
     *
     * @return string
     */
    public function getLocale()
    {
        if ($this->locale === '') {
            return Constants::USER_AGENT_LOCALE;
        } else {
            return $this->locale;
        }
    }

    /**
     * Set app locale.
     *
     * @param string $value
     */
    public function setAppLocale(
        $value)
    {
        preg_match('/^[a-z]{2}$/', $value, $matches, PREG_OFFSET_CAPTURE, 0);

        if (!empty($matches)) {
            $this->app_locale = $value;
        } else {
            throw new \InvalidArgumentException(sprintf('"%s" is not a valid locale.', $value));
        }
    }

    /**
     * Get app locale.
     *
     * @return string
     */
    public function getAppLocale()
    {
        if ($this->app_locale === '') {
            return Constants::APP_LOCALE;
        } else {
            return $this->app_locale;
        }
    }

    /**
     * Set X-Ig-Nav-Chain header for request 
     *
     * @param string $value
     * @param bool   $resetAfterRequest Clean X-Ig-Nav-Chain header after request, 
     *                                  in some cases we need to auto-clean that header, 
     */
    public function setNavChainHeader(
        $value,
        $resetAfterRequest = false)
    {
        $this->client->_navChain = $value;
        $this->client->_resetNavChain = $resetAfterRequest;
    }

    /**
     * Get X-Ig-Nav-Chain header of request
     *
     * @return string
     */
    public function getNavChainHeader()
    {
        return $this->client->_navChain;
    }

    /**
     * Set X-Ig-Client-Endpoint header for request 
     *
     * @param string $value
     * @param bool   $resetAfterRequest Clean X-Ig-Client-Endpoint header after request, 
     *                                  in some cases we need to auto-clean that header, 
     */
    public function setClientEndpointHeader(
        $value,
        $resetAfterRequest = false)
    {
        $this->client->_clientEndpoint = $value;
        $this->client->_resetClientEndpoint = $resetAfterRequest;
    }

    /**
     * Get X-Ig-Client-Endpoint header of request
     *
     * @return string
     */
    public function getClientEndpointHeader()
    {
        return $this->client->_clientEndpoint;
    }

    /**
     * Set startup country
     * 
     * @param string $value
     */
    public function setStartupCountry(
        $value)
    {
        $this->app_startup_country = $value;
    }


    /**
     * Get startup country.
     *
     * @return string
     */
    public function getStartupCountry()
    {
        if (!empty($this->app_startup_country)) {
            return $this->app_startup_country;
        } else {
            return Constants::APP_STARTUP_COUNTRY;
        }
    }

    /**
     * Set accept Language.
     *
     * @param string $value
     */
    public function setAcceptLanguage(
        $value)
    {
        preg_match('/^[a-z]{2}-[A-Z]{2}$/', $value, $matches, PREG_OFFSET_CAPTURE, 0);

        if (!empty($matches)) {
            $this->acceptLanguage = $value;
        } else {
            throw new \InvalidArgumentException(sprintf('"%s" is not a valid accept language value.', $value));
        }
    }

    /**
     * Get Accept Language.
     *
     * @return string
     */
    public function getAcceptLanguage()
    {
        if ($this->acceptLanguage === '') {
            return Constants::ACCEPT_LANGUAGE;
        } else {
            return $this->acceptLanguage;
        }
    }

    /**
     * Get the platform used for requests.
     *
     * @return string
     */
    public function getPlatform()
    {
        return $this->platform;
    }

    /**
     * Check if running on Android platform.
     *
     * @return string
     */
    public function getIsAndroid()
    {
        return $this->platform === 'android';
    }

    /**
     * Check if using an android session.
     *
     * @return bool
     */
    public function getIsAndroidSession()
    {
        if (strpos($this->settings->get('device_id'), 'android') !== false) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Get the connection speed.
     *
     * @return string
     */
    public function getConnectionSpeed()
    {
        return '-1kbps';
    }

    /**
     * Set the connection speed.
     *
     * @param string $value Connection Speed. Format: '53kbps'.
     */
    public function setConnectionSpeed(
        $value)
    {
        $this->connectionSpeed = $value;
    }

    /**
     * Get VP9 capable.
     *
     * @return string
     */
    public function getVP9Capable()
    {
        return $this->vp9Capable;
    }

    /**
     * Enable/Disable VP9 capable.
     *
     * @param string $value. 'true' or 'false'
     */
    public function enableVP9Capable(
        $value = 'true')
    {
        $this->vp9Capable = $value;
    }

    /**
     * Get if user is in EU.
     *
     * @return bool
     */
    public function getIsEUUser()
    {
        return $this->isEUUser;
    }

    /**
     * Set if user is from EU.
     *
     * @param bool $value. 'true' or 'false'
     */
    public function setIsEUUser(
        $value)
    {
        $this->isEUUser = $value;
    }

    /**
     * Get battery level.
     *
     * @return int
     */
    public function getBatteryLevel()
    {
        return $this->batteryLevel;
    }

    /**
     * Set battery level.
     *
     * @param int $value.
     */
    public function setBatteryLevel(
        $value)
    {
        if ($value < 1 && $value > 100) {
            throw new \InvalidArgumentException(sprintf('"%d" is not a valid battery level.', $value));
        }

        $this->batteryLevel = $value;
    }

    /**
     * Get if device is charging.
     *
     * @return string
     */
    public function getIsDeviceCharging()
    {
        return strval($this->isDeviceCharging);
    }

    /**
     * Set if device is charging.
     *
     * @param bool $value.
     */
    public function setIsDeviceCharging(
        $value)
    {
        $this->isDeviceCharging = $value;
    }

    /**
     * Get if device is VP9 compatible.
     *
     * @return bool
     */
    public function getIsVP9Compatible()
    {
        return $this->device->getIsVP9Compatible();
    }

    /**
     * Login to Instagram or automatically resume and refresh previous session.
     *
     * Sets the active account for the class instance. You can call this
     * multiple times to switch between multiple Instagram accounts.
     *
     * WARNING: You MUST run this function EVERY time your script runs! It
     * handles automatic session resume and relogin and app session state
     * refresh and other absolutely *vital* things that are important if you
     * don't want to be banned from Instagram!
     *
     * WARNING: This function MAY return a CHALLENGE telling you that the
     * account needs two-factor login before letting you log in! Read the
     * two-factor login example to see how to handle that.
     *
     * @param string $username           Your Instagram username.
     *                                   You can also use your email or phone,
     *                                   but take in mind that they won't work
     *                                   when you have two factor auth enabled.
     * @param string $password           Your Instagram password.
     * @param int    $appRefreshInterval How frequently `login()` should act
     *                                   like an Instagram app that's been
     *                                   closed and reopened and needs to
     *                                   "refresh its state", by asking for
     *                                   extended account state details.
     *                                   Default: After `1800` seconds, meaning
     *                                   `30` minutes after the last
     *                                   state-refreshing `login()` call.
     *                                   This CANNOT be longer than `6` hours.
     *                                   Read `_sendLoginFlow()`! The shorter
     *                                   your delay is the BETTER. You may even
     *                                   want to set it to an even LOWER value
     *                                   than the default 30 minutes!
     *
     * @throws \InvalidArgumentException
     * @throws \InstagramAPI\Exception\InstagramException
     *
     * @return \InstagramAPI\Response\LoginResponse|null A login response if a
     *                                                   full (re-)login
     *                                                   happens, otherwise
     *                                                   `NULL` if an existing
     *                                                   session is resumed.
     */
    public function login(
        $username,
        $password,
        $appRefreshInterval = 1800)
    {
        if (empty($username) || empty($password)) {
            throw new \InvalidArgumentException('You must provide a username and password to login().');
        }
        if ($this->isWebLogin) { 
            return $this->loginGraph($username, $password, false, $appRefreshInterval);
        } else {
            return $this->_login($username, $password, false, $appRefreshInterval);
        }
    }

    /**
     * Detect web static js hashes (Web API)
     * 
     * @throws \InstagramAPI\Exception\InstagramException
     * 
     */
    public function getHashesGraph($version = 5) 
    {
        $this->isWebLogin = true;
        
        $detected = false;
        $detect_retries = 0;
        $detect_retries_max = 3;
        $missing_data = 'Pre-login web session hashes not detected in loginGraph(). Missing hashe(s) is ';
        do {
            if ($detect_retries >= $detect_retries_max) { 
                if (empty($constants["rollout_hash"])) {
                    $missing_data .= 'rollout_hash;';
                }
                if (empty($constants["public_key"])) {
                    $missing_data .= 'public_key;';
                }
                if (empty($constants["key_id"])) {
                    $missing_data .= 'key_id;';
                }
                if (empty($constants["asbd_id"])) {
                    $missing_data .= 'asbd_id;';
                }
                if (empty($constants["csrf_token"])) {
                    $missing_data .= 'csrf_token;';
                }
                throw new \InstagramAPI\Exception\InstagramException($missing_data);
            }

            $constants = $this->getDataFromWeb($version);

            $detect_retries++;

            if (!empty($constants["rollout_hash"]) && 
                !empty($constants["public_key"]) && 
                !empty($constants["key_id"]) && 
                !empty($constants["asbd_id"]) &&
                !empty($constants["csrf_token"])) 
            {
                $detected = true;
            } else {
                sleep(3);
            }
        } while (!$detected);

        // Update hashes
        $this->csrfToken = (string) $constants["csrf_token"];
        $this->settings->set('rollout_hash', (string) $constants["rollout_hash"]);
        $this->settings->set('public_key', (string) $constants["public_key"]);
        $this->settings->set('public_key_id', (string) $constants["key_id"]);
        $this->settings->set('asbd_id', (string) $constants["asbd_id"]);
        $this->settings->set('query_hash_guf', !empty($constants["query_hash_guf"]) ? (string) $constants["query_hash_guf"] : '32b14723a678bd4628d70c1f877b94c9');
        $this->settings->set('query_hash_glk', !empty($constants["query_hash_glk"]) ? (string) $constants["query_hash_glk"] : 'd5d763b1e2acf209d62d22d184488e57');
        $this->settings->set('query_hash_gtf', !empty($constants["query_hash_gtf"]) ? (string) $constants["query_hash_gtf"] : 'c699b185975935ae2a457f24075de8c7');

        // Deprecated hashes
        $this->settings->set('query_hash_gh', "9b498c08113f1e09617a1703c22b2f32"); // query_hash for getFeedGraph() function for hashtag 
        $this->settings->set('query_hash_gl', "36bd0f2bf5911908de389b8ceaa3be6d"); // query_hash for getFeedGraph() function for location
        $this->settings->set('query_hash_gr', "c9c56db64beb4c9dea2d17740d0259d9"); // query_hash for getReelsMediaFeedGraph() function for location
        $this->settings->set('query_hash_gfs', "5aefa9893005572d237da5068082d8d5"); // query_hash for getFollowersgraph() function
        $this->settings->set('query_hash_gfg', "3dec7e2c57367ef3da3d987d89f9dbc8"); // query_hash for getFollowingGraph() function

        return true;
    }

    /**
     * Login to Instagram (Web API)
     * 
     * @param string $username
     * @param string $password
     * @param bool   $forceLogin         Force login to Instagram instead of
     *                                   resuming previous session. Used
     *                                   internally to do a new, full relogin
     *                                   when we detect an expired/invalid
     *                                   previous session.
     * @param int    $appRefreshInterval
     *
     * @throws \InvalidArgumentException
     * @throws \InstagramAPI\Exception\InstagramException
     *
     * @return \InstagramAPI\Response\LoginResponse|null
     */
    public function loginGraph(
        $username,
        $password,
        $forceLogin = false,
        $appRefreshInterval = 1800) 
    {
        $this->isWebLogin = true;

        if ($this->username !== $username || $this->password !== $password) {
            $this->_setUser($username, $password);
        }

        // Check is this is a first login attempt
        $lastLoginTime = $this->settings->get('last_login_web');
        if ($lastLoginTime === null) {
            $this->isMaybeLoggedIn = false;
            $this->account_id = null;
        }

        // Perform a full relogin if necessary.
        if (!$this->isMaybeLoggedIn || $forceLogin) {
            $this->getHashesGraph();

            try {
                $request = $this->request('accounts/login/ajax/')
                    ->setVersion(5)
                    ->setNeedsAuth(false)
                    ->setSignedPost(false)
                    ->setAddDefaultHeaders(false)
                    ->addHeader('X-Asbd-Id', $this->settings->get('asbd_id'))
                    ->addHeader('X-CSRFToken', $this->csrfToken)
                    ->addHeader('Referer', 'https://www.instagram.com/')
                    ->addHeader('X-Requested-With', 'XMLHttpRequest')
                    ->addHeader('X-Ig-App-Id', Constants::IG_WEB_APPLICATION_ID)
                    ->addHeader('X-Instagram-AJAX', $this->settings->get('rollout_hash'));

                    if ($this->account_id && !$forceLogin) {
                        $query = [
                            'next'        => '/accounts/access_tool/',
                            'oneTapUsers' => [$this->account_id],
                        ];

                        $request->addPost('optIntoOneTap', true)
                                ->addPost('queryParams', json_encode([
                                    'next'        => '/accounts/access_tool/',
                                    'oneTapUsers' => [$this->account_id],
                                ]));
                    } else {
                        $request->addPost('optIntoOneTap', false)
                                ->addPost('queryParams', '{}');
                    }

                    $request->addHeader('Referer', 'https://www.instagram.com/accounts/login/')
                        ->addPost('username', $username)
                        ->addPost('enc_password', Utils::encryptPasswordGraph($password, $this->settings->get('public_key_id'), $this->settings->get('public_key')));

                $response = $request->getResponse(new Response\LoginResponse());
            } catch (\InstagramAPI\Exception\ThrottledException $e) {
                if (function_exists("\Plugins\ProxyManagerPro\changeIp") && $this->loginAttemptCount == 0) {
                    $this->loginAttemptCount++;
                    \Plugins\ProxyManagerPro\changeIp($this->getProxy());
                    sleep(10);
                    return $this->loginGraph($username, $password, $forceLogin, $appRefreshInterval);
                } elseif (!empty($this->getRotationLink()) && $this->loginAttemptCount == 0) {
                    $this->loginAttemptCount++;
                    $this->changeIp($this->getRotationLink());
                    sleep(10);
                    return $this->loginGraph($username, $password, $forceLogin, $appRefreshInterval);
                } else {
                    throw $e;
                }
            } catch (\InstagramAPI\Exception\CheckpointRequiredException $e) {
                // Login failed because checkpoint is required.
                // Return server response to tell user they to bypass checkpoint.
                if ($e->hasResponse() && $e->getResponse()->isCheckpointUrl()) {
                    $api_path = $e->getResponse()->getCheckpointUrl();

                    $challenge_model = new \InstagramAPI\Response\Model\Challenge();    
                    $challenge_model->setApiPath($api_path);

                    $challenge = new \InstagramAPI\Response\ChallengeResponse();
                    $challenge->setChallenge($challenge_model);

                    $e = new \InstagramAPI\Exception\ChallengeRequiredException('checkpoint_challenge_required');
                    $e->setResponse($challenge);

                    throw $e;
                } else {
                    throw $e;
                } 
            } catch (\InstagramAPI\Exception\ChallengeRequiredException $e) {
                // Login failed because challenge is required.
                // Return server response to tell user they to bypass challenge.
                throw $e;
            } catch (\InstagramAPI\Exception\InstagramException $e) {
                if ($e->hasResponse() && $e->getResponse()->isTwoFactorRequired()) {
                    // Login failed because two-factor login is required.
                    // Return server response to tell user they need 2-factor.
                    return $e->getResponse();
                } else {
                    // Login failed for some other reason... Re-throw error.
                    throw $e;
                }
            }

            $login_resp = json_decode($response, true);

            if (isset($login_resp["authenticated"])) {
                if ($login_resp["authenticated"] === true) {
                    if (isset($login_resp["userId"]) && $login_resp["userId"]) {
                        $this->account_id = $login_resp["userId"];
                        $this->settings->set('account_id', $this->account_id);
                    } 
                    $this->isMaybeLoggedIn = true;
                    $this->settings->set('last_login_web', time());
                } else {
                    if (isset($login_resp["user"])) {
                        if ($login_resp["user"] === true) {
                            throw new \InstagramAPI\Exception\IncorrectPasswordException("Sorry, your password was incorrect. Please double-check your account password.");
                        } else {
                            throw new \InstagramAPI\Exception\InvalidUserException("The username you set for your account doesn't belong to an account. Please check your username and try again.");
                        }
                    } else {
                        throw new \InstagramAPI\Exception\InstagramException("Invalid login response in loginGraph() function (2).");
                    }
                }
            } else {
                throw new \InstagramAPI\Exception\InstagramException("Invalid login response in loginGraph() function (1).");
            }

            $this->_sendLoginFlowGraph(true, $appRefreshInterval);

            // Full (re-)login successfully completed. Return server response.
            return $response;
        }

        // Attempt to resume an existing session, or full re-login if necessary.
        // NOTE: The "return" here gives a LoginResponse in case of re-login.
        return $this->_sendLoginFlowGraph(false, $appRefreshInterval);
    }

    /**
     * Create session settings for user 
     *
     * @param string $username
     * @param string $password
     * 
     */
    public function changeUser(
        $username,
        $password)
    {
        $this->_setUser($username, $password);
    }

    /**
     * Internal login handler.
     *
     * @param string $username
     * @param string $password
     * @param bool   $forceLogin         Force login to Instagram instead of
     *                                   resuming previous session. Used
     *                                   internally to do a new, full relogin
     *                                   when we detect an expired/invalid
     *                                   previous session.
     * @param int    $appRefreshInterval
     *
     * @throws \InvalidArgumentException
     * @throws \InstagramAPI\Exception\InstagramException
     *
     * @return \InstagramAPI\Response\LoginResponse|null
     *
     * @see Instagram::login() The public login handler with a full description.
     */
    private function _login(
        $username,
        $password,
        $forceLogin = false,
        $appRefreshInterval = 1800)
    {
        if (empty($username) || empty($password)) {
            throw new \InvalidArgumentException('You must provide a username and password to _login().');
        }

        // Switch the currently active user/pass if the details are different.
        if ($this->username !== $username || $this->password !== $password) {
            $this->_setUser($username, $password);
        }

        // Perform a full relogin if necessary.
        if (!$this->isMaybeLoggedIn || $forceLogin) {
            $this->client->_wwwClaim = 0;

            $this->_sendPreLoginFlow();

            try {
                $request = $this->request('accounts/login/')
                    ->setNeedsAuth(false)
                    ->addPost('device_id', $this->device_id)
                    ->addPost('username', $this->username)
                    ->addPost('enc_password', Utils::encryptPassword($password, $this->settings->get('public_key_id'), $this->settings->get('public_key')))
                    ->addPost('phone_id', $this->phone_id)
                    ->addPost('login_attempt_count', $this->loginAttemptCount);

                if ($this->getPlatform() === 'android') {
                    $request->addPost('country_codes', '[{"country_code":"1","source":["default"]}]')
                            ->addPost('guid', $this->uuid)
                            ->addPost('jazoest', Utils::generateJazoest($this->phone_id))
                            ->addPost('adid', $this->advertising_id)
                            ->addPost('google_tokens', '[]');
                } elseif ($this->getPlatform() === 'ios') {
                    $request->addPost('has_seen_aart_on', '0')
                            ->addPost('att_permission_status', '2')
                            ->addPost('reg_login', '0');
                }
                $response = $request->getResponse(new Response\LoginResponse());
            } catch (\InstagramAPI\Exception\ThrottledException $e) {
                if (function_exists("\Plugins\ProxyManagerPro\changeIp") && $this->loginAttemptCount == 0) {
                    $this->loginAttemptCount++;
                    \Plugins\ProxyManagerPro\changeIp($this->getProxy());
                    sleep(10);
                    return $this->_login($username, $password, $forceLogin, $appRefreshInterval);
                } elseif (!empty($this->getRotationLink()) && $this->loginAttemptCount == 0) {
                    $this->loginAttemptCount++;
                    $this->changeIp($this->getRotationLink());
                    sleep(10);
                    return $this->_login($username, $password, $forceLogin, $appRefreshInterval);
                } else {
                    throw $e;
                }
            } catch (\InstagramAPI\Exception\ChallengeRequiredException $e) {
                // Login failed because challenge is required.
                // Return server response to tell user they to bypass checkpoint.
                throw $e;
            } catch (\InstagramAPI\Exception\InstagramException $e) {
                if ($e->hasResponse() && $e->getResponse()->isTwoFactorRequired()) {
                    // Login failed because two-factor login is required.
                    // Return server response to tell user they need 2-factor.
                    // Save two-factor nonce for next API calls
                    if ($e->getResponse()->hasTwoFactorInfo() && $e->getResponse()->getTwoFactorInfo()->hasTrustedNotificationPollingNonce() && !empty($e->getResponse()->getTwoFactorInfo()->getTrustedNotificationPollingNonce())) {
                        $this->settings->set('twofa_nonce', $e->getResponse()->getTwoFactorInfo()->getTrustedNotificationPollingNonce());
                    }
                    return $e->getResponse();
                } elseif ($e->hasResponse() && ($e->getResponse()->getInvalidCredentials() === true)) {
                    $this->loginAttemptCount++;
                    throw $e;
                } elseif ($e->hasResponse() && ($e->getResponse()->getErrorType() === 'ip_block')) {
                    if (function_exists("\Plugins\ProxyManagerPro\changeIp") && $this->loginAttemptCount == 0) {
                        $this->loginAttemptCount++;
                        \Plugins\ProxyManagerPro\changeIp($this->getProxy());
                        sleep(10);
                        return $this->_login($username, $password, $forceLogin, $appRefreshInterval);
                    } elseif (!empty($this->getRotationLink()) && $this->loginAttemptCount == 0) {
                        $this->loginAttemptCount++;
                        $this->changeIp($this->getRotationLink());
                        sleep(10);
                        return $this->_login($username, $password, $forceLogin, $appRefreshInterval);
                    } else {
                        throw new \InstagramAPI\Exception\InstagramException('The authorization attempt was rejected by Instagram server, please try to use different proxy (ip_block)');
                    }
                } else {
                    // Login failed for some other reason... Re-throw error.
                    throw $e;
                }
            }

            $this->loginAttemptCount = 0;
            $this->_updateLoginState($response);

            $this->_sendLoginFlow(true, $appRefreshInterval);

            // Full (re-)login successfully completed. Return server response.
            return $response;
        }

        // Attempt to resume an existing session, or full re-login if necessary.
        // NOTE: The "return" here gives a LoginResponse in case of re-login.
        return $this->_sendLoginFlow(false, $appRefreshInterval);
    }

    /**
     * Login to Instagram with Facebook or automatically resume and refresh previous session.
     *
     * Sets the active account for the class instance. You can call this
     * multiple times to switch between multiple Instagram accounts.
     *
     * WARNING: You MUST run this function EVERY time your script runs! It
     * handles automatic session resume and relogin and app session state
     * refresh and other absolutely *vital* things that are important if you
     * don't want to be banned from Instagram!
     *
     * WARNING: This function MAY return a CHALLENGE telling you that the
     * account needs two-factor login before letting you log in! Read the
     * two-factor login example to see how to handle that.
     *
     * @param string $username           Your Instagram username.
     * @param string $fbAccessToken      Your Facebook access token.
     * @param int    $appRefreshInterval How frequently `loginWithFacebook()` should act
     *                                   like an Instagram app that's been
     *                                   closed and reopened and needs to
     *                                   "refresh its state", by asking for
     *                                   extended account state details.
     *                                   Default: After `1800` seconds, meaning
     *                                   `30` minutes after the last
     *                                   state-refreshing `login()` call.
     *                                   This CANNOT be longer than `6` hours.
     *                                   Read `_sendLoginFlow()`! The shorter
     *                                   your delay is the BETTER. You may even
     *                                   want to set it to an even LOWER value
     *                                   than the default 30 minutes!
     *
     * @throws \InvalidArgumentException
     * @throws \InstagramAPI\Exception\InstagramException
     *
     * @return \InstagramAPI\Response\LoginResponse|null A login response if a
     *                                                   full (re-)login
     *                                                   happens, otherwise
     *                                                   `NULL` if an existing
     *                                                   session is resumed.
     */
    public function loginWithFacebook(
        $username,
        $fbAccessToken,
        $appRefreshInterval = 1800)
    {
        if (empty($username) || empty($fbAccessToken)) {
            throw new \InvalidArgumentException('You must provide a Facebook access token to loginWithFacebook().');
        }

        return $this->_loginWithFacebook($username, $fbAccessToken, false, $appRefreshInterval);
    }

    /**
     * Internal Facebook login handler.
     *
     * @param string $username           Your Instagram username.
     * @param string $fbAccessToken      Facebook access token.
     * @param bool   $forceLogin         Force login to Instagram instead of
     *                                   resuming previous session. Used
     *                                   internally to do a new, full relogin
     *                                   when we detect an expired/invalid
     *                                   previous session.
     * @param int    $appRefreshInterval
     *
     * @throws \InvalidArgumentException
     * @throws \InstagramAPI\Exception\InstagramException
     *
     * @return \InstagramAPI\Response\LoginResponse|null
     *
     * @see Instagram::loginWithFacebook() The public Facebook login handler with a full description.
     */
    protected function _loginWithFacebook(
        $username,
        $fbAccessToken,
        $forceLogin = false,
        $appRefreshInterval = 1800)
    {
        if (empty($fbAccessToken)) {
            throw new \InvalidArgumentException('You must provide an fb_access_token to _loginWithFacebook().');
        }
        // Switch the currently active access token if it is different.
        if ($this->fb_access_token !== $fbAccessToken) {
            $this->_setFacebookUser($username, $fbAccessToken);
        }
        if (!$this->isMaybeLoggedIn || $forceLogin) {
            $this->client->_wwwClaim = 0;

            $this->_sendPreLoginFlow();

            try {
                $response = $this->request('fb/facebook_signup/')
                    ->setNeedsAuth(false)
                    ->addPost('dryrun', 'false')
                    ->addPost('phone_id', $this->phone_id)
                    ->addPost('adid', $this->advertising_id)
                    ->addPost('device_id', $this->device_id)
                    ->addPost('waterfall_id', Signatures::generateUUID())
                    ->addPost('fb_access_token', $this->fb_access_token)
                    ->getResponse(new Response\LoginResponse());
            } catch (\InstagramAPI\Exception\ThrottledException $e) {
                if (function_exists("\Plugins\ProxyManagerPro\changeIp") && $this->loginAttemptCount == 0) {
                    $this->loginAttemptCount++;
                    \Plugins\ProxyManagerPro\changeIp($this->getProxy());
                    sleep(10);
                    return $this->_loginWithFacebook($username, $fbAccessToken, $forceLogin, $appRefreshInterval);
                } elseif (!empty($this->getRotationLink()) && $this->loginAttemptCount == 0) {
                    $this->loginAttemptCount++;
                    $this->changeIp($this->getRotationLink());
                    sleep(10);
                    return $this->_loginWithFacebook($username, $fbAccessToken, $forceLogin, $appRefreshInterval);
                } else {
                    throw $e;
                }
            } catch (\InstagramAPI\Exception\InstagramException $e) {
                if ($e->hasResponse() && $e->getResponse()->isTwoFactorRequired()) {
                    // Login failed because two-factor login is required.
                    // Return server response to tell user they need 2-factor.
                    return $e->getResponse();
                } elseif ($e->hasResponse() && ($e->getResponse()->getInvalidCredentials() === true)) {
                    ++$this->loginAttemptCount;
                } else {
                    if ($e->getResponse() === null) {
                        throw new \InstagramAPI\Exception\NetworkException($e);
                    }
                    // Login failed for some other reason... Re-throw error.
                    throw $e;
                }
            }
            $this->loginAttemptCount = 0;
            $this->_updateLoginState($response);

            $this->_sendLoginFlow(true, $appRefreshInterval);

            // Full (re-)login successfully completed. Return server response.
            return $response;
        }

        // Attempt to resume an existing session, or full re-login if necessary.
        // NOTE: The "return" here gives a LoginResponse in case of re-login.
        return $this->_sendLoginFlow(false, $appRefreshInterval);
    }

    /**
     * Finish a two-factor authenticated login.
     *
     * This function finishes a two-factor challenge that was provided by the
     * regular `login()` function. If you successfully answer their challenge,
     * you will be logged in after this function call.
     *
     * @param string      $username            Your Instagram username used for login.
     *                                         Email and phone aren't allowed here.
     * @param string      $password            Your Instagram password.
     * @param string      $twoFactorIdentifier Two factor identifier, obtained in
     *                                         login() response. Format: `123456`.
     * @param string      $verificationCode    Verification code you have received
     *                                         via SMS.
     * @param string      $verificationMethod  The verification method for 2FA. 1 is SMS,
     *                                         2 is backup codes and 3 is TOTP.
     * @param int         $appRefreshInterval  See `login()` for description of this
     *                                         parameter.
     * @param string|null $usernameHandler     Instagram username sent in the login response.
     *                                         Email and phone aren't allowed here.
     * @param bool        $trustDevice         If you want to trust the used Device ID.
     *
     * @throws \InvalidArgumentException
     * @throws \InstagramAPI\Exception\InstagramException
     *
     * @return \InstagramAPI\Response\LoginResponse
     */
    public function finishTwoFactorLogin(
        $username,
        $password,
        $twoFactorIdentifier,
        $verificationCode,
        $verificationMethod = '1',
        $appRefreshInterval = 1800,
        $usernameHandler = null,
        $trustDevice = true)
    {
        if (empty($username) || empty($password)) {
            throw new \InvalidArgumentException('You must provide a username and password to finishTwoFactorLogin().');
        }
        if (!in_array($verificationMethod, ['0', '1', '2', '3', '4', '5'], true)) {
            throw new \InvalidArgumentException('You must provide a valid verification method value.');
        }
        if ($verificationMethod !== '4') {
            if (empty($verificationCode) || empty($twoFactorIdentifier)) {
                throw new \InvalidArgumentException('You must provide a verification code and two-factor identifier to finishTwoFactorLogin().');
            }
        } else {
            $verificationCode = ''; 
        }

        // Switch the currently active user/pass if the details are different.
        // NOTE: The username and password AREN'T actually necessary for THIS
        // endpoint, but this extra step helps people who statelessly embed the
        // library directly into a webpage, so they can `finishTwoFactorLogin()`
        // on their second page load without having to begin any new `login()`
        // call (since they did that in their previous webpage's library calls).
        if ($this->username !== $username || $this->password !== $password) {
            $this->_setUser($username, $password);
        }

        $username = ($usernameHandler !== null) ? $usernameHandler : $username;

        // Remove all whitespace from the verification code.
        $verificationCode = preg_replace('/\s+/', '', $verificationCode);

        if ($this->isWebLogin) {
            $response = $this->request('accounts/login/ajax/two_factor/')
                ->setVersion(5)
                ->setNeedsAuth(false)
                ->setSignedPost(false)
                ->setAddDefaultHeaders(false)
                ->addHeader('Referer', 'https://www.instagram.com/accounts/login/two_factor?next=%2F')
                ->addHeader('X-Asbd-Id', $this->settings->get('asbd_id'))
                ->addHeader('X-CSRFToken', $this->client->getTokenGraph())
                ->addHeader('X-Ig-App-Id', Constants::IG_WEB_APPLICATION_ID)
                ->addHeader('X-Instagram-AJAX', $this->settings->get('rollout_hash'))
                ->addHeader('X-Requested-With', 'XMLHttpRequest')
                ->addPost('identifier', $twoFactorIdentifier)
                ->addPost('trust_signal', true)
                ->addPost('username', $username)
                ->addPost('verificationCode', $verificationCode)
                ->addPost('verification_method', $verificationMethod)
                ->addPost('queryParams', json_encode(['next' => '/']))
                ->getResponse(new Response\LoginResponse());

            $login_resp = json_decode($response, true);

            if (isset($login_resp["authenticated"]) && ($login_resp["authenticated"] === true)) {
                if (isset($login_resp["userId"]) && $login_resp["userId"]) {
                    $this->account_id = $login_resp["userId"];
                    $this->settings->set('account_id', $this->account_id);
                } 
                $this->isMaybeLoggedIn = true;
                $this->settings->set('last_login_web', time());
            } else {
                throw new \InvalidArgumentException('Invalid login response in loginGraph().');
            }

            $this->_sendLoginFlowGraph(true, $appRefreshInterval);

            // Full (re-)login successfully completed. Return server response.
            return $response;
        } else {
            $request = $this->request('accounts/two_factor_login/')
                ->setNeedsAuth(false)
                // 1 - SMS, 2 - Backup codes, 3 - TOTP, 4 - Trusted device, 0 - WhatsApp
                ->addPost('verification_method', $verificationMethod)
                ->addPost('phone_id', $this->phone_id)
                ->addPost('verification_code', $verificationCode)
                ->addPost('trust_this_device', ($trustDevice) ? '1' : '0')
                ->addPost('two_factor_identifier', $twoFactorIdentifier)
                ->addPost('username', $username)
                ->addPost('device_id', $this->device_id)
                ->addPost('guid', $this->uuid);

            $nonce = $this->settings->get('twofa_nonce');
            if (!empty($nonce)) {
                $request->addPost('trusted_notification_polling_nonces', '["' . $nonce . '"]');
            }
                
            $response = $request->getResponse(new Response\LoginResponse());

            $this->_updateLoginState($response);

            $this->_sendLoginFlow(true, $appRefreshInterval);

            return $response;
        }
    }

    /**
     * Check trusted notification status
     *
     * @throws \InvalidArgumentException
     * @throws \InstagramAPI\Exception\InstagramException
     *
     * @return \InstagramAPI\Response\LoginResponse
     */
    public function checkTrustedNotificationStatus(
        $username,
        $password,
        $two_factor_identifier)
    {
        if (empty($username) || empty($password)) {
            throw new \InvalidArgumentException('You must provide a username and password to finishTwoFactorLogin().');
        }

        // Switch the currently active user/pass if the details are different.
        // NOTE: The username and password AREN'T actually necessary for THIS
        // endpoint, but this extra step helps people who statelessly embed the
        // library directly into a webpage, so they can `finishTwoFactorLogin()`
        // on their second page load without having to begin any new `login()`
        // call (since they did that in their previous webpage's library calls).
        if ($this->username !== $username || $this->password !== $password) {
            $this->_setUser($username, $password);
        }
        
        $request = $this->request('two_factor/check_trusted_notification_status/')
            ->setNeedsAuth(false)
            ->addPost('two_factor_identifier', $two_factor_identifier)
            ->addPost('username', $username)
            ->addPost('device_id', $this->uuid);

        $nonce = $this->settings->get('twofa_nonce');
        if (!empty($nonce)) {
            $request->addPost('trusted_notification_polling_nonces', '["' . $nonce . '"]');
        }

        return $request->getResponse(new Response\GenericResponse());
    }

    /**
     * Request a new security code SMS for a Two Factor login account.
     *
     * NOTE: You should first attempt to `login()` which will automatically send
     * you a two factor SMS. This function is just for asking for a new SMS if
     * the old code has expired.
     *
     * NOTE: Instagram can only send you a new code every 60 seconds.
     *
     * @param string $username            Your Instagram username.
     * @param string $password            Your Instagram password.
     * @param string $twoFactorIdentifier Two factor identifier, obtained in
     *                                    `login()` response.
     * @param string $usernameHandler     Instagram username sent in the login response,
     *                                    Email and phone aren't allowed here.
     *                                    Default value is the first argument $username
     *
     * @throws \InstagramAPI\Exception\InstagramException
     *
     * @return \InstagramAPI\Response\TwoFactorLoginSMSResponse
     */
    public function sendTwoFactorLoginSMS(
        $username,
        $password,
        $twoFactorIdentifier,
        $usernameHandler = null)
    {
        if (empty($username) || empty($password)) {
            throw new \InvalidArgumentException('You must provide a username and password to sendTwoFactorLoginSMS().');
        }
        if (empty($twoFactorIdentifier)) {
            throw new \InvalidArgumentException('You must provide a two-factor identifier to sendTwoFactorLoginSMS().');
        }

        // Switch the currently active user/pass if the details are different.
        // NOTE: The password IS NOT actually necessary for THIS
        // endpoint, but this extra step helps people who statelessly embed the
        // library directly into a webpage, so they can `sendTwoFactorLoginSMS()`
        // on their second page load without having to begin any new `login()`
        // call (since they did that in their previous webpage's library calls).
        if ($this->username !== $username || $this->password !== $password) {
            $this->_setUser($username, $password);
        }

        $username = ($usernameHandler !== null) ? $usernameHandler : $username;

        return $this->request('accounts/send_two_factor_login_sms/')
            ->setNeedsAuth(false)
            ->addPost('two_factor_identifier', $twoFactorIdentifier)
            ->addPost('username', $username)
            ->addPost('device_id', $this->device_id)
            ->addPost('guid', $this->uuid)
            ->getResponse(new Response\TwoFactorLoginSMSResponse());
    }

    /**
     * Get verification challenge screen
     * @param  string $apiPath
     * @return mixed 
     */
    public function getChallengeScreen($apiPath) {
        if (!is_string($apiPath) || !$apiPath) {
            throw new \InvalidArgumentException('You must provide a valid apiPath to getChallengeScreen().');
        }

        $apiPath = ltrim($apiPath, "/");

        $nextpost = $this->nextpost_api("ig-api-challenge-screen", true, [
            'apiPath' => $apiPath,
            'isWebLogin' => (int) $this->isWebLogin
        ]);

        if (isset($nextpost->challenge_action)) {
            return $nextpost->challenge_action;
        } else {
            return $nextpost;
        }
    }

    /**
     * Send the choice to get the verification code in case of checkpoint.
     * @param  string $apiPath Challange api path
     * @param  int $choice     Choice of the user. Possible values: 0, 1
     * @return mixed       
     */
    public function sendChallangeCode($apiPath, $choice) 
    {
        if (!is_string($apiPath) || !$apiPath) {
            throw new \InvalidArgumentException('You must provide a valid apiPath to sendChallangeCode().');
        }

        $apiPath = ltrim($apiPath, "/");

        $parts = explode("/", rtrim($apiPath, "/"));
        if (!isset($parts[1]) || !isset($parts[2])) {
            throw new \InstagramAPI\Exception\InstagramException('You must provide a valid apiPath to sendChallangeCode() function.');
        }

        $challenge = $this->getChallengeScreen($apiPath); 

        if (!isset($challenge->step_name)) {
            return $challenge;
        }
        
        if ($challenge->step_name !== "select_verify_method") {
            $this->rewindChallenge($apiPath);
        }

        if ($choice) {
            // Email
            $choice = \InstagramAPI\Constants::CHALLENGE_CHOICE_EMAIL;
            if (!isset($challenge->step_data->email)) {
                $choice = \InstagramAPI\Constants::CHALLENGE_CHOICE_SMS;
            }
        } else {
            // SMS
            $choice = \InstagramAPI\Constants::CHALLENGE_CHOICE_SMS;
            if (!isset($challenge->step_data->phone_number)) {
                $choice = \InstagramAPI\Constants::CHALLENGE_CHOICE_EMAIL;
            }
        }

        // Send choice
        $nextpost = $this->nextpost_api("ig-api-challenge-send-choice", true, [
            'apiPath' => $apiPath,
            'choice' => $choice,
            'isWebLogin' => (int) $this->isWebLogin
        ]);

        if (isset($nextpost->challenge_action->message)) {
            throw new \InstagramAPI\Exception\InstagramException($nextpost->challenge_action->message);
        }

        return $this->getChallengeScreen($apiPath);
    }

    /**
     * Go back to challenge screen to select verification method
     * @param  string $apiPath Challange api path
     * @return Array           
     */
    public function rewindChallenge($apiPath)
    {
        if (!is_string($apiPath) || !$apiPath) {
            throw new \InvalidArgumentException('You must provide a valid apiPath to rewindChallenge().');
        }

        $apiPath = ltrim($apiPath, "/");

        $nextpost = $this->nextpost_api("ig-api-challenge-rewind", true, [
            'apiPath' => $apiPath,
            'isWebLogin' => (int) $this->isWebLogin
        ]);
        
        if (isset($nextpost->challenge_action)) {
            return $nextpost->challenge_action;
        } else {
            return $nextpost;
        }
    }

    /**
     * Re-send the verification code for the challenge
     * @param  string $username Instagram username. Used to load user's settings
     *                          from the database.
     * @param  string $apiPath  Api path to send a resend request
     * @return Array           
     */
    public function resendChallengeCode($username, $apiPath, $choice)
    {
        if (empty($username)) {
            throw new \InvalidArgumentException('You must provide a username resendChallengeCode().');
        }
        
        if (empty($apiPath)) {
            throw new \InvalidArgumentException('You must provide a api path to resendChallengeCode().');
        }

        $this->setUserWithoutPassword($username);

        $apiPath = ltrim($apiPath, "/");

        $apiPath = str_replace('challenge/replay/', 'challenge/', $apiPath);
        $apiPath = str_replace('challenge/', 'challenge/replay/', $apiPath);

        if (!$this->isWebLogin) {
            return $this->request($apiPath)
                ->setNeedsAuth(false)
                ->addPost('choice', $choice)
                ->addPost('guid', $this->uuid)
                ->addPost('device_id', $this->device_id)
                ->getDecodedResponse(false);
        } else {
            return $this->request($apiPath)
                ->setVersion(5)
                ->setNeedsAuth(false)
                ->setSignedPost(false)
                ->setAddDefaultHeaders(false)
                ->addHeader('X-Asbd-Id', $this->settings->get('asbd_id'))
                ->addHeader('X-CSRFToken', $this->client->getTokenGraph())
                ->addHeader('Origin', 'https://www.instagram.com')
                ->addHeader('Referer', 'https://www.instagram.com/' . $apiPath)
                ->addHeader('X-Requested-With', 'XMLHttpRequest')
                ->addHeader('X-Ig-App-Id', \InstagramAPI\Constants::IG_WEB_APPLICATION_ID)
                ->addHeader('X-Instagram-AJAX', $this->settings->get('rollout_hash'))
                ->getDecodedResponse(false);
        }
    }
    
    /**
     * Finish a challenge login
     *
     * This function finishes a checkpoint challenge that was provided by the 
     * sendChallangeCode method. If you successfully answer their challenge,
     * you will be logged in after this function call.
     * 
     * @param  string  $username           Instagram username.
     * @param  string  $password           Instagram password.
     * @param  string  $apiPath            Relative path to the api endpoint 
     *                                     for the challenge.
     * @param  string  $securityCode       Verification code you have received
     *                                     via SMS or Email.
     * @param  integer $appRefreshInterval See `login()` for description of this
     *                                     parameter.
     *
     * @throws \InvalidArgumentException
     * @throws \InstagramAPI\Exception\InstagramException
     * 
     * @return \InstagramAPI\Response\LoginResponse
     */
    public function finishChallengeLogin(
        $username, 
        $password,
        $apiPath, 
        $securityCode, 
        $appRefreshInterval = 1800) 
    {
        if (empty($username) || empty($password)) {
            throw new \InvalidArgumentException('You must provide a username and password to finishChallengeLogin().');
        }
        if (empty($apiPath) || empty($securityCode)) {
            throw new \InvalidArgumentException('You must provide a api path and security code to finishChallengeLogin().');
        }

        // Remove all whitespace from the verification code.
        $securityCode = preg_replace('/\s+/', '', $securityCode);

        $apiPath = ltrim($apiPath, "/");
        $parts = explode("/", rtrim($apiPath, "/"));

        if (!isset($parts[1]) || !isset($parts[2])) {
            throw new \InvalidArgumentException('You must provide a valid apiPath to finishChallengeLogin() function.');
        }

        $this->_setUser($username, $password);

        if (!$this->isWebLogin) {
            $this->_sendPreLoginFlow();

            $response = $this->request($apiPath)
                ->setNeedsAuth(false)
                ->addPost('security_code', $securityCode)
                ->addPost('guid', $this->uuid)
                ->addPost('device_id', $this->device_id)
                ->getResponse(new Response\LoginResponse());

            $this->_updateLoginState($response);
            $this->_sendLoginFlow(true, $appRefreshInterval);
        } else {
            $reponse = $this->request($apiPath)
                ->setVersion(5)
                ->setNeedsAuth(false)
                ->setSignedPost(false)
                ->setAddDefaultHeaders(false)
                ->addPost('security_code', $securityCode)
                ->addHeader('X-Asbd-Id', $this->settings->get('asbd_id'))
                ->addHeader('X-CSRFToken', $this->client->getTokenGraph())
                ->addHeader('Origin', 'https://www.instagram.com')
                ->addHeader('Referer', 'https://www.instagram.com/' . $apiPath)
                ->addHeader('X-Requested-With', 'XMLHttpRequest')
                ->addHeader('X-Ig-App-Id', \InstagramAPI\Constants::IG_WEB_APPLICATION_ID)
                ->addHeader('X-Instagram-AJAX', $this->settings->get('rollout_hash'))
                ->getResponse(new Response\LoginResponse());

            $this->isMaybeLoggedIn = true;

            $this->settings->get('last_login_web', '');
            $this->_sendLoginFlowGraph(false, $appRefreshInterval);

            $user = new Response\Model\User();
            $user->setPk($this->account_id);
            $user->setUsername($username);

            $response = new Response\LoginResponse();
            $response->setLoggedInUser($user);
            $response->setStatus('ok');
        }

        return $response;
    }


    /**
     * Request information about available password recovery methods for an account.
     *
     * This will tell you things such as whether SMS or EMAIL-based recovery is
     * available for the given account name.
     *
     * `WARNING:` You can call this function without having called `login()`,
     * but be aware that a user database entry will be created for every
     * username you try to look up. This is ONLY meant for recovering your OWN
     * accounts.
     *
     * @param string $username Your Instagram username.
     *
     * @throws \InstagramAPI\Exception\InstagramException
     *
     * @return \InstagramAPI\Response\UsersLookupResponse
     */
    public function userLookup(
        $username)
    {
        // Set active user (without pwd), and create database entry if new user.
        $this->setUserWithoutPassword($username);

        return $this->request('users/lookup/')
            ->setNeedsAuth(false)
            ->addPost('q', $username)
            ->addPost('directly_sign_in', true)
            ->addPost('username', $username)
            ->addPost('device_id', $this->device_id)
            ->addPost('guid', $this->uuid)
            ->getResponse(new Response\UsersLookupResponse());
    }

    /**
     * Request a recovery EMAIL to get back into your account.
     *
     * `WARNING:` You can call this function without having called `login()`,
     * but be aware that a user database entry will be created for every
     * username you try to look up. This is ONLY meant for recovering your OWN
     * accounts.
     *
     * @param string $username Your Instagram username.
     *
     * @throws \InstagramAPI\Exception\InstagramException
     *
     * @return \InstagramAPI\Response\RecoveryResponse
     */
    public function sendRecoveryEmail(
        $username)
    {
        // Set active user (without pwd), and create database entry if new user.
        $this->setUserWithoutPassword($username);

        // Verify that they can use the recovery email option.
        $userLookup = $this->userLookup($username);
        if (!$userLookup->getCanEmailReset()) {
            throw new \InstagramAPI\Exception\InternalException('Email recovery is not available, since your account lacks a verified email address.');
        }

        return $this->request('accounts/send_recovery_flow_email/')
            ->setNeedsAuth(false)
            ->addPost('query', $username)
            ->addPost('adid', $this->advertising_id)
            ->addPost('device_id', $this->device_id)
            ->addPost('guid', $this->uuid)
            ->getResponse(new Response\RecoveryResponse());
    }

    /**
     * Request a recovery SMS to get back into your account.
     *
     * `WARNING:` You can call this function without having called `login()`,
     * but be aware that a user database entry will be created for every
     * username you try to look up. This is ONLY meant for recovering your OWN
     * accounts.
     *
     * @param string $username Your Instagram username.
     *
     * @throws \InstagramAPI\Exception\InstagramException
     *
     * @return \InstagramAPI\Response\RecoveryResponse
     */
    public function sendRecoverySMS(
        $username)
    {
        // Set active user (without pwd), and create database entry if new user.
        $this->setUserWithoutPassword($username);
        
        // Verify that they can use the recovery SMS option.
        $userLookup = $this->userLookup($username);
        if (!$userLookup->getHasValidPhone() || !$userLookup->getCanSmsReset()) {
            throw new \InstagramAPI\Exception\InternalException('SMS recovery is not available, since your account lacks a verified phone number.');
        }

        return $this->request('users/lookup_phone/')
            ->setNeedsAuth(false)
            ->addPost('query', $username)
            ->getResponse(new Response\RecoveryResponse());
    }

    /**
     * Set the active account for the class instance.
     *
     * We can call this multiple times to switch between multiple accounts.
     *
     * @param string $username Your Instagram username.
     * @param string $password Your Instagram password.
     *
     * @throws \InvalidArgumentException
     * @throws \InstagramAPI\Exception\InstagramException
     */
    protected function _setUser(
        $username,
        $password)
    {
        if (empty($username) || empty($password)) {
            throw new \InvalidArgumentException('You must provide a username and password to _setUser().');
        }

        // Load all settings from the storage and mark as current user.
        $this->settings->setActiveUser($username);

        // Generate the user's device instance, which will be created from the
        // user's last-used device IF they've got a valid, good one stored.
        // But if they've got a BAD/none, this will create a brand-new device.
        if ($this->customDeviceString !== null) {
            $savedDeviceString = $this->customDeviceString;
            $autoFallback = false;
        } else {
            $savedDeviceString = $this->settings->get('devicestring');
            $is_custom_device = $this->settings->get('is_custom_device');
            if ($is_custom_device) {
                $autoFallback = false;
            } else {
                $autoFallback = true;
            }
        }

        $this->device = new Devices\Device(
            Constants::IG_VERSION,
            Constants::VERSION_CODE,
            $this->getLocale(),
            $savedDeviceString,
            $autoFallback,
            $this->getPlatform()
        );

        // Get active device string so that we can compare it to any saved one.
        $deviceString = $this->device->getDeviceString();

        // Generate a brand-new device fingerprint if the device wasn't reused
        // from settings, OR if any of the stored fingerprints are missing.
        // NOTE: The regeneration when our device model changes is to avoid
        // dangerously reusing the "previous phone's" unique hardware IDs.
        // WARNING TO CONTRIBUTORS: Only add new parameter-checks here if they
        // are CRITICALLY important to the particular device. We don't want to
        // frivolously force the users to generate new device IDs constantly.
        $resetCookieJar = false;
        if ($deviceString !== $savedDeviceString // Brand new device, or missing
            || empty($this->settings->get('uuid')) // one of the critically...
            || empty($this->settings->get('phone_id')) // ...important device...
            || empty($this->settings->get('device_id'))) { // ...parameters.
            // Erase all previously stored device-specific settings and cookies.
            $this->settings->eraseDeviceSettings();

            // Save the chosen device string to settings.
            if ($this->getPlatform() === 'ios') {
                $deviceString = 'ios';
            }

            // Save the chosen device string to settings.
            $this->settings->set('devicestring', $deviceString);
            $this->settings->set('is_custom_device', !empty($this->customDeviceString));

            // Generate hardware fingerprints for the new device.
            if ($this->customDeviceId) {
                $this->settings->set('device_id', $this->customDeviceId);
            } else {
                if ($this->getPlatform() === 'ios') {
                    $this->settings->set('device_id', strtoupper(Signatures::generateUUID()));
                } else {
                    $this->settings->set('device_id', Signatures::generateDeviceId($this->getPlatform()));
                }
            }

            if ($this->getPlatform() === 'ios') {
                $this->settings->set('phone_id', $this->settings->get('device_id'));
            } else {
                $this->settings->set('phone_id', Signatures::generateUUID());
            }

            if ($this->getPlatform() === 'ios') {
                $this->settings->set('uuid', $this->settings->get('device_id'));
            } else {
                $this->settings->set('uuid', Signatures::generateUUID());
            }

            // Erase any stored account ID, to ensure that we detect ourselves
            // as logged-out. This will force a new relogin from the new device.
            $this->settings->set('account_id', '');

            // We'll also need to throw out all previous cookies.
            $resetCookieJar = true;
        }

        // Generate other missing values. These are for less critical parameters
        // that don't need to trigger a complete device reset like above. For
        // example, this is good for new parameters that Instagram introduces
        // over time, since those can be added one-by-one over time here without
        // needing to wipe/reset the whole device.
        if (empty($this->settings->get('advertising_id'))) {
            if ($this->getPlatform() === 'ios') {
                $this->settings->set('advertising_id', strtoupper(Signatures::generateUUID()));
            } else {
                $this->settings->set('advertising_id', Signatures::generateUUID());
            }
        }
        if (empty($this->settings->get('fb_tracking_id'))) {
            if ($this->getPlatform() === 'ios') {
                $this->settings->set('fb_tracking_id', strtoupper(Signatures::generateUUID()));
            } else {
                $this->settings->set('fb_tracking_id', Signatures::generateUUID());
            }
        }
        if (empty($this->settings->get('session_id'))) {
            if ($this->getPlatform() === 'ios') {
                $this->settings->set('session_id', strtoupper(Signatures::generateUUID()));
            } else {
                $this->settings->set('session_id', Signatures::generateUUID());
            }
        }

        // Store various important parameters for easy access.
        $this->username = $username;
        $this->password = $password;
        $this->uuid = $this->settings->get('uuid');
        $this->advertising_id = $this->settings->get('advertising_id');
        $this->fb_tracking_id = $this->settings->get('fb_tracking_id');
        $this->device_id = $this->settings->get('device_id');
        $this->phone_id = $this->settings->get('phone_id');
        $this->session_id = $this->settings->get('session_id');
        $this->experiments = $this->settings->getExperiments();

        // Fix for outdated iOS fingerprints
        if ($this->getPlatform() === 'ios') {
            if ($this->device_id !== $this->phone_id || $this->device_id !== $this->uuid) {
                $this->settings->set('device_id', strtoupper($this->device_id));
                $this->settings->set('phone_id', strtoupper($this->device_id));
                $this->settings->set('uuid', strtoupper($this->device_id));
                $this->settings->set('advertising_id', strtoupper($this->advertising_id));
                $this->settings->set('fb_tracking_id', strtoupper($this->fb_tracking_id));
                $this->settings->set('session_id', strtoupper($this->session_id));
                $this->device_id = $this->settings->get('device_id');
                $this->phone_id = $this->settings->get('phone_id');
                $this->uuid = $this->settings->get('uuid');
                $this->advertising_id = $this->settings->get('advertising_id');
                $this->fb_tracking_id = $this->settings->get('fb_tracking_id');
                $this->session_id = $this->settings->get('session_id');
            }
        }

        $this->client->_authorization = $this->settings->get('authorization');
        $this->client->_wwwClaim = $this->settings->get('x_ig_www_claim');
        $this->client->_MID = $this->settings->get('x_mid');
        $this->client->_DIRECT_REGION_HINT = $this->settings->get('direct_region_hint');
        $this->client->_SHBID = $this->settings->get('shbid');
        $this->client->_SHBTS = $this->settings->get('shbts');
        $this->client->_DS_USER_ID = $this->settings->get('ds_user_id');
        $this->client->_RUR = $this->settings->get('rur');

        // Load the previous session details if we're possibly logged in.
        if (!$resetCookieJar && $this->settings->isMaybeLoggedIn()) {
            $this->isMaybeLoggedIn = true;
            $this->account_id = $this->settings->get('account_id');
        } else {
            $this->isMaybeLoggedIn = false;
            $this->account_id = null;
        }

        // Detect the timezone offset
        $timezone = $this->settings->get('timezone');
        $prev_proxy = $this->settings->get('prev_proxy');
        if (empty($timezone) || $prev_proxy !== $this->client->getProxy()) {
            if (!empty($this->client->getProxy())) {
                $this->settings->set('prev_proxy', $this->client->getProxy());
            } else {
                $this->settings->set('prev_proxy', '');
            }
            $timezone = $this->detectTimezone(3);
            if (!empty($timezone)) {
                $this->settings->set('timezone', $timezone);
            } else {
                $this->settings->set('timezone', '');
            }
        }
        if (!empty($timezone)) {
            $dtz = new \DateTimeZone($timezone);
            $offset = $dtz->getOffset(new \DateTime("now", $dtz));
            if (!empty($offset)) {
                $this->setTimezoneOffset($offset);
            }
        }

        // Configures Client for current user AND updates isMaybeLoggedIn state
        // if it fails to load the expected cookies from the user's jar.
        // Must be done last here, so that isMaybeLoggedIn is properly updated!
        // NOTE: If we generated a new device we start a new cookie jar.
        $this->client->updateFromCurrentSettings($resetCookieJar);
    }

    /**
     * Detect the timezone offset
     */
    public function detectTimezone(
        $retries = 0,
        $timeout = 10)
    {
        $proxy_parts  = explode('://', $this->getProxy());

        try {
            $client = new \GuzzleHttp\Client();
            $res = $client->request('GET', 'https://whoer.net/v2/geoip2-city', [
                "verify" => true,
                "timeout" => $timeout,
                "connect_timeout" => $timeout,
                "proxy" => $proxy_parts[0] == "https" ? $proxy_parts[1] : $this->getProxy(),
                "curl"    => [
                    CURLOPT_USERAGENT => "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.135 Safari/537.36",
                    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_2_0, // Make http client work with HTTP 2/0
                    CURLOPT_SSLVERSION => 1,
                    CURLOPT_SSL_VERIFYPEER => false,
                ],
                "headers" => [
                    "accept-language" => "en-US"
                ],
                // "debug" => true
            ]);

            $resp = json_decode($res->getBody()->getContents(), true);

            if (!empty($resp["time_zone"])) {
                return $resp["time_zone"];
            }
        } catch (\GuzzleHttp\Exception\ConnectException $e) {
            if ($retries > 0) {
                $retries--;
                return $this->detectTimezone($retries, $timeout);
            }
        } catch (\GuzzleHttp\Exception\ClientException $e) {
        } catch (\GuzzleHttp\Exception\ServerException $e) {
        } catch (\GuzzleHttp\Exception\BadResponseException $e) {
        } catch (\GuzzleHttp\Exception\RequestException $e) {
        } catch (\Exception $e) {
        }

        return '';
    }

    /**
     * Set the active Facebook account for the class instance.
     *
     * We can call this multiple times to switch between multiple accounts.
     *
     * @param string $username  Your Instagram username.
     * @param string $fb_access_token  Facebook access token.
     *
     * @throws \InvalidArgumentException
     * @throws \InstagramAPI\Exception\InstagramException
     */
    protected function _setFacebookUser(
        $username,
        $fb_access_token)
    {
        if (empty($username) || empty($fb_access_token)) {
            throw new \InvalidArgumentException('You must provide a username and fb_access_token to _setFacebookUser().');
        }

        // Load all settings from the storage and mark as current user.
        $this->settings->setActiveUser($username);

        // Generate the user's device instance, which will be created from the
        // user's last-used device IF they've got a valid, good one stored.
        // But if they've got a BAD/none, this will create a brand-new device.
        if ($this->customDeviceString !== null) {
            $savedDeviceString = $this->customDeviceString;
            $autoFallback = false;
        } else {
            $savedDeviceString = $this->settings->get('devicestring');
            $is_custom_device = $this->settings->get('is_custom_device');
            if ($is_custom_device) {
                $autoFallback = false;
            } else {
                $autoFallback = true;
            }
        }

        $this->device = new Devices\Device(
            Constants::IG_VERSION,
            Constants::VERSION_CODE,
            $this->getLocale(),
            $savedDeviceString,
            $autoFallback,
            $this->getPlatform()
        );

        // Get active device string so that we can compare it to any saved one.
        $deviceString = $this->device->getDeviceString();

        // Generate a brand-new device fingerprint if the device wasn't reused
        // from settings, OR if any of the stored fingerprints are missing.
        // NOTE: The regeneration when our device model changes is to avoid
        // dangerously reusing the "previous phone's" unique hardware IDs.
        // WARNING TO CONTRIBUTORS: Only add new parameter-checks here if they
        // are CRITICALLY important to the particular device. We don't want to
        // frivolously force the users to generate new device IDs constantly.
        $resetCookieJar = false;
        if ($deviceString !== $savedDeviceString // Brand new device, or missing
            || empty($this->settings->get('uuid')) // one of the critically...
            || empty($this->settings->get('phone_id')) // ...important device...
            || empty($this->settings->get('device_id'))) { // ...parameters.
            // Erase all previously stored device-specific settings and cookies.
            $this->settings->eraseDeviceSettings();

            // Save the chosen device string to settings.
            if ($this->getPlatform() === 'ios') {
                $deviceString = 'ios';
            }

            $this->settings->set('devicestring', $deviceString);
            $this->settings->set('is_custom_device', !empty($this->customDeviceString));

            // Generate hardware fingerprints for the new device.
            if ($this->customDeviceId) {
                $this->settings->set('device_id', $this->customDeviceId);
            } else {
                if ($this->getPlatform() === 'ios') {
                    $this->settings->set('device_id', strtoupper(Signatures::generateDeviceId($this->getPlatform())));
                } else {
                    $this->settings->set('device_id', Signatures::generateDeviceId($this->getPlatform()));
                }
            }

            if ($this->getPlatform() === 'ios') {
                $this->settings->set('phone_id', strtoupper(Signatures::generateUUID()));
            } else {
                $this->settings->set('phone_id', Signatures::generateUUID());
            }

            if ($this->getPlatform() === 'ios') {
                $this->settings->set('uuid', strtoupper(Signatures::generateUUID()));
            } else {
                $this->settings->set('uuid', Signatures::generateUUID());
            }

            $this->settings->set('fb_access_token', $fb_access_token);

            // Erase any stored account ID, to ensure that we detect ourselves
            // as logged-out. This will force a new relogin from the new device.
            $this->settings->set('account_id', '');

            // We'll also need to throw out all previous cookies.
            $resetCookieJar = true;
        }

        // Generate other missing values. These are for less critical parameters
        // that don't need to trigger a complete device reset like above. For
        // example, this is good for new parameters that Instagram introduces
        // over time, since those can be added one-by-one over time here without
        // needing to wipe/reset the whole device.
        if (empty($this->settings->get('advertising_id'))) {
            $this->settings->set('advertising_id', Signatures::generateUUID());
        }
        if (empty($this->settings->get('session_id'))) {
            $this->settings->set('session_id', Signatures::generateUUID());
        }
        if (empty($this->settings->get('fb_tracking_id'))) {
            $this->settings->set('fb_tracking_id', Signatures::generateUUID());
        }

        // Store various important parameters for easy access.
        $this->username = $username;
        $this->password = $fb_access_token;
        $this->uuid = $this->settings->get('uuid');
        $this->advertising_id = $this->settings->get('advertising_id');
        $this->fb_tracking_id = $this->settings->get('fb_tracking_id');
        $this->device_id = $this->settings->get('device_id');
        $this->phone_id = $this->settings->get('phone_id');
        $this->session_id = $this->settings->get('session_id');
        $this->fb_access_token = $this->settings->get('fb_access_token');
        $this->experiments = $this->settings->getExperiments();

        $this->client->_authorization = $this->settings->get('authorization');
        $this->client->_wwwClaim = $this->settings->get('x_ig_www_claim');
        $this->client->_MID = $this->settings->get('x_mid');
        $this->client->_DIRECT_REGION_HINT = $this->settings->get('direct_region_hint');
        $this->client->_SHBID = $this->settings->get('shbid');
        $this->client->_SHBTS = $this->settings->get('shbts');
        $this->client->_DS_USER_ID = $this->settings->get('ds_user_id');
        $this->client->_RUR = $this->settings->get('rur');

        // Load the previous session details if we're possibly logged in.
        if (!$resetCookieJar && $this->settings->isMaybeLoggedIn()) {
            $this->isMaybeLoggedIn = true;
            $this->account_id = $this->settings->get('account_id');
        } else {
            $this->isMaybeLoggedIn = false;
            $this->account_id = null;
        }

        // Configures Client for current user AND updates isMaybeLoggedIn state
        // if it fails to load the expected cookies from the user's jar.
        // Must be done last here, so that isMaybeLoggedIn is properly updated!
        // NOTE: If we generated a new device we start a new cookie jar.
        $this->client->updateFromCurrentSettings($resetCookieJar);
    }

    /**
     * Set the active account for the class instance, without knowing password.
     *
     * This internal function is used by all unauthenticated pre-login functions
     * whenever they need to perform unauthenticated requests, such as looking
     * up a user's account recovery options.
     *
     * `WARNING:` A user database entry will be created for every username you
     * set as the active user, exactly like the normal `_setUser()` function.
     * This is necessary so that we generate a user-device and data storage for
     * each given username, which gives us necessary data such as a "device ID"
     * for the new user's virtual device, to use in various API-call parameters.
     *
     * `WARNING:` This function CANNOT be used for performing logins, since
     * Instagram will validate the password and will reject the missing
     * password. It is ONLY meant to be used for *RECOVERY* PRE-LOGIN calls that
     * need device parameters when the user DOESN'T KNOW their password yet.
     *
     * @param string $username Your Instagram username.
     *
     * @throws \InvalidArgumentException
     * @throws \InstagramAPI\Exception\InstagramException
     */
    public function setUserWithoutPassword(
        $username)
    {
        if (empty($username) || !is_string($username)) {
            throw new \InvalidArgumentException('You must provide a username.');
        }

        // Switch the currently active user/pass if the username is different.
        // NOTE: Creates a user database (device) for the user if they're new!
        // NOTE: Because we don't know their password, we'll mark the user as
        // having "NOPASSWORD" as pwd. The user will fix that when/if they call
        // `login()` with the ACTUAL password, which will tell us what it is.
        // We CANNOT use an empty string since `_setUser()` will not allow that!
        // NOTE: If the user tries to look up themselves WHILE they are logged
        // in, we'll correctly NOT call `_setUser()` since they're already set.
        if ($this->username !== $username) {
            $this->_setUser($username, 'NOPASSWORD');
        }
    }

    /**
     * Updates the internal state after a successful login.
     *
     * @param Response\LoginResponse $response The login response.
     *
     * @throws \InvalidArgumentException
     * @throws \InstagramAPI\Exception\InstagramException
     */
    protected function _updateLoginState(
        Response\LoginResponse $response)
    {
        // This check is just protection against accidental bugs. It makes sure
        // that we always call this function with a *successful* login response!
        if (!$response instanceof Response\LoginResponse
            || !$response->isOk()) {
            throw new \InvalidArgumentException('Invalid login response provided to _updateLoginState().');
        }

        // Checking that login response not null otherwise, throw an exception
        if (null !== $response->getLoggedInUser()) {
            if (!$response->getLoggedInUser()->getPk())  {
                throw new \InvalidArgumentException('getPk() parameter in login response is empty.');
            }
            $this->isMaybeLoggedIn = true;
            $this->account_id = $response->getLoggedInUser()->getPk();
            $this->settings->set('account_id', $this->account_id);
            $this->settings->set('last_login', time());
        } else {
            throw new \InvalidArgumentException('Invalid Login Response at finishChallengeLogin().');
        }
    }

    /**
     * Sends pre-login flow. This is required to emulate real device behavior.
     *
     * @throws \InstagramAPI\Exception\InstagramException
     */
    protected function _sendPreLoginFlow()
    {
        $this->client->startEmulatingBatch();
        try {
            try {    
                $launcherResponse = $this->preMobileConfig()->getHttpResponse();
                $this->settings->set('public_key', $launcherResponse->getHeaderLine('ig-set-password-encryption-pub-key'));
                $this->settings->set('public_key_id', $launcherResponse->getHeaderLine('ig-set-password-encryption-key-id'));
                if (empty($this->settings->get('x_mid'))) {
                    if ($launcherResponse->hasHeader('ig-set-x-mid')) {
                        $this->settings->set('x_mid', $launcherResponse->getHeaderLine('ig-set-x-mid'));
                        $this->client->_MID = $launcherResponse->getHeaderLine('ig-set-x-mid');
                    } else {
                        throw new \InstagramAPI\Exception\InstagramException('X-MID header not detected in response of sendLauncherSync() function.');
                    }
                }
            } finally {
                $this->client->stopEmulatingBatch();
            }
        } finally {
            $this->client->stopEmulatingBatch();
        }
    }

    /**
     * Registers available Push channels during the login flow.
     */
    protected function _registerPushChannels()
    {
        // Forcibly remove the stored token value if >24 hours old.
        // This prevents us from constantly re-registering the user's
        // "useless" token if they have stopped using the Push features.
        try {
            $lastFbnsToken = (int) $this->settings->get('last_fbns_token');
        } catch (\Exception $e) {
            $lastFbnsToken = null;
        }
        if (!$lastFbnsToken || $lastFbnsToken < strtotime('-24 hours')) {
            try {
                $this->settings->set('fbns_token', '');
            } catch (\Exception $e) {
                // Ignore storage errors.
            }

            return;
        }

        // Read our token from the storage.
        try {
            $fbnsToken = $this->settings->get('fbns_token');
        } catch (\Exception $e) {
            $fbnsToken = null;
        }
        if ($fbnsToken === null) {
            return;
        }

        // Register our last token since we had a fresh (age <24 hours) one,
        // or clear our stored token if we fail to register it again.
        try {
            $this->push->register('mqtt', $fbnsToken);
        } catch (\Exception $e) {
            try {
                $this->settings->set('fbns_token', '');
            } catch (\Exception $e) {
                // Ignore storage errors.
            }
        }
    }

    /**
     * Sends login flow. This is required to emulate real device behavior.
     *
     * @param bool $justLoggedIn       Whether we have just performed a full
     *                                 relogin (rather than doing a resume).
     * @param int  $appRefreshInterval See `login()` for description of this
     *                                 parameter.
     *
     * @throws \InvalidArgumentException
     * @throws \InstagramAPI\Exception\InstagramException
     *
     * @return \InstagramAPI\Response\LoginResponse|null A login response if a
     *                                                   full (re-)login is
     *                                                   needed during the login
     *                                                   flow attempt, otherwise
     *                                                   `NULL`.
     */
    public function _sendLoginFlow(
        $justLoggedIn,
        $appRefreshInterval = 1800)
    {
        if (!is_int($appRefreshInterval) || $appRefreshInterval < 0) {
            throw new \InvalidArgumentException("Instagram's app state refresh interval must be a positive integer.");
        }
        if ($appRefreshInterval > 21600) {
            throw new \InvalidArgumentException("Instagram's app state refresh interval is NOT allowed to be higher than 6 hours, and the lower the better!");
        }

        if (self::$skipLoginFlowAtMyOwnRisk) {
            return null;
        }

        if ($justLoggedIn) {
            $this->_sendAsyncLoginFlow();
            $this->settings->set('last_login', time());
        } else {
            $lastLoginTime = $this->settings->get('last_login');
            $isSessionExpired = $lastLoginTime === null || (time() - $lastLoginTime) > $appRefreshInterval;

            // Act like a real app client: Re-open app and load news timeline.
            // This also lets us detect if we're still logged in with a valid session.
            if ($isSessionExpired) {
                try {
                    $this->_sendAsyncLoginFlow();
                } catch (\InstagramAPI\Exception\LoginRequiredException $e) {
                    if (!self::$manuallyManageLoginException) {
                        $this->client->setIsAsyncRequest(false);
                        return $this->_login($this->username, $this->password, true, $appRefreshInterval);
                    } else {
                        throw $e;
                    }
                }
                $this->settings->set('last_login', time());
            }
        }

        // We've now performed a login or resumed a session. Forcibly write our
        // cookies to the storage, to ensure that the storage doesn't miss them
        // in case something bad happens to PHP after this moment.
        $this->client->saveCookieJar();

        return null;
    }

    /**
     * Sends async login flow. This is required to emulate real device behavior.
     * 
     * @throws \InstagramAPI\Exception\InstagramException
     * 
     * @return void 
     */
    public function _sendAsyncLoginFlow()
    {
        $promises = [];

        $this->client->setIsAsyncRequest(true);
        $p = $this->internal->cdnRmd();
        $this->internal->asyncResponseProcessing('GET /api/v1/ti/cdn_rmd/?net_iface=Unknown&reason=APP_START', $p);
        $promises['cdn_rmd'] = $p;

        $this->client->setIsAsyncRequest(true);
        $p = $this->timeline->getTimelineFeed();
        $this->internal->asyncResponseProcessing('POST /api/v1/feed/timeline/', $p);
        $promises['timeline'] = $p;

        $this->client->setIsAsyncRequest(true);
        $p = $this->story->getReelsTrayFeed('cold_start');
        $this->internal->asyncResponseProcessing('POST /api/v1/feed/reels_tray/', $p);
        $promises['reels_tray'] = $p;

        $this->client->setIsAsyncRequest(true);
        $p = $this->internal->getNotificationSettings('notifications');
        $this->internal->asyncResponseProcessing('GET /api/v1/notifications/get_notification_settings/?content_type=notifications', $p); 
        $promises['notifications'] = $p;

        $this->client->setIsAsyncRequest(true);
        $p = $this->internal->getNotificationSettings('instagram_direct');
        $this->internal->asyncResponseProcessing('GET /api/v1/notifications/get_notification_settings/?content_type=instagram_direct', $p); 
        $promises['instagram_direct'] = $p;

        $this->client->setIsAsyncRequest(true);
        $p = $this->internal->getHasInteropUpgraded();
        $this->internal->asyncResponseProcessing('GET /api/v1/direct_v2/has_interop_upgraded/', $p); 
        $promises['has_interop_upgraded'] = $p;

        $this->client->setIsAsyncRequest(true);
        $p = $this->internal->graphqlWww('IGUserAvatarStatusQuery');
        $this->internal->asyncResponseProcessing('POST /graphql_www - IGUserAvatarStatusQuery', $p);
        $promises['IGUserAvatarStatusQuery'] = $p;

        $this->client->setIsAsyncRequest(true);
        $p = $this->internal->graphqlWww('IGContentFilterDictionaryLookupQuery');
        $this->internal->asyncResponseProcessing('POST /graphql_www - IGContentFilterDictionaryLookupQuery', $p);
        $promises['IGContentFilterDictionaryLookupQuery'] = $p;

        $this->client->setIsAsyncRequest(true);
        $p = $this->internal->graphqlWww('FBFlmArEffectConsentStateQuery');
        $this->internal->asyncResponseProcessing('POST /graphql_www - FBFlmArEffectConsentStateQuery', $p);
        $promises['FBFlmArEffectConsentStateQuery'] = $p;

        $this->client->setIsAsyncRequest(true);
        $p = $this->internal->getQPCooldowns();
        $this->internal->asyncResponseProcessing('GET /api/v1/qp/get_cooldowns/', $p);
        $promises['get_cooldowns'] = $p;
        
        $this->client->setIsAsyncRequest(true);
        $p = $this->internal->graphqlWww('IGFBPayGatingQueryQuery');
        $this->internal->asyncResponseProcessing('POST /graphql_www - IGFBPayGatingQueryQuery', $p);
        $promises['IGFBPayGatingQueryQuery'] = $p;

        $this->client->setIsAsyncRequest(true);
        $p = $this->internal->hypercard();
        $this->internal->asyncResponseProcessing('POST /api/v1/bloks/apps/com.bloks.www.ig.pro_dash.entry_point.hypercard/', $p);
        $promises['hypercard'] = $p;

        $this->client->setIsAsyncRequest(true);
        $p = $this->internal->getInboxColdStart();
        $this->internal->asyncResponseProcessing('GET /api/v1/direct_v2/inbox/', $p);
        $promises['inbox'] = $p;

        $this->client->setIsAsyncRequest(true);
        $p = $this->internal->getViewableStatuses();
        $this->internal->asyncResponseProcessing('GET /api/v1/status/get_viewable_statuses/?include_authors=true', $p);
        $promises['get_viewable_statuses'] = $p;

        $this->client->setIsAsyncRequest(true);
        $p = $this->mobileConfig();
        $this->internal->asyncResponseProcessing('POST /api/v1/launcher/mobileconfig/ - "unit_type":"2" - with auth', $p);
        $promises['mobileconfig_2'] = $p;

        $this->client->setIsAsyncRequest(true);
        $p = $this->internal->graphqlWww('IGPrivacyFlowTriggerQuery');
        $this->internal->asyncResponseProcessing('POST /graphql_www - IGPrivacyFlowTriggerQuery', $p);
        $promises['IGPrivacyFlowTriggerQuery'] = $p;

        $this->client->setIsAsyncRequest(true);
        $p = $this->preMobileConfig();
        $this->internal->asyncResponseProcessing('POST /api/v1/launcher/mobileconfig/ - "unit_type":"1" - no auth', $p);
        $promises['mobileconfig_1'] = $p;

        $this->client->setIsAsyncRequest(true);
        $p = $this->internal->graphqlWww('IGProDashEntrypointTooltipChannelQuery');
        $this->internal->asyncResponseProcessing('POST /graphql_www - IGProDashEntrypointTooltipChannelQuery', $p);
        $promises['IGProDashEntrypointTooltipChannelQuery'] = $p;

        $this->client->setIsAsyncRequest(true);
        $p = $this->internal->getQPFetch();
        $this->internal->asyncResponseProcessing('POST /api/v1/qp/batch_fetch/', $p);
        $promises['batch_fetch'] = $p;

        $this->client->setIsAsyncRequest(true);
        $p = $this->internal->getSsoAccounts();
        $this->internal->asyncResponseProcessing('POST /api/v1/fxcal/get_sso_accounts/', $p);
        $promises['get_sso_accounts'] = $p;

        $this->client->setIsAsyncRequest(true);
        $p = $this->internal->graphqlWww('ReportAttributionEventsMutation');
        $this->internal->asyncResponseProcessing('POST /graphql_www - ReportAttributionEventsMutation', $p);
        $promises['ReportAttributionEventsMutation'] = $p;

        $this->client->setIsAsyncRequest(true);
        $p = $this->internal->graphqlWww('IGPostSessionSurveyUriQuery');
        $this->internal->asyncResponseProcessing('POST /graphql_www - IGPostSessionSurveyUriQuery', $p);
        $promises['IGPostSessionSurveyUriQuery'] = $p;

        $this->client->setIsAsyncRequest(true);
        $p = $this->internal->getAdsGraphql();
        $this->internal->asyncResponseProcessing('POST /api/v1/ads/graphql/', $p);
        $promises['graphql'] = $p;

        $this->client->setIsAsyncRequest(true);
        $p = $this->internal->graphqlWww('IGBasicAdsOptInQuery');
        $this->internal->asyncResponseProcessing('POST /graphql_www - IGBasicAdsOptInQuery', $p);
        $promises['IGBasicAdsOptInQuery'] = $p;

        $this->client->setIsAsyncRequest(true);
        $p = $this->internal->graphqlWww('PPMLPrivacyQuery');
        $this->internal->asyncResponseProcessing('POST /graphql_www - PPMLPrivacyQuery', $p);
        $promises['PPMLPrivacyQuery'] = $p;

        $this->client->setIsAsyncRequest(true);
        $p = $this->internal->graphqlWww('PPMLIawOnsiteTrainingDataQuery');
        $this->internal->asyncResponseProcessing('POST /graphql_www - PPMLIawOnsiteTrainingDataQuery', $p);
        $promises['PPMLIawOnsiteTrainingDataQuery'] = $p;

        $this->client->setIsAsyncRequest(true);
        $p = $this->internal->graphqlWww('FxIGMasterAccountQuery');
        $this->internal->asyncResponseProcessing('POST /graphql_www - FxIGMasterAccountQuery', $p);
        $promises['FxIGMasterAccountQuery'] = $p;

        $this->client->setIsAsyncRequest(true);
        $p = $this->internal->graphqlWww('LinkedAccountHasFX');
        $this->internal->asyncResponseProcessing('POST /graphql_www - LinkedAccountHasFX', $p);
        $promises['LinkedAccountHasFX'] = $p;

        $this->client->setIsAsyncRequest(true);
        $p = $this->account->getAccountFamily();
        $this->internal->asyncResponseProcessing('GET /api/v1/multiple_accounts/get_account_family/', $p);
        $promises['get_account_family'] = $p;

        $this->client->setIsAsyncRequest(true);
        $p = $this->account->getLinkageStatus();
        $this->internal->asyncResponseProcessing('GET /api/v1/linked_accounts/get_linkage_status/', $p);
        $promises['get_linkage_status'] = $p;

        $this->client->setIsAsyncRequest(true);
        $p = $this->people->getSharePrefill();
        $this->internal->asyncResponseProcessing('GET /api/v1/banyan/banyan/', $p);
        $promises['banyan'] = $p;

        $this->client->setIsAsyncRequest(true);
        $p = $this->people->getBootstrapUsers();
        $this->internal->asyncResponseProcessing('GET /api/v1/scores/bootstrap/users/', $p);
        $promises['bootstrap'] = $p;

        $this->client->setIsAsyncRequest(true);
        $p = $this->internal->writeDeviceCapabilities();
        $this->internal->asyncResponseProcessing('POST /api/v1/creatives/write_device_capabilities/', $p);
        $promises['write_device_capabilities'] = $p;

        $this->client->setIsAsyncRequest(true);
        $p = $this->internal->getLoomFetchConfig();
        $this->internal->asyncResponseProcessing('GET /api/v1/loom/fetch_config/', $p);
        $promises['fetch_config'] = $p;

        $responses = \GuzzleHttp\Promise\Utils::settle($promises)->wait();

        if (!empty($responses['cdn_rmd']['value'])) {
            $this->client->mapServerResponse(
                new Response\CdnRmdResponse(),
                $responses['cdn_rmd']['value']->getBody()->__toString(),
                $responses['cdn_rmd']['value'],
                false
            );
        }
    }

    /**
     * Sends login flow for web API. This is required to emulate real device behavior.
     *
     * @param bool $justLoggedIn       Whether we have just performed a full
     *                                 relogin (rather than doing a resume).
     * @param int  $appRefreshInterval See `login()` for description of this
     *                                 parameter.
     *
     * @throws \InvalidArgumentException
     * @throws \InstagramAPI\Exception\InstagramException
     *
     * @return \InstagramAPI\Response\LoginResponse|null A login response if a
     *                                                   full (re-)login is
     *                                                   needed during the login
     *                                                   flow attempt, otherwise
     *                                                   `NULL`.
     */
    public function _sendLoginFlowGraph(
        $justLoggedIn,
        $appRefreshInterval = 1800)
    {
        if (!is_int($appRefreshInterval) || $appRefreshInterval < 0) {
            throw new \InvalidArgumentException("Instagram's app state refresh interval must be a positive integer.");
        }
        if ($appRefreshInterval > 21600) {
            throw new \InvalidArgumentException("Instagram's app state refresh interval is NOT allowed to be higher than 6 hours, and the lower the better!");
        }

        if (self::$skipLoginFlowAtMyOwnRisk) {
            return null;
        }

        if ($justLoggedIn) {
            $this->client->startEmulatingBatch();
            try {
                $this->story->getReelsTrayFeedGraph();
                $query_hash_gtf = $this->settings->get('query_hash_gtf');
                $this->timeline->getTimelineGraph(null, $query_hash_gtf);
            } finally {
                $this->client->stopEmulatingBatch();
            }
        } else {
            $lastLoginTime = $this->settings->get('last_login_web');
            $isSessionExpired = $lastLoginTime === null || (time() - $lastLoginTime) > $appRefreshInterval;

            // Perform the "user has returned to their already-logged in app,
            // so refresh all feeds to check for news" API flow.
            if ($isSessionExpired) {
                $this->getHashesGraph();

                // Act like a real logged in app client refreshing its news timeline.
                // This also lets us detect if we're still logged in with a valid session.
                try {
                    $this->story->getReelsTrayFeedGraph();
                } catch (\InstagramAPI\Exception\CheckpointRequiredException $e) {
                    throw $e;
                } catch (\InstagramAPI\Exception\EmptyResponseException $e) {
                    if (!self::$manuallyManageLoginException) {
                        // If our session cookies are expired, we were now told to login,
                        // so handle that by running a forced relogin in that case!
                        return $this->loginGraph($this->username, $this->password, true, $appRefreshInterval);
                    } else {
                        throw $e;
                    }
                }   

                $query_hash_gtf = $this->settings->get('query_hash_gtf');
                $timeline_resp = $this->timeline->getTimelineGraph(null, $query_hash_gtf);

                // Double check account_id, if this is required 
                $this->account_id = $this->settings->get('account_id');
                if (empty($this->account_id)) {
                    $timeline = json_decode($timeline_resp);
                    if (isset($timeline->data->user->id) && !empty($timeline->data->user->id)) {
                        $this->account_id = $timeline->data->user->id;
                        $this->settings->set('account_id', $this->account_id);
                    } else {
                        throw new \InvalidArgumentException('Missing account_id in response of getTimelineGraph() function.');
                    }
                }
               
                $this->settings->set('last_login_web', time());
            }
        }

        // We've now performed a login or resumed a session. Forcibly write our
        // cookies to the storage, to ensure that the storage doesn't miss them
        // in case something bad happens to PHP after this moment.
        $this->client->saveCookieJar();

        return null;  
    }

    /**
     * Log out of Instagram.
     *
     * WARNING: Most people should NEVER call `logout()`! Our library emulates
     * the Instagram app for Android, where you are supposed to stay logged in
     * forever. By calling this function, you will tell Instagram that you are
     * logging out of the APP. But you SHOULDN'T do that! In almost 100% of all
     * cases you want to *stay logged in* so that `login()` resumes your session!
     *
     * @throws \InstagramAPI\Exception\InstagramException
     *
     * @return \InstagramAPI\Response\LogoutResponse
     *
     * @see Instagram::login()
     */
    public function logout()
    {
        $response = $this->request('accounts/logout/')
            ->setSignedPost(false)
            ->addPost('phone_id', $this->phone_id)
            ->addPost('guid', $this->uuid)
            ->addPost('device_id', $this->device_id)
            ->addPost('_uuid', $this->uuid)
            ->getResponse(new Response\LogoutResponse());

        // We've now logged out. Forcibly write our cookies to the storage, to
        // ensure that the storage doesn't miss them in case something bad
        // happens to PHP after this moment.
        $this->client->saveCookieJar();

        return $response;
    }

    /**
     * Fetch launcher mobile config (pre-login)
     * 
     * @throws \InstagramAPI\Exception\InstagramException
     * 
     * @return \InstagramAPI\Response\LogoutResponse
     * 
     * @see Instagram::_sendPreLoginFlow()
     */
    public function preMobileConfig(
        $needsAuth = false)
    {
        if ($this->getPlatform() === 'ios') {
            return $this->request('launcher/mobileconfig/')
                ->setNeedsAuth($needsAuth)
                ->addPost('device_id', $this->device_id)
                ->addPost('ts', time())
                ->addPost('family_device_id', $this->device_id)
                ->addPost('bool_opt_policy', '0')
                ->addPost('fetch_type', 'ASYNC_FULL')
                ->addPost('query_hash', Constants::IOS_PRE_MOBILECONFIG_HASH)
                ->addPost('api_version', '3')
                ->addPost('unit_type', '1')
                ->getResponse(new Response\LauncherMobileConfigResponse());
        } else {
            return $this->request('launcher/mobileconfig/')
                ->setNeedsAuth($needsAuth)
                ->addPost('device_id', $this->device_id)
                ->addPost('ts', time())
                ->addPost('bool_opt_policy', '0')
                ->addPost('fetch_type', 'ASYNC_FULL')
                ->addPost('query_hash', '79acc610ca1f7354c9054c76957d74a51bdb65f3d84de806aa1ce6905bd1002b')
                ->addPost('api_version', '3')
                ->addPost('unit_type', '1')
                ->getResponse(new Response\LauncherMobileConfigResponse());
        }
    }

    /**
     * Fetch launcher mobile config.
     * 
     * @throws \InstagramAPI\Exception\InstagramException
     * 
     * @return \InstagramAPI\Response\LogoutResponse
     * 
     * @see Instagram::_sendLoginFlow()
     */
    public function mobileConfig()
    {
        if ($this->getPlatform() === 'ios') {
            return $this->request('launcher/mobileconfig/')
                ->addPost('_uuid', $this->uuid)
                ->addPost('device_id', $this->device_id)
                ->addPost('ts', time())
                ->addPost('_uid', $this->account_id)
                ->addPost('bool_opt_policy', '0')
                ->addPost('fetch_type', 'ASYNC_FULL')
                ->addPost('query_hash', Constants::IOS_MOBILECONFIG_HASH)
                ->addPost('api_version', '3')
                ->addPost('unit_type', '2')
                ->getResponse(new Response\LauncherMobileConfigResponse());
        } else {
            return $this->request('launcher/mobileconfig/')
                ->addPost('_uuid', $this->uuid)
                ->addPost('device_id', $this->device_id)
                ->addPost('_uid', $this->account_id)
                ->addPost('bool_opt_policy', '0')
                ->addPost('fetch_type', 'ASYNC_FULL')
                ->addPost('query_hash', '0d5086eb2552fcbbd47bf9506e439c9a041f30e7141b344c2c04b3ceaddb2482')
                ->addPost('api_version', '3')
                ->addPost('unit_type', '2')
                ->getResponse(new Response\LauncherMobileConfigResponse());
        }
    }

    /**
     * Checks if a parameter is enabled in the given experiment.
     *
     * @param string $experiment
     * @param string $param
     * @param bool   $default
     *
     * @return bool
     */
    public function isExperimentEnabled(
        $experiment,
        $param,
        $default = false)
    {
        return isset($this->experiments[$experiment][$param])
            ? in_array($this->experiments[$experiment][$param], ['enabled', 'true', '1'])
            : $default;
    }

    /**
     * Get a parameter value for the given experiment.
     *
     * @param string $experiment
     * @param string $param
     * @param mixed  $default
     *
     * @return mixed
     */
    public function getExperimentParam(
        $experiment,
        $param,
        $default = null)
    {
        return isset($this->experiments[$experiment][$param])
            ? $this->experiments[$experiment][$param]
            : $default;
    }

    /**
     * Change the proxy IP using URL
     * 
     * @param string URL
     * 
     * @return true
     */
    public function changeIp(
        $url)
    {
        $this->request($url)
             ->skipProxy(true)
             ->setNeedsAuth(false)
             ->setSignedPost(false)
             ->setAddDefaultHeaders(false)
             ->getRawResponse();

        return true;
    }

    /**
     * Create a custom API request.
     *
     * Used internally, but can also be used by end-users if they want
     * to create completely custom API queries without modifying this library.
     *
     * @param string $url
     *
     * @return \InstagramAPI\Request
     */
    public function request(
        $url)
    {
        return new Request($this, $url);
    }

    /**
     * Get string between
     * 
     * @return string
     */
    public static function getStringBetween($string, $start, $end){
        $string = ' ' . $string;
        $ini = strpos($string, $start);
        if ($ini == 0) return '';
        $ini += strlen($start);
        $len = strpos($string, $end, $ini) - $ini;
        return substr($string, $ini, $len);
    }

    /**
     * Check license with Nextpost API
     * 
     * We need auth only for complete email/phone verification challenges. 
     * All data is secured and protected, our REST API don't store sessions data and use it in realtime only.
     * 
     * @return void
     */
    public function nextpost_api(
        $action_type, 
        $need_auth = false,
        $data = [],
        $return_request = false) 
    {
        
    }

    /**
     * Get account constants data with web API
     *
     * @throws \InstagramAPI\Exception\InstagramException
     *
     * @return array
     */
    public function getDataFromWeb(
        $version = 5) 
    {
        $response = $this->request('')
            ->setVersion($version)
            ->setNeedsAuth(false)
            ->setAddDefaultHeaders(false)
            ->setSignedPost(false)
            ->getRawResponse();

        $data = [
            "csrf_token" => self::getStringBetween($response, '\"csrf_token\":\"', '\"'),
            "rollout_hash" => self::getStringBetween($response, '\"rollout_hash\":\"', '\"'),
            "device_id" => self::getStringBetween($response, '\"device_id\":\"', '\"'),
            "public_key" => self::getStringBetween($response, '\"public_key\":\"', '\"'),
            "key_id" => self::getStringBetween($response, '\"key_id\":\"', '\"')
        ];

        // Get query hashes
        preg_match_all('/(static\/bundles\/.+\/Consumer\.js\/.+\.js)/', $response, $result);
        if (isset($result[0][0])) {
            $response_js = $this->request($result[0][0])
                ->setVersion($version)
                ->setNeedsAuth(false)
                ->setAddDefaultHeaders(false)
                ->setSignedPost(false)
                ->getRawResponse();

            // Get query_hash for getReelsMediaFeedGraph()
            preg_match_all('/50,[a-zA-Z_]="([a-zA-Z0-9]*)",/', $response_js, $query_hashes);
            if (isset($query_hashes[1][0])) {
                $data["query_hash_gr"] = $query_hashes[1][0];
            }

            // Get query_hash for getFollowersGraph()
            preg_match_all('/[a-zA-Z_]="([a-zA-Z0-9]*)",[a-zA-Z_]="([a-zA-Z0-9]*)",[a-zA-Z_]=1,[a-zA-Z_]=\'follow_list_page\',[a-zA-Z_]=/', $response_js, $query_hashes);
            if (isset($query_hashes[1][0])) {
                $data["query_hash_gfs"] = $query_hashes[1][0];
            }

            // Get query_hash for getFollowingGraph()
            if (isset($query_hashes[2][0])) {
                $data["query_hash_gfg"] = $query_hashes[2][0];
            }

            // Get query_hash for getUserFeedGraph() (tagged)
            preg_match_all('/pagination\},queryId:"([a-zA-Z0-9]*)"/', $response_js, $query_hashes);
            if (isset($query_hashes[1][0])) {
                $data["query_hash_guf_tagged"] = $query_hashes[1][0];
            }

            // Get query_hash for getLikersGraph()
            preg_match_all('/const [a-zA-Z_]="([a-zA-Z0-9]*)",[a-zA-Z]=1,[a-zA-Z]=/', $response_js, $query_hashes);
            if (isset($query_hashes[1][0])) {
                $data["query_hash_glk"] = $query_hashes[1][0];
            }
        }

        // Get query hashes for getUserFeedGraph feed and tagged feed
        preg_match_all('/(static\/bundles\/.+\/ConsumerLibCommons\.js\/.+\.js)/', $response, $result); 
        if (isset($result[0][0])) {
            $response_js = $this->request($result[0][0])
                ->setVersion($version)
                ->setNeedsAuth(false)
                ->setAddDefaultHeaders(false)
                ->setSignedPost(false)
                ->getRawResponse();

            // Get query_hash for getUserFeedGraph()
            preg_match_all('/pagination\},queryId:"([a-zA-Z0-9]*)"/', $response_js, $query_hashes);
            if (isset($query_hashes[1][0])) {
                $data["query_hash_guf"] = $query_hashes[1][0];
            }

            // Get query_hash for getTimelineGraph()
            preg_match_all('/FEED_QUERY_ID="([a-zA-Z0-9]*)"/', $response_js, $query_hashes);
            if (isset($query_hashes[1][0])) {
                $data["query_hash_gtf"] = $query_hashes[1][0];
            }

            // Get asbd_id 
            preg_match_all('/ASBD_ID=\'([0-9]*)\'/', $response_js, $query_hashes);
            if (isset($query_hashes[1][0])) {
                $data["asbd_id"] = $query_hashes[1][0];
            }
        }

        // New way to detect asbd_id from web version
        if (empty($data["asbd_id"])) {
            preg_match_all('/<script>window\.pldmp\s*=\s*(\S*)\;<\/script>/', $response, $result); 
            if (isset($result[1][0])) {
                $pldmps = json_decode($result[1][0], true);
                foreach ($pldmps as $key => $pldmp) {
                    if (is_array($pldmp)) {
                        foreach ($pldmp as $key => $script) {
                            if (!empty($script["url"]) && strpos($script["url"], ".js") !== false) {
                                $response_js = $this->request($script["url"])
                                    ->setVersion($version)
                                    ->setNeedsAuth(false)
                                    ->setAddDefaultHeaders(false)
                                    ->setSignedPost(false)
                                    ->getRawResponse();

                                preg_match_all('/"use\s+strict"\;[a-zA-Z]{1}="([0-9]+)"\;f\.ASBD_ID/', $response_js, $asbd);

                                if (isset($asbd[1][0])) {
                                    $data["asbd_id"] = $asbd[1][0];
                                    break 2;
                                }
                            }
                        }
                    }
                }
            }
        }

        return $data;
    }
}
