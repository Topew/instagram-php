<?php

namespace InstagramAPI\Exception;

use InstagramAPI\Exception\RequestException;

class UnknownChallengeStepException extends RequestException
{
}
