<?php

namespace InstagramAPI\Exception;

use InstagramAPI\Exception\RequestException;

class ChallengeIterationsLimitException extends RequestException
{
}
