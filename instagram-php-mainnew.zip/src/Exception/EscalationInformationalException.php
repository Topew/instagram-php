<?php

namespace InstagramAPI\Exception;

use InstagramAPI\Exception\RequestException;

class EscalationInformationalException extends RequestException
{
}
