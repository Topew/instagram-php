<?php

namespace InstagramAPI\Exception;

use InstagramAPI\Exception\RequestException;

class SelectContactPointRecoveryException extends RequestException
{
}
