<?php

namespace InstagramAPI\Exception;

use InstagramAPI\Exception\RequestException;

class ForceVerifyCodeException extends RequestException
{
}
