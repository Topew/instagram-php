<?php

namespace InstagramAPI\Exception;

use InstagramAPI\Exception\RequestException;

class SelectVerifyMethodException extends RequestException
{
}
