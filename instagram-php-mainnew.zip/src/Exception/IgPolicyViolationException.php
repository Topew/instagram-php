<?php

namespace InstagramAPI\Exception;

class IgPolicyViolationException extends RequestException
{
}
