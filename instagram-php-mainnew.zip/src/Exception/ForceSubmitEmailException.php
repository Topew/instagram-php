<?php

namespace InstagramAPI\Exception;

use InstagramAPI\Exception\RequestException;

class ForceSubmitEmailException extends RequestException
{
}
