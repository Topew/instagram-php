<?php

namespace InstagramAPI\Exception;

use InstagramAPI\Exception\RequestException;

class SubmitEmailException extends RequestException
{
}
