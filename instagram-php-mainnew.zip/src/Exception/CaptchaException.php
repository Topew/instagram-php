<?php

namespace InstagramAPI\Exception;

class CaptchaException extends RequestException
{
}
