<?php

namespace InstagramAPI\Response\Model;

use InstagramAPI\AutoPropertyMapper;

/**
 * IgBusinessCategoriesTypeahead.
 *
 * @method BusinessCategoriesItem[] getItems()
 * @method bool isItems()
 * @method $this setItems(BusinessCategoriesItem[] $value)
 * @method $this unsetItems()
 */
class IgBusinessCategoriesTypeahead extends AutoPropertyMapper
{
    const JSON_PROPERTY_MAP = [
        'items'                             => 'BusinessCategoriesItem[]',
    ];
}
