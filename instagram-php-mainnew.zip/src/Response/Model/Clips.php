<?php

namespace InstagramAPI\Response\Model;

use InstagramAPI\AutoPropertyMapper;

/**
 * Clips.
 *  
 * @method mixed getBadgeLabel()
 * @method mixed getChainingInfo()
 * @method string getContentSource()
 * @method string getDesign()
 * @method string getId()
 * @method ClipsFeedItem[] getItems()
 * @method string getLabel()
 * @method string getMaxId()
 * @method bool getMoreAvailable()
 * @method string getType()
 * @method bool isBadgeLabel()
 * @method bool isChainingInfo()
 * @method bool isContentSource()
 * @method bool isDesign()
 * @method bool isId()
 * @method bool isItems()
 * @method bool isLabel()
 * @method bool isMaxId()
 * @method bool isMoreAvailable()
 * @method bool isType()
 * @method $this setBadgeLabel(mixed $value)
 * @method $this setChainingInfo(mixed $value)
 * @method $this setContentSource(string $value)
 * @method $this setDesign(string $value)
 * @method $this setId(string $value)
 * @method $this setItems(ClipsFeedItem[] $value)
 * @method $this setLabel(string $value)
 * @method $this setMaxId(string $value)
 * @method $this setMoreAvailable(bool $value)
 * @method $this setType(string $value)
 * @method $this unsetBadgeLabel()
 * @method $this unsetChainingInfo()
 * @method $this unsetContentSource()
 * @method $this unsetDesign()
 * @method $this unsetId()
 * @method $this unsetItems()
 * @method $this unsetLabel()
 * @method $this unsetMaxId()
 * @method $this unsetMoreAvailable()
 * @method $this unsetType()
 */
class Clips extends AutoPropertyMapper
{
    const JSON_PROPERTY_MAP = [
        'badge_label'       => '',
        'chaining_info'     => '',
        'content_source'    => 'string',
        'design'            => 'string',
        'id'                => 'string',
        'items'             => 'ClipsFeedItem[]',
        'label'             => 'string',
        'max_id'            => 'string',
        'more_available'    => 'bool',
        'type'              => 'string'
    ];
}
