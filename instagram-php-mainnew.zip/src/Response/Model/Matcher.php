<?php

namespace InstagramAPI\Response\Model;

use InstagramAPI\AutoPropertyMapper;

/**
 * Matcher.
 *
 * @method string   getObjects()
 * @method string[] getProtos()
 * @method bool     isObjects()
 * @method bool     isProtos()
 * @method $this    setObjects(string $value)
 * @method $this    setProtos(string[] $value)
 * @method $this    unsetObjects()
 * @method $this    unsetProtos()
 */
class Matcher extends AutoPropertyMapper
{
    const JSON_PROPERTY_MAP = [
        'objects'   => 'string',
        'protos'    => 'string[]'
    ];
}
