<?php

namespace InstagramAPI\Response\Model;

use InstagramAPI\AutoPropertyMapper;

/**
 * BioLinks.
 *
 * @method int getLinkId()
 * @method string getUrl()
 * @method string getLynxUrl()
 * @method string getLinkType()
 * @method string getTitle()
 * @method bool getOpenExternalUrlWithInAppBrowser()
 * @method bool isLinkId()
 * @method bool isUrl()
 * @method bool isLynxUrl()
 * @method bool isLinkType()
 * @method bool isTitle()
 * @method bool isOpenExternalUrlWithInAppBrowser()
 * @method $this setLinkId(int $value) 
 * @method $this setUrl(string $value)
 * @method $this setLynxUrl(string $value)
 * @method $this setLinkType(string $value)
 * @method $this setTitle(string $value)
 * @method $this setOpenExternalUrlWithInAppBrowser(bool $value)
 * @method $this unsetLinkId()
 * @method $this unsetUrl()
 * @method $this unsetLynxUrl()
 * @method $this unsetLinkType()
 * @method $this unsetTitle()
 * @method $this unsetOpenExternalUrlWithInAppBrowser()
 * 
 */
class BioLinks extends AutoPropertyMapper
{
    const JSON_PROPERTY_MAP = [
        'link_id'                               => 'int',
        'url'                                   => 'string',
        'lynx_url'                              => 'string',
        'link_type'                             => 'string',
        'title'                                 => 'string',
        'open_external_url_with_in_app_browser' => 'bool',
    ];
}
