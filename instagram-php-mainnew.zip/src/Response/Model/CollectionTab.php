<?php

namespace InstagramAPI\Response\Model;

use InstagramAPI\AutoPropertyMapper;

/**
 * CollectionTab.
 * 
 * @method string getTabType()
 * @method bool isTabType()
 * @method $this setTabType(string $value)
 * @method $this unsetTabType()
 */
class CollectionTab extends AutoPropertyMapper
{
    const JSON_PROPERTY_MAP = [
        'tab_type'          => 'string',
    ];
}
