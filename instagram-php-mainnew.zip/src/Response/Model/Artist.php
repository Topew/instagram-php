<?php

namespace InstagramAPI\Response\Model;

use InstagramAPI\AutoPropertyMapper;

/**
 * Artist.
 *
 * @method string getId()
 * @method string getArtistName()
 * @method string getArtistSubtitle()
 * @method string getCoverArtworkUri()
 * @method bool   isId()
 * @method bool   isArtistName()
 * @method bool   isArtistSubtitle()
 * @method bool   isCoverArtworkUri()
 * @method $this  setId(string $value)
 * @method $this  setArtistName(string $value)
 * @method $this  setArtistSubtitle(string $value)
 * @method $this  setCoverArtworkUri(string $value)
 * @method $this  unsetId()
 * @method $this  unsetArtistName()
 * @method $this  unsetArtistSubtitle()
 * @method $this  unsetCoverArtworkUri()
 */
class Artist extends AutoPropertyMapper
{
    const JSON_PROPERTY_MAP = [
        'id' => 'string',
        'artist_name' => 'string',
        'artist_subtitle' => 'string',
        'cover_artwork_uri' => 'string',
    ];
}
