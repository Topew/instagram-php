<?php

namespace InstagramAPI\Response;

use InstagramAPI\Response;

/**
 * CdnRmdResponse.
 * 
 * @method int      getVersion()
 * @method string   getCatParam()
 * @method Model\Rules[]  getRules()
 * @method mixed    getHints()
 * @method mixed    getInstagramGraph()
 * @method string   getToken()
 * @method int      getTimestamp()
 * @method string   getTgtIp()
 * @method string   getStatus()
 * @method bool     isVersion()
 * @method bool     isCatParam()
 * @method bool     isRules()
 * @method bool     isHints()
 * @method bool     isInstagramGraph()
 * @method bool     isToken()
 * @method bool     isTimestamp()
 * @method bool     isTgtIp()
 * @method bool     isStatus()
 * @method $this    setVersion(int $value)
 * @method $this    setCatParam(string $value)
 * @method $this    setRules(Model\Rules[] $value)
 * @method $this    setHints(mixed $value)
 * @method $this    setInstagramGraph(mixed $value)
 * @method $this    setToken(string $value)
 * @method $this    setTimestamp(int $value)
 * @method $this    setTgtIp(string $value)
 * @method $this    setStatus(string $value)
 * @method $this    unsetVersion()
 * @method $this    unsetCatParam()
 * @method $this    unsetRules()
 * @method $this    unsetHints()
 * @method $this    unsetInstagramGraph()
 * @method $this    unsetToken()
 * @method $this    unsetTimestamp()
 * @method $this    unsetTgtIp()
 * @method $this    unsetStatus()
 */
class CdnRmdResponse extends Response
{
    const JSON_PROPERTY_MAP = [
        'version'           =>  'int',
        'cat_param'         =>  'string',
        'rules'             =>  'Model\Rules[]',
        'hints'             =>  'mixed',
        'instagram_graph'   =>  'mixed',
        'token'             =>  'string',
        'timestamp'         =>  'int',
        'tgt_ip'            =>  'string',
        'status'            =>  'string',
    ];
}
