<?php

namespace InstagramAPI\Response;

use InstagramAPI\Response;

/**
 * ArchiveBadgeCountResponse.
 *
 * @method int getBadgeCount()
 * @method mixed getMessage()
 * @method string getStatus()
 * @method Model\_Message[] get_Messages()
 * @method bool isBadgeCount()
 * @method bool isMessage()
 * @method bool isStatus()
 * @method bool is_Messages()
 * @method $this setBadgeCount(int $value)
 * @method $this setMessage(mixed $value)
 * @method $this setStatus(string $value)
 * @method $this set_Messages(Model\_Message[] $value)
 * @method $this unsetBadgeCount()
 * @method $this unsetMessage()
 * @method $this unsetStatus()
 * @method $this unset_Messages()
 */
class ArchiveBadgeCountResponse extends Response
{
    const JSON_PROPERTY_MAP = [
        'badge_count'             => 'int',
    ];
}
