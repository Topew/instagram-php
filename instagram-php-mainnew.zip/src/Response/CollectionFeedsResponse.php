<?php

namespace InstagramAPI\Response;

use InstagramAPI\Response;

/**
 * CollectionFeedsResponse.
 * 
 * @method CollectionFeedResponse getSaveClipsResponse()
 * @method CollectionFeedResponse getSaveIgtvResponse()
 * @method CollectionFeedResponse getSaveMediaResponse()
 * @method Model\CollectionTab[] getTabs()
 * @method bool isSaveClipsResponse()
 * @method bool isSaveIgtvResponse()
 * @method bool isSaveMediaResponse()
 * @method bool isTabs()
 * @method $this setSaveClipsResponse(CollectionFeedResponse $value)
 * @method $this setSaveIgtvResponse(CollectionFeedResponse $value)
 * @method $this setSaveMediaResponse(CollectionFeedResponse $value)
 * @method $this setTabs(Model\CollectionTab[] $value)
 * @method $this unsetSaveClipsResponse()
 * @method $this unsetSaveIgtvResponse()
 * @method $this unsetSaveMediaResponse()
 * @method $this unsetTabs()
 */
class CollectionFeedsResponse extends Response
{
    const JSON_PROPERTY_MAP = [
        'save_clips_response'      => 'CollectionFeedResponse',
        'save_igtv_response'       => 'CollectionFeedResponse',
        'save_media_response'      => 'CollectionFeedResponse',
        'tabs'                     => 'Model\CollectionTab[]'
    ];
}
