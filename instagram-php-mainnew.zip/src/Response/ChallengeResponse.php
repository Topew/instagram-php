<?php

namespace InstagramAPI\Response;

use InstagramAPI\Response;

/**
 * ChallengeResponse.
 *
 * @method Model\Challenge getChallenge()
 * @method mixed getMessage()
 * @method string getNonceCode()
 * @method string getStatus()
 * @method string getAction()
 * @method Model\StepData getStepData()
 * @method string getStepName()
 * @method string getUserId()
 * @method string getCni()
 * @method string getChallengeTypeEnum()
 * @method Model\_Message[] get_Messages()
 * @method bool isChallenge()
 * @method bool isMessage()
 * @method bool isNonceCode()
 * @method bool isStatus()
 * @method bool isAction()
 * @method bool isStepData()
 * @method bool isStepName()
 * @method bool isUserId()
 * @method bool isCni()
 * @method bool isChallengeTypeEnum()
 * @method bool is_Messages()
 * @method $this setChallenge(Model\Challenge $value)
 * @method $this setMessage(mixed $value)
 * @method $this setNonceCode(string $value)
 * @method $this setStatus(string $value)
 * @method $this setAction(string $value)
 * @method $this setStepData(Model\StepData $value)
 * @method $this setStepName(string $value)
 * @method $this setUserId(string $value)
 * @method $this setCni(string $value)
 * @method $this setChallengeTypeEnum(string $value)
 * @method $this set_Messages(Model\_Message[] $value)
 * @method $this unsetChallenge()
 * @method $this unsetMessage()
 * @method $this unsetNonceCode()
 * @method $this unsetStatus()
 * @method $this unsetAction()
 * @method $this unsetStepData()
 * @method $this unsetStepName()
 * @method $this unsetUserId()
 * @method $this unsetCni()
 * @method $this unsetChallengeTypeEnum()
 * @method $this unset_Messages()
 */
class ChallengeResponse extends Response
{
    const JSON_PROPERTY_MAP = [
        'step_name'             => 'string',
        'challenge'             => 'Model\Challenge',
        'step_data'             => 'Model\StepData',
        'user_id'               => 'string',
        'nonce_code'            => 'string',
        'cni'                   => 'string',
        'challenge_type_enum'   => 'string',
        'status'                => 'string',
        'action'                => 'string',
    ];
}
